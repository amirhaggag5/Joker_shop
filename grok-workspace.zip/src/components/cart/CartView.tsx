import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { QuantitySelector } from "@/components/product/QuantitySelector";
import { BRAND } from "@/lib/config";
import { formatEGP } from "@/lib/format";
import { cn } from "@/lib/utils";
import { useCart, useCartTotals } from "@/store/cart";

export function CartView() {
  const items = useCart((s) => s.items);
  const setQuantity = useCart((s) => s.setQuantity);
  const removeItem = useCart((s) => s.removeItem);
  const applyPromo = useCart((s) => s.applyPromo);
  const removePromo = useCart((s) => s.removePromo);
  const promoCode = useCart((s) => s.promoCode);
  const promoMessage = useCart((s) => s.promoMessage);
  const promoStatus = useCart((s) => s.promoStatus);
  const totals = useCartTotals();
  const [code, setCode] = useState("");

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <h1 className="font-display text-4xl font-semibold">Your cart is empty</h1>
        <p className="mt-3 text-sm text-muted">The drop is waiting.</p>
        <Button className="mt-8" asChild>
          <Link to="/shop">Continue shopping</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="mx-auto grid max-w-7xl gap-12 px-4 py-10 md:px-6 md:py-14 lg:grid-cols-[minmax(0,1fr)_360px]">
      <div>
        <h1 className="font-display text-4xl font-semibold">Cart</h1>
        <ul className="mt-8 divide-y divide-border border-y border-border">
          {items.map((item) => (
            <li key={item.key} className="flex gap-4 py-6">
              <Link to="/product/$slug" params={{ slug: item.slug }} className="size-28 shrink-0 overflow-hidden bg-surface sm:size-32">
                <img src={item.image} alt={item.name} className="h-full w-full object-cover" />
              </Link>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <p className="font-medium">{item.name}</p>
                    <p className="mt-1 text-sm text-muted">
                      Size {item.size} · {item.color}
                    </p>
                  </div>
                  <p className="tabular-nums">{formatEGP(item.price * item.quantity)}</p>
                </div>
                <div className="mt-4 flex items-center justify-between">
                  <QuantitySelector value={item.quantity} onChange={(qty) => setQuantity(item.key, qty)} />
                  <button
                    type="button"
                    className="text-xs tracking-label uppercase text-muted hover:text-fg"
                    onClick={() => removeItem(item.key)}
                  >
                    Remove
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
      <aside className="h-fit border border-border bg-bg-elevated p-6">
        <h2 className="text-sm tracking-label uppercase">Summary</h2>
        <dl className="mt-6 space-y-2 text-sm">
          <div className="flex justify-between">
            <dt className="text-muted">Subtotal</dt>
            <dd className="tabular-nums">{formatEGP(totals.subtotal)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-muted">Shipping</dt>
            <dd className="tabular-nums">{totals.freeShipping ? "Free" : formatEGP(totals.shipping)}</dd>
          </div>
          {totals.offerDiscount > 0 ? (
            <div className="flex justify-between text-success">
              <dt>{totals.offerLabel}</dt>
              <dd className="tabular-nums">-{formatEGP(totals.offerDiscount)}</dd>
            </div>
          ) : null}
          {totals.promoDiscount > 0 ? (
            <div className="flex justify-between text-success">
              <dt>Promo {promoCode}</dt>
              <dd className="tabular-nums">-{formatEGP(totals.promoDiscount)}</dd>
            </div>
          ) : null}
          <div className="flex justify-between">
            <dt className="text-muted">Discount</dt>
            <dd className="tabular-nums">{totals.discount ? `-${formatEGP(totals.discount)}` : formatEGP(0)}</dd>
          </div>
        </dl>
        {totals.freeShipping ? (
          <p className="mt-4 text-xs tracking-label uppercase text-success">Free shipping</p>
        ) : (
          <p className="mt-4 text-xs text-muted">
            Add {formatEGP(totals.remainingForFreeShipping)} more for free shipping over{" "}
            {BRAND.freeShippingThreshold.toLocaleString("en-EG")} EGP.
          </p>
        )}
        <div className="mt-6 flex justify-between border-t border-border pt-4 text-base font-medium">
          <span>Total</span>
          <span className="tabular-nums">{formatEGP(totals.total)}</span>
        </div>
        <form
          className="mt-6 flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            applyPromo(code);
          }}
        >
          <Input
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="Promo code"
            className="h-12"
            aria-label="Promo code"
          />
          <Button type="submit" variant="outline">
            Apply
          </Button>
        </form>
        {promoMessage ? (
          <p
            className={cn(
              "mt-2 text-xs",
              promoStatus === "success" ? "text-success" : "text-danger",
            )}
          >
            {promoMessage}
          </p>
        ) : null}
        {promoCode ? (
          <button type="button" className="mt-2 text-xs text-muted hover:text-fg" onClick={removePromo}>
            Remove code
          </button>
        ) : (
          <p className="mt-2 text-[11px] text-subtle">Try JOKER10</p>
        )}
        <Button className="mt-6 w-full" size="lg" asChild>
          <Link to="/checkout">Checkout</Link>
        </Button>
      </aside>
    </div>
  );
}

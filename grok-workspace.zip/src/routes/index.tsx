import { createFileRoute } from "@tanstack/react-router";
import { HomeView } from "@/components/home/HomeView";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "JOKER — Built for your everyday." },
      {
        name: "description",
        content: "Premium youth streetwear. Oversized tees, hoodies and cargos. Designed for the way you move, train and live.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  return <HomeView />;
}

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { evaluatePromo } from "@/data/promo";
import { computeTotals } from "@/lib/cart-math";

export type CartLine = {
  key: string;
  productId: string;
  slug: string;
  name: string;
  image: string;
  size: string;
  color: string;
  colorHex: string;
  price: number;
  quantity: number;
};

type CartState = {
  items: CartLine[];
  promoCode: string | null;
  promoMessage: string | null;
  promoStatus: "idle" | "success" | "invalid" | "expired" | "used" | "min";
  usedCodes: string[];
  bump: number;
  addItem: (line: Omit<CartLine, "key" | "quantity"> & { quantity?: number }) => void;
  removeItem: (key: string) => void;
  setQuantity: (key: string, quantity: number) => void;
  applyPromo: (code: string) => void;
  removePromo: () => void;
  markPromoUsed: () => void;
  clear: () => void;
};

export function lineKey(productId: string, size: string, color: string) {
  return `${productId}__${size}__${color}`;
}

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      promoCode: null,
      promoMessage: null,
      promoStatus: "idle",
      usedCodes: [],
      bump: 0,
      addItem: (line) => {
        const key = lineKey(line.productId, line.size, line.color);
        const quantity = line.quantity ?? 1;
        set((state) => {
          const existing = state.items.find((item) => item.key === key);
          const items = existing
            ? state.items.map((item) =>
                item.key === key ? { ...item, quantity: item.quantity + quantity } : item,
              )
            : [...state.items, { ...line, key, quantity }];
          return { items, bump: state.bump + 1 };
        });
      },
      removeItem: (key) => set((state) => ({ items: state.items.filter((item) => item.key !== key) })),
      setQuantity: (key, quantity) =>
        set((state) => ({
          items:
            quantity <= 0
              ? state.items.filter((item) => item.key !== key)
              : state.items.map((item) => (item.key === key ? { ...item, quantity } : item)),
        })),
      applyPromo: (code) => {
        const { items, usedCodes } = get();
        const totals = computeTotals(items, null, usedCodes);
        const result = evaluatePromo(code, totals.subtotal - totals.offerDiscount, usedCodes);
        if (!result.ok) {
          set({
            promoCode: null,
            promoMessage: result.message,
            promoStatus: result.reason,
          });
          return;
        }
        set({
          promoCode: result.promo.code,
          promoMessage: result.message,
          promoStatus: "success",
        });
      },
      removePromo: () => set({ promoCode: null, promoMessage: null, promoStatus: "idle" }),
      markPromoUsed: () => {
        const { promoCode, usedCodes } = get();
        if (!promoCode) return;
        if (usedCodes.includes(promoCode)) return;
        set({ usedCodes: [...usedCodes, promoCode], promoCode: null, promoMessage: null, promoStatus: "idle" });
      },
      clear: () => set({ items: [], promoCode: null, promoMessage: null, promoStatus: "idle" }),
    }),
    { name: "joker-cart" },
  ),
);

export function useCartCount() {
  return useCart((s) => s.items.reduce((sum, item) => sum + item.quantity, 0));
}

export function useCartTotals() {
  const items = useCart((s) => s.items);
  const promoCode = useCart((s) => s.promoCode);
  const usedCodes = useCart((s) => s.usedCodes);
  return computeTotals(items, promoCode, usedCodes);
}

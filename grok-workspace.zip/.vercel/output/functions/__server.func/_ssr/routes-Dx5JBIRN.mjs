import { i as __toESM } from "../_runtime.mjs";
import { X as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as BRAND } from "./config-DAONyBRW.mjs";
import { r as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { t as Button } from "./button-Bv-N6FT1.mjs";
import { c as Scan, f as Layers, o as ShieldCheck, r as StretchHorizontal } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { f as INSTAGRAM_IMAGES, p as PRODUCTS } from "./router-QtDp_Yot.mjs";
import { t as Input } from "./input-D6LKnbkF.mjs";
import { n as ProductCard } from "./ProductCard-C0R-tK-9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dx5JBIRN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var REVIEWS = [
	{
		id: "r1",
		name: "Karim A.",
		city: "New Cairo",
		quote: "The oversized tee actually fits. Heavy fabric — not that thin mall stuff. Wearing it every other day.",
		product: "Core Oversized Tee"
	},
	{
		id: "r2",
		name: "Layla M.",
		city: "Alexandria",
		quote: "Hoodie is dense, warm, and the cut is right. Ordered a second colour the same week.",
		product: "Essential Hoodie"
	},
	{
		id: "r3",
		name: "Omar H.",
		city: "6th of October",
		quote: "Clean pieces. Nothing loud. Exactly what I wanted for the gym and the street.",
		product: "Heavyweight Box Tee"
	},
	{
		id: "r4",
		name: "Nour S.",
		city: "Maadi",
		quote: "Cash on delivery, fast in Cairo, and the cargo is better in person than on the site.",
		product: "Utility Cargo"
	},
	{
		id: "r5",
		name: "Youssef K.",
		city: "Mansoura",
		quote: "Acid wash came with a real texture. Looks expensive without trying.",
		product: "Acid Wash Tee"
	},
	{
		id: "r6",
		name: "Farida T.",
		city: "Sheikh Zayed",
		quote: "JOKER feels like a proper brand, not a random drop page. I'll keep buying.",
		product: "Jester Tee"
	}
];
var QUALITY = [
	{
		title: "Premium Fabric",
		copy: "Heavyweight cotton and fleece chosen for drape, not just weight.",
		icon: Layers
	},
	{
		title: "Comfortable Fit",
		copy: "Oversized cuts that still sit clean on the body.",
		icon: StretchHorizontal
	},
	{
		title: "Modern Designs",
		copy: "Quiet graphics. No seasonal noise. Pieces that last more than a drop.",
		icon: Scan
	},
	{
		title: "Quality Guaranteed",
		copy: "If it isn't right, we replace it. Fourteen days, no argument.",
		icon: ShieldCheck
	}
];
function Newsletter() {
	const [email, setEmail] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)(false);
	function submit(event) {
		event.preventDefault();
		const value = email.trim().toLowerCase();
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
			toast.error("Enter a valid email.");
			return;
		}
		const key = "joker-newsletter";
		const prev = JSON.parse(localStorage.getItem(key) || "[]");
		if (!prev.includes(value)) localStorage.setItem(key, JSON.stringify([...prev, value]));
		setDone(true);
		toast.success("You're in.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-t border-border px-4 py-20 md:px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-xl text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl font-semibold tracking-tight md:text-4xl",
					children: "Join the JOKER community"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Drops, restocks, and the occasional private offer. No noise."
				}),
				done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-sm",
					children: "You're on the list."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "mt-8 flex flex-col gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "email",
						required: true,
						value: email,
						onChange: (e) => setEmail(e.target.value),
						placeholder: "Email address",
						className: "flex-1"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "sm:w-40",
						children: "Subscribe"
					})]
				})
			]
		})
	});
}
function HomeView() {
	const featured = PRODUCTS.filter((p) => p.featured);
	const best = PRODUCTS.filter((p) => p.bestSeller);
	const fresh = PRODUCTS.filter((p) => p.newArrival);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative min-h-[78vh] overflow-hidden md:min-h-[88vh]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/products/hero.jpg",
					alt: "JOKER streetwear — oversized tee, hoodie and cargo",
					className: "absolute inset-0 h-full w-full object-cover animate-fade-in",
					fetchPriority: "high"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/45 to-bg/20" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto flex min-h-[78vh] max-w-7xl flex-col justify-end px-4 pb-16 md:min-h-[88vh] md:px-6 md:pb-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "animate-fade-up text-[11px] tracking-label uppercase text-muted",
							children: "Streetwear · Sportswear · Egypt"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "animate-fade-up mt-4 font-display text-6xl font-extrabold tracking-brand md:text-8xl",
							style: { animationDelay: "80ms" },
							children: "JOKER"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "animate-fade-up mt-4 max-w-md text-sm tracking-label uppercase text-fg/90 md:text-base",
							style: { animationDelay: "160ms" },
							children: BRAND.tagline
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "animate-fade-up mt-8",
							style: { animationDelay: "240ms" },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/shop",
									children: "Shop now"
								})
							})
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-8 flex items-end justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold md:text-3xl",
					children: "Featured collection"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/shop",
					className: "text-[11px] tracking-label uppercase text-muted hover:text-fg",
					children: "View all"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-x-3 gap-y-10 md:grid-cols-3 lg:grid-cols-4",
				children: featured.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, {
					product: p,
					priority: i < 2
				}, p.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 pb-16 md:px-6 md:pb-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-8 flex items-end justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold md:text-3xl",
					children: "Best sellers"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/shop/$category",
					params: { category: "best-sellers" },
					className: "text-[11px] tracking-label uppercase text-muted hover:text-fg",
					children: "Shop best sellers"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-x-3 gap-y-10 md:grid-cols-3 lg:grid-cols-4",
				children: best.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden border-y border-border",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/products/promo-banner.jpg",
					alt: "",
					className: "absolute inset-0 h-full w-full object-cover opacity-40"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-bg/70" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto max-w-7xl px-4 py-20 text-center md:px-6 md:py-28",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] tracking-label uppercase text-muted",
							children: "Limited offer"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-display text-4xl font-semibold md:text-6xl",
							children: "2 T-Shirts + 1 Free"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 text-sm tracking-label uppercase text-muted",
							children: [
								"Free shipping on orders over ",
								BRAND.freeShippingThreshold.toLocaleString("en-EG"),
								" EGP"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-8",
							size: "lg",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/shop/$category",
								params: { category: "t-shirts" },
								children: "Shop the offer"
							})
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-8 flex items-end justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold md:text-3xl",
					children: "New arrivals"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/shop/$category",
					params: { category: "new-arrivals" },
					className: "text-[11px] tracking-label uppercase text-muted hover:text-fg",
					children: "Shop new"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-x-3 gap-y-10 md:grid-cols-3",
				children: fresh.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-border bg-bg-elevated",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl gap-10 px-4 py-20 md:grid-cols-2 md:px-6 md:py-28",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] tracking-label uppercase text-muted",
					children: "The house"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 font-display text-3xl font-semibold md:text-5xl",
					children: BRAND.philosophy
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-xl self-end text-base leading-relaxed text-muted md:text-lg",
					children: "JOKER is built as a uniform, not a costume. Heavy fabrics, oversized cuts, and a palette that doesn't expire with the season. Designed in Cairo for a generation that trains, commutes, and lives in the same clothes."
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-semibold md:text-3xl",
				children: "Made to last"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-4",
				children: QUALITY.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-border pt-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-5 text-muted" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-4 text-sm font-medium",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: item.copy
						})
					]
				}, item.title))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-border bg-bg-elevated",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold md:text-3xl",
					children: "What they say"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-6 md:grid-cols-3",
					children: REVIEWS.map((review) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
						className: "border border-border bg-bg p-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm leading-relaxed",
							children: [
								"“",
								review.quote,
								"”"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
							className: "mt-6 text-xs tracking-label uppercase text-muted",
							children: [
								review.name,
								" · ",
								review.city
							]
						})]
					}, review.id))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-8 flex items-end justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold md:text-3xl",
					children: "On Instagram"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: BRAND.instagram,
					className: "text-[11px] tracking-label uppercase text-muted hover:text-fg",
					children: "@joker"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2 md:grid-cols-3 md:gap-3",
				children: INSTAGRAM_IMAGES.map((img) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: BRAND.instagram,
					target: "_blank",
					rel: "noreferrer",
					className: "block aspect-square overflow-hidden bg-surface",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: img.src,
						alt: img.alt,
						className: "h-full w-full object-cover transition-transform duration-500 hover:scale-105",
						loading: "lazy"
					})
				}, img.src))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Newsletter, {})
	] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeView, {});
}
//#endregion
export { Home as component };

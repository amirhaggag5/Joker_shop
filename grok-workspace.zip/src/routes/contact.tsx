import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BRAND, whatsappUrl } from "@/lib/config";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — JOKER" },
      { name: "description", content: "Contact JOKER on WhatsApp, email, or the form. We reply within a day." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [sent, setSent] = useState(false);

  function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const payload = {
      name: String(data.get("name") ?? ""),
      email: String(data.get("email") ?? ""),
      message: String(data.get("message") ?? ""),
      at: new Date().toISOString(),
    };
    if (payload.name.trim().length < 2 || payload.message.trim().length < 8) {
      toast.error("Add your name and a short message.");
      return;
    }
    const key = "joker-contact";
    const prev = JSON.parse(localStorage.getItem(key) || "[]") as unknown[];
    localStorage.setItem(key, JSON.stringify([payload, ...prev]));
    setSent(true);
    toast.success("Message received.");
  }

  return (
    <div className="mx-auto grid max-w-5xl gap-12 px-4 py-16 md:grid-cols-2 md:py-24">
      <div>
        <h1 className="font-display text-4xl font-semibold md:text-5xl">Contact</h1>
        <p className="mt-4 text-sm leading-relaxed text-muted">
          Orders, sizing, or a restock question — WhatsApp is fastest. Email works too.
        </p>
        <ul className="mt-8 space-y-3 text-sm">
          <li>
            WhatsApp ·{" "}
            <a className="underline-offset-4 hover:underline" href={whatsappUrl()} target="_blank" rel="noreferrer">
              Chat with us
            </a>
          </li>
          <li>
            Email · <a className="hover:underline" href={`mailto:${BRAND.email}`}>{BRAND.email}</a>
          </li>
          <li>Hours · Daily, 11:00–22:00 Cairo</li>
        </ul>
      </div>
      {sent ? (
        <p className="self-center text-sm">Thanks — we'll get back to you.</p>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          <label className="block text-xs">
            Name
            <Input name="name" required className="mt-1.5" />
          </label>
          <label className="block text-xs">
            Email
            <Input name="email" type="email" required className="mt-1.5" />
          </label>
          <label className="block text-xs">
            Message
            <textarea
              name="message"
              required
              className="mt-1.5 min-h-32 w-full border border-border bg-bg-elevated px-4 py-3 text-sm outline-none focus:border-fg"
            />
          </label>
          <Button type="submit">Send</Button>
        </form>
      )}
    </div>
  );
}

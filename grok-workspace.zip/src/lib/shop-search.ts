import type { SortKey } from "@/data/products";
import { SORT_OPTIONS } from "@/data/products";

const SORTS = new Set(SORT_OPTIONS.map((s) => s.value));

export type ShopSearchParams = {
  size?: string;
  color?: string;
  min?: number;
  max?: number;
  sort?: SortKey;
};

export function parseShopSearch(search: Record<string, unknown>): ShopSearchParams {
  const result: ShopSearchParams = {};
  if (typeof search.size === "string" && search.size) result.size = search.size;
  if (typeof search.color === "string" && search.color) result.color = search.color;
  const min = search.min == null || search.min === "" ? undefined : Number(search.min);
  const max = search.max == null || search.max === "" ? undefined : Number(search.max);
  if (Number.isFinite(min)) result.min = min;
  if (Number.isFinite(max)) result.max = max;
  if (SORTS.has(search.sort as SortKey)) result.sort = search.sort as SortKey;
  return result;
}

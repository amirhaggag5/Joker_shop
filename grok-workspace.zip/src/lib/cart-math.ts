import { BRAND } from "@/lib/config";
import { getProductById } from "@/data/products";
import { evaluatePromo, findPromo, promoDiscountAmount } from "@/data/promo";
import type { CartLine } from "@/store/cart";

export type CartTotals = {
  subtotal: number;
  offerDiscount: number;
  offerLabel: string | null;
  promoDiscount: number;
  discount: number;
  shipping: number;
  total: number;
  freeShipping: boolean;
  remainingForFreeShipping: number;
};

export function teeOfferDiscount(items: CartLine[]) {
  const prices: number[] = [];
  for (const line of items) {
    const product = getProductById(line.productId);
    if (product?.category !== "t-shirts") continue;
    for (let i = 0; i < line.quantity; i += 1) prices.push(line.price);
  }
  prices.sort((a, b) => a - b);
  const freeCount = Math.floor(prices.length / 3);
  if (freeCount <= 0) return 0;
  return prices.slice(0, freeCount).reduce((sum, price) => sum + price, 0);
}

export function computeTotals(
  items: CartLine[],
  promoCode: string | null,
  usedCodes: string[],
): CartTotals {
  const subtotal = items.reduce((sum, line) => sum + line.price * line.quantity, 0);
  const offerDiscount = teeOfferDiscount(items);
  const offerLabel = offerDiscount > 0 ? "2 T-Shirts + 1 Free" : null;
  const afterOffer = Math.max(0, subtotal - offerDiscount);

  let promoDiscount = 0;
  if (promoCode) {
    const check = evaluatePromo(promoCode, afterOffer, usedCodes);
    if (check.ok) promoDiscount = promoDiscountAmount(check.promo, afterOffer);
    else {
      const promo = findPromo(promoCode);
      if (promo && !promo.once) {
        const relaxed = evaluatePromo(promoCode, afterOffer, []);
        if (relaxed.ok) promoDiscount = promoDiscountAmount(relaxed.promo, afterOffer);
      }
    }
  }

  const discount = offerDiscount + promoDiscount;
  const afterDiscounts = Math.max(0, subtotal - discount);
  const freeShipping = afterDiscounts >= BRAND.freeShippingThreshold;
  const shipping = items.length === 0 || freeShipping ? 0 : BRAND.shippingFee;
  const remainingForFreeShipping = Math.max(0, BRAND.freeShippingThreshold - afterDiscounts);

  return {
    subtotal,
    offerDiscount,
    offerLabel,
    promoDiscount,
    discount,
    shipping,
    total: afterDiscounts + shipping,
    freeShipping,
    remainingForFreeShipping,
  };
}

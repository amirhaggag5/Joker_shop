import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { BRAND } from "@/lib/config";
import { formatEGP } from "@/lib/format";
import { orderWhatsAppLink } from "@/lib/whatsapp";
import type { Order } from "@/store/orders";

export function OrderConfirmation({ order }: { order: Order }) {
  return (
    <div className="mx-auto max-w-2xl px-4 py-16 md:py-24">
      <p className="text-[11px] tracking-label uppercase text-success">Cash on delivery</p>
      <h1 className="mt-3 font-display text-4xl font-semibold md:text-5xl">Order confirmed</h1>
      <p className="mt-4 text-sm text-muted">
        We'll call to confirm, then ship. Estimated delivery: {BRAND.estimatedDelivery.toLowerCase()}.
      </p>
      <dl className="mt-10 space-y-3 border border-border bg-bg-elevated p-6 text-sm">
        <div className="flex justify-between gap-4">
          <dt className="text-muted">Order number</dt>
          <dd className="font-medium tabular-nums">{order.id}</dd>
        </div>
        <div className="flex justify-between gap-4">
          <dt className="text-muted">Customer</dt>
          <dd>{order.customer.fullName}</dd>
        </div>
        <div className="flex justify-between gap-4">
          <dt className="text-muted">Phone</dt>
          <dd className="tabular-nums">{order.customer.mobile}</dd>
        </div>
        <div className="flex justify-between gap-4">
          <dt className="text-muted">Total</dt>
          <dd className="tabular-nums">{formatEGP(order.total)}</dd>
        </div>
        <div className="flex justify-between gap-4">
          <dt className="text-muted">Payment</dt>
          <dd>Cash on Delivery</dd>
        </div>
        <div>
          <dt className="text-muted">Delivery</dt>
          <dd className="mt-1">
            {order.customer.address}, Bldg {order.customer.building}, Apt {order.customer.apartment}, {order.customer.city},{" "}
            {order.customer.governorate}
          </dd>
        </div>
      </dl>
      <ul className="mt-6 divide-y divide-border border-y border-border text-sm">
        {order.items.map((item) => (
          <li key={item.key} className="flex justify-between py-3">
            <span>
              {item.name} · {item.color}/{item.size} × {item.quantity}
            </span>
            <span className="tabular-nums">{formatEGP(item.price * item.quantity)}</span>
          </li>
        ))}
      </ul>
      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <Button asChild>
          <Link to="/shop">Continue shopping</Link>
        </Button>
        <Button variant="outline" asChild>
          <a href={orderWhatsAppLink(order)} target="_blank" rel="noreferrer">
            Contact us on WhatsApp
          </a>
        </Button>
      </div>
    </div>
  );
}

import { useMemo, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { GOVERNORATES, citiesFor } from "@/data/egypt";
import { formatEGP } from "@/lib/format";
import { cn } from "@/lib/utils";
import { useCart, useCartTotals } from "@/store/cart";
import { createOrderId, useOrders, type CheckoutCustomer } from "@/store/orders";

const schema = z.object({
  fullName: z.string().min(3, "Enter your full name"),
  mobile: z
    .string()
    .regex(/^01[0125][0-9]{8}$/, "Enter a valid Egyptian mobile (01x xxxxxxxx)"),
  governorate: z.string().min(1, "Select a governorate"),
  city: z.string().min(1, "Select a city"),
  address: z.string().min(8, "Enter a full address"),
  building: z.string().min(1, "Building number required"),
  apartment: z.string().min(1, "Apartment number required"),
  notes: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

export function CheckoutView() {
  const items = useCart((s) => s.items);
  const totals = useCartTotals();
  const promoCode = useCart((s) => s.promoCode);
  const clear = useCart((s) => s.clear);
  const markPromoUsed = useCart((s) => s.markPromoUsed);
  const addOrder = useOrders((s) => s.addOrder);
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      fullName: "",
      mobile: "",
      governorate: "",
      city: "",
      address: "",
      building: "",
      apartment: "",
      notes: "",
    },
  });

  const governorate = form.watch("governorate");
  const cities = useMemo(() => citiesFor(governorate), [governorate]);

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <h1 className="font-display text-4xl font-semibold">Your cart is empty</h1>
        <Button className="mt-8" asChild>
          <Link to="/shop">Shop now</Link>
        </Button>
      </div>
    );
  }

  function onSubmit(values: FormValues) {
    setSubmitting(true);
    const customer: CheckoutCustomer = {
      ...values,
      notes: values.notes?.trim() || undefined,
    };
    const order = {
      id: createOrderId(),
      createdAt: new Date().toISOString(),
      customer,
      items: [...items],
      subtotal: totals.subtotal,
      shipping: totals.shipping,
      discount: totals.discount,
      total: totals.total,
      promoCode: promoCode ?? undefined,
      payment: "cod" as const,
    };
    addOrder(order);
    markPromoUsed();
    clear();
    void navigate({ to: "/order/$id", params: { id: order.id } });
  }

  const fieldClass = "mt-1.5";

  return (
    <div className="mx-auto grid max-w-7xl gap-12 px-4 py-10 md:px-6 md:py-14 lg:grid-cols-[minmax(0,1fr)_360px]">
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <h1 className="font-display text-4xl font-semibold">Checkout</h1>
        <p className="text-sm text-muted">Cash on delivery. No card details required.</p>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="sm:col-span-2 text-xs">
            Full name
            <Input className={fieldClass} {...form.register("fullName")} autoComplete="name" />
            {form.formState.errors.fullName ? (
              <span className="mt-1 block text-danger">{form.formState.errors.fullName.message}</span>
            ) : null}
          </label>
          <label className="sm:col-span-2 text-xs">
            Mobile number
            <Input className={fieldClass} {...form.register("mobile")} placeholder="01xxxxxxxxx" inputMode="tel" />
            {form.formState.errors.mobile ? (
              <span className="mt-1 block text-danger">{form.formState.errors.mobile.message}</span>
            ) : null}
          </label>
          <label className="text-xs">
            Governorate
            <select
              className={cn(fieldClass, "h-12 w-full border border-border bg-bg-elevated px-3 text-sm")}
              {...form.register("governorate", {
                onChange: () => form.setValue("city", ""),
              })}
            >
              <option value="">Select</option>
              {GOVERNORATES.map((g) => (
                <option key={g.name} value={g.name}>
                  {g.name}
                </option>
              ))}
            </select>
            {form.formState.errors.governorate ? (
              <span className="mt-1 block text-danger">{form.formState.errors.governorate.message}</span>
            ) : null}
          </label>
          <label className="text-xs">
            City
            <select
              className={cn(fieldClass, "h-12 w-full border border-border bg-bg-elevated px-3 text-sm")}
              {...form.register("city")}
              disabled={!governorate}
            >
              <option value="">Select</option>
              {cities.map((city) => (
                <option key={city} value={city}>
                  {city}
                </option>
              ))}
            </select>
            {form.formState.errors.city ? (
              <span className="mt-1 block text-danger">{form.formState.errors.city.message}</span>
            ) : null}
          </label>
          <label className="sm:col-span-2 text-xs">
            Full address
            <Input className={fieldClass} {...form.register("address")} placeholder="Street name, district" />
            {form.formState.errors.address ? (
              <span className="mt-1 block text-danger">{form.formState.errors.address.message}</span>
            ) : null}
          </label>
          <label className="text-xs">
            Building number
            <Input className={fieldClass} {...form.register("building")} />
            {form.formState.errors.building ? (
              <span className="mt-1 block text-danger">{form.formState.errors.building.message}</span>
            ) : null}
          </label>
          <label className="text-xs">
            Apartment number
            <Input className={fieldClass} {...form.register("apartment")} />
            {form.formState.errors.apartment ? (
              <span className="mt-1 block text-danger">{form.formState.errors.apartment.message}</span>
            ) : null}
          </label>
          <label className="sm:col-span-2 text-xs">
            Notes
            <textarea
              className="mt-1.5 min-h-24 w-full border border-border bg-bg-elevated px-4 py-3 text-sm outline-none focus:border-fg"
              {...form.register("notes")}
              placeholder="Landmark, delivery time, extra details"
            />
          </label>
        </div>
        <fieldset className="border border-border p-4">
          <legend className="px-2 text-[11px] tracking-label uppercase text-muted">Payment method</legend>
          <label className="flex items-center gap-3 text-sm">
            <input type="radio" checked readOnly className="size-4 accent-current" />
            Cash on Delivery
          </label>
          <p className="mt-2 text-xs text-muted">Pay the courier when your order arrives. We never ask for card details.</p>
        </fieldset>
        <Button type="submit" size="lg" className="w-full" disabled={submitting}>
          Confirm order
        </Button>
      </form>
      <aside className="h-fit border border-border bg-bg-elevated p-6">
        <h2 className="text-sm tracking-label uppercase">Order summary</h2>
        <ul className="mt-5 space-y-4">
          {items.map((item) => (
            <li key={item.key} className="flex gap-3 text-sm">
              <img src={item.image} alt="" className="size-16 object-cover bg-surface" />
              <div className="min-w-0 flex-1">
                <p className="truncate">{item.name}</p>
                <p className="text-xs text-muted">
                  {item.color} / {item.size} × {item.quantity}
                </p>
              </div>
              <p className="tabular-nums">{formatEGP(item.price * item.quantity)}</p>
            </li>
          ))}
        </ul>
        <dl className="mt-6 space-y-2 border-t border-border pt-4 text-sm">
          <div className="flex justify-between">
            <dt className="text-muted">Subtotal</dt>
            <dd className="tabular-nums">{formatEGP(totals.subtotal)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-muted">Shipping</dt>
            <dd className="tabular-nums">{totals.freeShipping ? "Free" : formatEGP(totals.shipping)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-muted">Discount</dt>
            <dd className="tabular-nums">{totals.discount ? `-${formatEGP(totals.discount)}` : formatEGP(0)}</dd>
          </div>
          <div className="flex justify-between pt-2 font-medium">
            <dt>Total</dt>
            <dd className="tabular-nums">{formatEGP(totals.total)}</dd>
          </div>
        </dl>
      </aside>
    </div>
  );
}

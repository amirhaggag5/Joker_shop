import { Outlet, createFileRoute } from "@tanstack/react-router";
import { parseShopSearch } from "@/lib/shop-search";

export const Route = createFileRoute("/shop")({
  validateSearch: parseShopSearch,
  component: ShopLayout,
});

function ShopLayout() {
  return <Outlet />;
}

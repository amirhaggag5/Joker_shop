import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { BRAND } from "@/lib/config";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — JOKER" },
      { name: "description", content: BRAND.description },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <article className="mx-auto max-w-3xl px-4 py-16 md:py-24">
      <p className="text-[11px] tracking-label uppercase text-muted">The house</p>
      <h1 className="mt-3 font-display text-4xl font-semibold md:text-6xl">JOKER</h1>
      <p className="mt-6 text-xl text-muted">{BRAND.philosophy}</p>
      <div className="mt-10 space-y-5 text-base leading-relaxed text-muted">
        <p>
          JOKER is a streetwear house for people who live in their clothes. We design oversized tees,
          heavyweight hoodies and everyday sportswear in a short palette — black, off-white, charcoal,
          navy — so the pieces actually get worn.
        </p>
        <p>
          Nothing here is seasonal filler. Fabric weight, shoulder drop, and hem length are decided
          on the body, not on a moodboard. If it doesn't earn a place in a weekly rotation, it doesn't
          ship.
        </p>
        <p>
          We sell from Egypt, ship nationwide, and take cash on delivery because that's how our
          customers actually buy. Premium doesn't have to mean inaccessible.
        </p>
      </div>
      <Button className="mt-10" asChild>
        <Link to="/shop">Shop the collection</Link>
      </Button>
    </article>
  );
}

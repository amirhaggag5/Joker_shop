import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orders-fH9KXyrh.js
var useOrders = create()(persist((set) => ({
	orders: [],
	addOrder: (order) => set((state) => ({ orders: [order, ...state.orders] }))
}), { name: "joker-orders" }));
function createOrderId() {
	const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
	let body = "";
	for (let i = 0; i < 6; i += 1) body += alphabet[Math.floor(Math.random() * 32)];
	return `JKR-${body}`;
}
//#endregion
export { useOrders as n, createOrderId as t };

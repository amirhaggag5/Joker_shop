import { SIZE_GUIDE } from "@/data/products";

export function SizeGuideTable() {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-80 text-left text-sm">
        <thead>
          <tr className="border-b border-border text-[11px] uppercase tracking-label text-muted">
            <th className="py-3 pr-4 font-medium">Size</th>
            <th className="py-3 pr-4 font-medium">Chest</th>
            <th className="py-3 pr-4 font-medium">Length</th>
            <th className="py-3 font-medium">Shoulder</th>
          </tr>
        </thead>
        <tbody>
          {SIZE_GUIDE.map((row) => (
            <tr key={row.size} className="border-b border-border/70 text-fg">
              <td className="py-3 pr-4 font-medium">{row.size}</td>
              <td className="py-3 pr-4 tabular-nums">{row.chest} cm</td>
              <td className="py-3 pr-4 tabular-nums">{row.length} cm</td>
              <td className="py-3 tabular-nums">{row.shoulder} cm</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="mt-3 text-xs text-muted">
        Oversized fit. If you are between sizes, take the smaller one for a cleaner drape.
      </p>
    </div>
  );
}

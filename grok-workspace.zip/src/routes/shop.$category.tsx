import { createFileRoute, notFound } from "@tanstack/react-router";
import { ShopView } from "@/components/shop/ShopView";
import { SHOP_CATEGORIES } from "@/data/products";
import { parseShopSearch } from "@/lib/shop-search";

const slugs = new Set(SHOP_CATEGORIES.map((c) => c.slug));

export const Route = createFileRoute("/shop/$category")({
  validateSearch: parseShopSearch,
  beforeLoad: ({ params }) => {
    if (params.category === "all" || !slugs.has(params.category as (typeof SHOP_CATEGORIES)[number]["slug"])) {
      throw notFound();
    }
  },
  head: ({ params }) => {
    const label = SHOP_CATEGORIES.find((c) => c.slug === params.category)?.label ?? "Shop";
    return {
      meta: [
        { title: `${label} — JOKER` },
        { name: "description", content: `Shop ${label.toLowerCase()} from JOKER. Premium streetwear with cash on delivery in Egypt.` },
      ],
    };
  },
  component: ShopCategory,
});

function ShopCategory() {
  const { category } = Route.useParams();
  const search = Route.useSearch();
  return <ShopView category={category} search={search} />;
}

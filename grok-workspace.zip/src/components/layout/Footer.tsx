import { Link } from "@tanstack/react-router";
import { Logo } from "@/components/logo";
import { SHOP_CATEGORIES } from "@/data/products";
import { BRAND, whatsappUrl } from "@/lib/config";

const HOUSE = [
  { to: "/about" as const, label: "About" },
  { to: "/contact" as const, label: "Contact" },
  { to: "/shipping" as const, label: "Shipping & Returns" },
  { to: "/privacy" as const, label: "Privacy Policy" },
  { to: "/terms" as const, label: "Terms" },
];

export function Footer() {
  return (
    <footer className="border-t border-border bg-bg">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 md:grid-cols-4 md:px-6">
        <div className="md:col-span-1">
          <Logo />
          <p className="mt-4 max-w-xs text-sm text-muted">{BRAND.philosophy}</p>
        </div>
        <div>
          <p className="text-[11px] font-medium tracking-label uppercase text-subtle">Shop</p>
          <ul className="mt-4 space-y-2.5">
            {SHOP_CATEGORIES.map((item) => (
              <li key={item.slug}>
                {item.slug === "all" ? (
                  <Link to="/shop" className="text-sm text-muted transition-colors hover:text-fg">
                    {item.label}
                  </Link>
                ) : (
                  <Link
                    to="/shop/$category"
                    params={{ category: item.slug }}
                    className="text-sm text-muted transition-colors hover:text-fg"
                  >
                    {item.label}
                  </Link>
                )}
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-[11px] font-medium tracking-label uppercase text-subtle">House</p>
          <ul className="mt-4 space-y-2.5">
            {HOUSE.map((item) => (
              <li key={item.to}>
                <Link to={item.to} className="text-sm text-muted transition-colors hover:text-fg">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-[11px] font-medium tracking-label uppercase text-subtle">Connect</p>
          <ul className="mt-4 space-y-2.5 text-sm text-muted">
            <li>
              <a href={BRAND.instagram} target="_blank" rel="noreferrer" className="hover:text-fg">
                Instagram
              </a>
            </li>
            <li>
              <a href={BRAND.tiktok} target="_blank" rel="noreferrer" className="hover:text-fg">
                TikTok
              </a>
            </li>
            <li>
              <a href={whatsappUrl()} target="_blank" rel="noreferrer" className="hover:text-fg">
                WhatsApp
              </a>
            </li>
            <li>
              <a href={`mailto:${BRAND.email}`} className="hover:text-fg">
                {BRAND.email}
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border">
        <p className="mx-auto flex max-w-7xl justify-between px-4 py-5 text-[11px] tracking-label uppercase text-subtle md:px-6">
          <span>© {new Date().getFullYear()} JOKER</span>
          <span>Egypt · Cash on delivery</span>
        </p>
      </div>
    </footer>
  );
}

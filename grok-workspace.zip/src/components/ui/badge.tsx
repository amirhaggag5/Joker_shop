import { cn } from "@/lib/utils";

export function Badge({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <span
      className={cn(
        "inline-flex items-center bg-fg px-2 py-1 font-sans text-[10px] font-medium uppercase tracking-label text-bg",
        className,
      )}
    >
      {children}
    </span>
  );
}

import { create } from "zustand";

type UIState = {
  cartOpen: boolean;
  searchOpen: boolean;
  menuOpen: boolean;
  setCartOpen: (open: boolean) => void;
  setSearchOpen: (open: boolean) => void;
  setMenuOpen: (open: boolean) => void;
  closeAll: () => void;
};

export const useUI = create<UIState>((set) => ({
  cartOpen: false,
  searchOpen: false,
  menuOpen: false,
  setCartOpen: (cartOpen) => set({ cartOpen, searchOpen: false, menuOpen: false }),
  setSearchOpen: (searchOpen) => set({ searchOpen, cartOpen: false, menuOpen: false }),
  setMenuOpen: (menuOpen) => set({ menuOpen, cartOpen: false, searchOpen: false }),
  closeAll: () => set({ cartOpen: false, searchOpen: false, menuOpen: false }),
}));

import { X as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_-B48Nqn3n.js
var import_jsx_runtime = require_jsx_runtime();
function CatchAll() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl px-4 py-24 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] tracking-label uppercase text-muted",
				children: "404"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl font-semibold",
				children: "This page doesn't exist."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/shop",
				className: "mt-8 inline-flex h-12 items-center bg-fg px-6 text-xs font-medium tracking-label uppercase text-bg",
				children: "Back to shop"
			})
		]
	});
}
//#endregion
export { CatchAll as component };

import { Link } from "@tanstack/react-router";
import { ShieldCheck, StretchHorizontal, Layers, Scan } from "lucide-react";
import { ProductCard } from "@/components/product/ProductCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { INSTAGRAM_IMAGES, PRODUCTS } from "@/data/products";
import { REVIEWS } from "@/data/reviews";
import { BRAND } from "@/lib/config";
import { useState } from "react";
import { toast } from "sonner";

const QUALITY = [
  { title: "Premium Fabric", copy: "Heavyweight cotton and fleece chosen for drape, not just weight.", icon: Layers },
  { title: "Comfortable Fit", copy: "Oversized cuts that still sit clean on the body.", icon: StretchHorizontal },
  { title: "Modern Designs", copy: "Quiet graphics. No seasonal noise. Pieces that last more than a drop.", icon: Scan },
  { title: "Quality Guaranteed", copy: "If it isn't right, we replace it. Fourteen days, no argument.", icon: ShieldCheck },
];

function Newsletter() {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  function submit(event: React.FormEvent) {
    event.preventDefault();
    const value = email.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      toast.error("Enter a valid email.");
      return;
    }
    const key = "joker-newsletter";
    const prev = JSON.parse(localStorage.getItem(key) || "[]") as string[];
    if (!prev.includes(value)) localStorage.setItem(key, JSON.stringify([...prev, value]));
    setDone(true);
    toast.success("You're in.");
  }

  return (
    <section className="border-t border-border px-4 py-20 md:px-6">
      <div className="mx-auto max-w-xl text-center">
        <h2 className="font-display text-3xl font-semibold tracking-tight md:text-4xl">
          Join the JOKER community
        </h2>
        <p className="mt-3 text-sm text-muted">Drops, restocks, and the occasional private offer. No noise.</p>
        {done ? (
          <p className="mt-8 text-sm">You're on the list.</p>
        ) : (
          <form onSubmit={submit} className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email address"
              className="flex-1"
            />
            <Button type="submit" className="sm:w-40">
              Subscribe
            </Button>
          </form>
        )}
      </div>
    </section>
  );
}

export function HomeView() {
  const featured = PRODUCTS.filter((p) => p.featured);
  const best = PRODUCTS.filter((p) => p.bestSeller);
  const fresh = PRODUCTS.filter((p) => p.newArrival);

  return (
    <div>
      <section className="relative min-h-[78vh] overflow-hidden md:min-h-[88vh]">
        <img
          src="/products/hero.jpg"
          alt="JOKER streetwear — oversized tee, hoodie and cargo"
          className="absolute inset-0 h-full w-full object-cover animate-fade-in"
          fetchPriority="high"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/45 to-bg/20" />
        <div className="relative mx-auto flex min-h-[78vh] max-w-7xl flex-col justify-end px-4 pb-16 md:min-h-[88vh] md:px-6 md:pb-24">
          <p className="animate-fade-up text-[11px] tracking-label uppercase text-muted">Streetwear · Sportswear · Egypt</p>
          <h1 className="animate-fade-up mt-4 font-display text-6xl font-extrabold tracking-brand md:text-8xl" style={{ animationDelay: "80ms" }}>
            JOKER
          </h1>
          <p className="animate-fade-up mt-4 max-w-md text-sm tracking-label uppercase text-fg/90 md:text-base" style={{ animationDelay: "160ms" }}>
            {BRAND.tagline}
          </p>
          <div className="animate-fade-up mt-8" style={{ animationDelay: "240ms" }}>
            <Button size="lg" asChild>
              <Link to="/shop">Shop now</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
        <div className="mb-8 flex items-end justify-between">
          <h2 className="font-display text-2xl font-semibold md:text-3xl">Featured collection</h2>
          <Link to="/shop" className="text-[11px] tracking-label uppercase text-muted hover:text-fg">
            View all
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-x-3 gap-y-10 md:grid-cols-3 lg:grid-cols-4">
          {featured.map((p, i) => (
            <ProductCard key={p.id} product={p} priority={i < 2} />
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 pb-16 md:px-6 md:pb-24">
        <div className="mb-8 flex items-end justify-between">
          <h2 className="font-display text-2xl font-semibold md:text-3xl">Best sellers</h2>
          <Link
            to="/shop/$category"
            params={{ category: "best-sellers" }}
            className="text-[11px] tracking-label uppercase text-muted hover:text-fg"
          >
            Shop best sellers
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-x-3 gap-y-10 md:grid-cols-3 lg:grid-cols-4">
          {best.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      <section className="relative overflow-hidden border-y border-border">
        <img src="/products/promo-banner.jpg" alt="" className="absolute inset-0 h-full w-full object-cover opacity-40" />
        <div className="absolute inset-0 bg-bg/70" />
        <div className="relative mx-auto max-w-7xl px-4 py-20 text-center md:px-6 md:py-28">
          <p className="text-[11px] tracking-label uppercase text-muted">Limited offer</p>
          <h2 className="mt-4 font-display text-4xl font-semibold md:text-6xl">2 T-Shirts + 1 Free</h2>
          <p className="mt-4 text-sm tracking-label uppercase text-muted">
            Free shipping on orders over {BRAND.freeShippingThreshold.toLocaleString("en-EG")} EGP
          </p>
          <Button className="mt-8" size="lg" asChild>
            <Link to="/shop/$category" params={{ category: "t-shirts" }}>
              Shop the offer
            </Link>
          </Button>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
        <div className="mb-8 flex items-end justify-between">
          <h2 className="font-display text-2xl font-semibold md:text-3xl">New arrivals</h2>
          <Link
            to="/shop/$category"
            params={{ category: "new-arrivals" }}
            className="text-[11px] tracking-label uppercase text-muted hover:text-fg"
          >
            Shop new
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-x-3 gap-y-10 md:grid-cols-3">
          {fresh.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      <section className="border-t border-border bg-bg-elevated">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-20 md:grid-cols-2 md:px-6 md:py-28">
          <div>
            <p className="text-[11px] tracking-label uppercase text-muted">The house</p>
            <h2 className="mt-4 font-display text-3xl font-semibold md:text-5xl">{BRAND.philosophy}</h2>
          </div>
          <p className="max-w-xl self-end text-base leading-relaxed text-muted md:text-lg">
            JOKER is built as a uniform, not a costume. Heavy fabrics, oversized cuts, and a palette that doesn't expire
            with the season. Designed in Cairo for a generation that trains, commutes, and lives in the same clothes.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
        <h2 className="font-display text-2xl font-semibold md:text-3xl">Made to last</h2>
        <div className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {QUALITY.map((item) => (
            <div key={item.title} className="border-t border-border pt-6">
              <item.icon className="size-5 text-muted" />
              <h3 className="mt-4 text-sm font-medium">{item.title}</h3>
              <p className="mt-2 text-sm text-muted">{item.copy}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-t border-border bg-bg-elevated">
        <div className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
          <h2 className="font-display text-2xl font-semibold md:text-3xl">What they say</h2>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {REVIEWS.map((review) => (
              <blockquote key={review.id} className="border border-border bg-bg p-6">
                <p className="text-sm leading-relaxed">“{review.quote}”</p>
                <footer className="mt-6 text-xs tracking-label uppercase text-muted">
                  {review.name} · {review.city}
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
        <div className="mb-8 flex items-end justify-between">
          <h2 className="font-display text-2xl font-semibold md:text-3xl">On Instagram</h2>
          <a href={BRAND.instagram} className="text-[11px] tracking-label uppercase text-muted hover:text-fg">
            @joker
          </a>
        </div>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-3 md:gap-3">
          {INSTAGRAM_IMAGES.map((img) => (
            <a key={img.src} href={BRAND.instagram} target="_blank" rel="noreferrer" className="block aspect-square overflow-hidden bg-surface">
              <img src={img.src} alt={img.alt} className="h-full w-full object-cover transition-transform duration-500 hover:scale-105" loading="lazy" />
            </a>
          ))}
        </div>
      </section>

      <Newsletter />
    </div>
  );
}

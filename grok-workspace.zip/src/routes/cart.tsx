import { createFileRoute } from "@tanstack/react-router";
import { CartView } from "@/components/cart/CartView";

export const Route = createFileRoute("/cart")({
  head: () => ({ meta: [{ title: "Cart — JOKER" }] }),
  component: CartPage,
});

function CartPage() {
  return <CartView />;
}

import { X as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route } from "./router-QtDp_Yot.mjs";
import { t as ShopView } from "./ShopView-DzhFmcnE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shop._category-BvqFOzck.js
var import_jsx_runtime = require_jsx_runtime();
function ShopCategory() {
	const { category } = Route.useParams();
	const search = Route.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopView, {
		category,
		search
	});
}
//#endregion
export { ShopCategory as component };

import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Search, X } from "lucide-react";
import { searchSuggestions } from "@/data/products";
import { formatEGP } from "@/lib/format";
import { cn } from "@/lib/utils";
import { useUI } from "@/store/ui";

export function SearchOverlay() {
  const open = useUI((s) => s.searchOpen);
  const setSearchOpen = useUI((s) => s.setSearchOpen);
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  const results = useMemo(() => searchSuggestions(query), [query]);

  useEffect(() => {
    if (open) {
      setQuery("");
      const t = window.setTimeout(() => inputRef.current?.focus(), 40);
      return () => window.clearTimeout(t);
    }
  }, [open]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") setSearchOpen(false);
    }
    if (open) window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, setSearchOpen]);

  function submit(event: React.FormEvent) {
    event.preventDefault();
    const q = query.trim();
    if (!q) return;
    setSearchOpen(false);
    void navigate({ to: "/search", search: { q } });
  }

  return (
    <div className={cn("fixed inset-0 z-50", open ? "" : "pointer-events-none")}>
      <button
        type="button"
        aria-label="Close search"
        className={cn(
          "absolute inset-0 bg-bg/80 transition-opacity duration-200",
          open ? "opacity-100" : "opacity-0",
        )}
        onClick={() => setSearchOpen(false)}
      />
      <div
        className={cn(
          "absolute inset-x-0 top-0 bg-bg-elevated px-4 pt-6 pb-8 shadow-2xl transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] md:px-6",
          open ? "translate-y-0" : "-translate-y-full",
        )}
      >
        <div className="mx-auto max-w-3xl">
          <form onSubmit={submit} className="flex items-center gap-3 border-b border-border">
            <Search className="size-5 text-muted" />
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search JOKER"
              className="h-14 flex-1 bg-transparent text-lg text-fg outline-none placeholder:text-subtle"
            />
            <button type="button" className="size-11" onClick={() => setSearchOpen(false)} aria-label="Close search">
              <X className="size-5" />
            </button>
          </form>
          <div className="mt-6">
            {query.trim() && results.length === 0 ? (
              <p className="text-sm text-muted">No results for “{query.trim()}”.</p>
            ) : null}
            {results.length > 0 ? (
              <ul className="space-y-2">
                {results.map((product) => (
                  <li key={product.id}>
                    <Link
                      to="/product/$slug"
                      params={{ slug: product.slug }}
                      onClick={() => setSearchOpen(false)}
                      className="flex items-center gap-4 px-1 py-2 transition-colors hover:bg-surface"
                    >
                      <img
                        src={product.images[0]}
                        alt=""
                        className="size-16 object-cover bg-surface"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm">{product.name}</p>
                        <p className="text-xs text-muted">{product.colors[0]?.name}</p>
                      </div>
                      <p className="text-sm tabular-nums">{formatEGP(product.price)}</p>
                    </Link>
                  </li>
                ))}
              </ul>
            ) : null}
            {query.trim() && results.length > 0 ? (
              <button
                type="submit"
                onClick={submit}
                className="mt-4 text-xs tracking-label uppercase text-muted hover:text-fg"
              >
                View all results
              </button>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { CartLine } from "@/store/cart";

export type CheckoutCustomer = {
  fullName: string;
  mobile: string;
  governorate: string;
  city: string;
  address: string;
  building: string;
  apartment: string;
  notes?: string;
};

export type Order = {
  id: string;
  createdAt: string;
  customer: CheckoutCustomer;
  items: CartLine[];
  subtotal: number;
  shipping: number;
  discount: number;
  total: number;
  promoCode?: string;
  payment: "cod";
};

type OrdersState = {
  orders: Order[];
  addOrder: (order: Order) => void;
};

export const useOrders = create<OrdersState>()(
  persist(
    (set) => ({
      orders: [],
      addOrder: (order) => set((state) => ({ orders: [order, ...state.orders] })),
    }),
    { name: "joker-orders" },
  ),
);

export function createOrderId() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let body = "";
  for (let i = 0; i < 6; i += 1) body += alphabet[Math.floor(Math.random() * alphabet.length)];
  return `JKR-${body}`;
}

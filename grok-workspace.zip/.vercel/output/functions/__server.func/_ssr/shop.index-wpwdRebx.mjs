import { X as require_jsx_runtime, b as getRouteApi } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as ShopView } from "./ShopView-DzhFmcnE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shop.index-wpwdRebx.js
var import_jsx_runtime = require_jsx_runtime();
var shopRoute = getRouteApi("/shop");
function ShopIndex() {
	const search = shopRoute.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopView, {
		category: "all",
		search
	});
}
//#endregion
export { ShopIndex as component };

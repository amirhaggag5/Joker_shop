import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/$")({
  component: CatchAll,
});

function CatchAll() {
  return (
    <div className="mx-auto max-w-xl px-4 py-24 text-center">
      <p className="text-[11px] tracking-label uppercase text-muted">404</p>
      <h1 className="mt-3 font-display text-4xl font-semibold">This page doesn't exist.</h1>
      <a
        href="/shop"
        className="mt-8 inline-flex h-12 items-center bg-fg px-6 text-xs font-medium tracking-label uppercase text-bg"
      >
        Back to shop
      </a>
    </div>
  );
}

import { X as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as BRAND } from "./config-DAONyBRW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-Bb4FrQ8h.js
var import_jsx_runtime = require_jsx_runtime();
function TermsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-4 py-16 md:py-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl font-semibold",
			children: "Terms"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 space-y-4 text-sm leading-relaxed text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"By placing an order you agree to pay the total shown — including shipping unless the order qualifies for free shipping over ",
					BRAND.freeShippingThreshold.toLocaleString("en-EG"),
					" EGP — in cash to the courier."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Promo codes cannot be stacked. Some codes are one-time, some require a minimum subtotal, and expired codes will be rejected at the cart." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"Colours can shift slightly on screens. Size charts are measurements of the garment, not the body. If a piece is the wrong size and still unworn, the ",
					BRAND.returnWindowDays,
					"-day exchange window applies."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "JOKER may refuse orders that look fraudulent or that we cannot fulfil." })
			]
		})]
	});
}
//#endregion
export { TermsPage as component };

import { X as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as BRAND } from "./config-DAONyBRW.mjs";
import { t as SizeGuideTable } from "./SizeGuideTable-B1cPOWUZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shipping-4so_zW0v.js
var import_jsx_runtime = require_jsx_runtime();
function ShippingPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-4 py-16 md:py-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl font-semibold",
				children: "Shipping & Returns"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 space-y-3 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl text-fg",
						children: "Shipping"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"We ship to every governorate in Egypt. Delivery in ",
						BRAND.estimatedDelivery.toLowerCase(),
						"."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Standard shipping is ",
						BRAND.shippingFee,
						" EGP. Orders over ",
						BRAND.freeShippingThreshold.toLocaleString("en-EG"),
						" EGP ship free."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Payment is cash on delivery. You pay the courier when the order arrives. We do not collect card details." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 space-y-3 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl text-fg",
						children: "Returns & exchanges"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"You have ",
						BRAND.returnWindowDays,
						" days from delivery to return or exchange an unworn item with tags attached. Items that have been washed, damaged, or worn cannot be returned."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Message us on WhatsApp with your order number. We'll arrange a pickup in Cairo/Giza or a courier return elsewhere. Refunds for COD orders are issued as store credit or cash on the exchange delivery." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Size guide"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 mb-6 text-sm text-muted",
						children: "Measurements in centimetres. Oversized cut."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SizeGuideTable, {})
				]
			})
		]
	});
}
//#endregion
export { ShippingPage as component };

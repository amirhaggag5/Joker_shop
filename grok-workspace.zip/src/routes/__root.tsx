import { HeadContent, Outlet, Scripts, createRootRoute } from "@tanstack/react-router";
import { Toaster } from "sonner";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { SiteShell } from "@/components/layout/SiteShell";
import { AppErrorComponent } from "@/lib/error-component";
import appCss from "../styles.css?url";

const APP_NAME = "JOKER";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "JOKER — Built for your everyday." },
      {
        name: "description",
        content:
          "JOKER is a youth streetwear house. Oversized tees, heavyweight hoodies and everyday sportswear. Cash on delivery across Egypt.",
      },
      { name: "theme-color", content: "#0A0A0A" },
      { name: "keywords", content: "JOKER, streetwear, oversized t-shirt, hoodie, Egypt, cash on delivery" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&family=Syne:wght@600;700;800&display=swap",
      },
    ],
  }),
  errorComponent: AppErrorComponent,
  notFoundComponent: NotFound,
  component: RootDocument,
});

function RootDocument() {
  return (
    <html lang="en" className="antialiased" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body className="bg-bg text-fg">
        <PreviewHostBridge />
        <AuthProvider>
          <SiteShell>
            <Outlet />
          </SiteShell>
          <Toaster
            theme="dark"
            position="top-center"
            toastOptions={{
              className: "font-sans",
              style: { background: "#111111", border: "1px solid #262626", color: "#f3f3f0" },
            }}
          />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  );
}

function NotFound() {
  return (
    <div className="mx-auto max-w-xl px-4 py-24 text-center">
      <p className="text-[11px] tracking-label uppercase text-muted">404</p>
      <h1 className="mt-3 font-display text-4xl font-semibold">This page doesn't exist.</h1>
      <p className="mt-3 text-sm text-muted">The drop you're looking for has moved.</p>
      <a href="/shop" className="mt-8 inline-flex h-12 items-center bg-fg px-6 text-xs font-medium tracking-label uppercase text-bg">
        Back to shop
      </a>
    </div>
  );
}

import { createFileRoute, getRouteApi } from "@tanstack/react-router";
import { ShopView } from "@/components/shop/ShopView";

const shopRoute = getRouteApi("/shop");

export const Route = createFileRoute("/shop/")({
  head: () => ({
    meta: [
      { title: "Shop — JOKER" },
      {
        name: "description",
        content:
          "Shop JOKER oversized tees, hoodies and cargos. Free shipping over 1000 EGP. Cash on delivery.",
      },
    ],
  }),
  component: ShopIndex,
});

function ShopIndex() {
  const search = shopRoute.useSearch();
  return <ShopView category="all" search={search} />;
}

import { X as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as SIZE_GUIDE } from "./router-QtDp_Yot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/SizeGuideTable-B1cPOWUZ.js
var import_jsx_runtime = require_jsx_runtime();
function SizeGuideTable() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-x-auto",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full min-w-80 text-left text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-b border-border text-[11px] uppercase tracking-label text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-3 pr-4 font-medium",
						children: "Size"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-3 pr-4 font-medium",
						children: "Chest"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-3 pr-4 font-medium",
						children: "Length"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-3 font-medium",
						children: "Shoulder"
					})
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: SIZE_GUIDE.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-b border-border/70 text-fg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-3 pr-4 font-medium",
						children: row.size
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "py-3 pr-4 tabular-nums",
						children: [row.chest, " cm"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "py-3 pr-4 tabular-nums",
						children: [row.length, " cm"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "py-3 tabular-nums",
						children: [row.shoulder, " cm"]
					})
				]
			}, row.size)) })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-xs text-muted",
			children: "Oversized fit. If you are between sizes, take the smaller one for a cleaner drape."
		})]
	});
}
//#endregion
export { SizeGuideTable as t };

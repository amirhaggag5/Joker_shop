import { Link } from "@tanstack/react-router";
import { X } from "lucide-react";
import { SHOP_CATEGORIES } from "@/data/products";
import { cn } from "@/lib/utils";
import { useUI } from "@/store/ui";

export function MobileMenu() {
  const open = useUI((s) => s.menuOpen);
  const setMenuOpen = useUI((s) => s.setMenuOpen);
  const setSearchOpen = useUI((s) => s.setSearchOpen);

  return (
    <div className={cn("fixed inset-0 z-50 md:hidden", open ? "" : "pointer-events-none")}>
      <button
        type="button"
        className={cn(
          "absolute inset-0 bg-bg/70 transition-opacity duration-200",
          open ? "opacity-100" : "opacity-0",
        )}
        onClick={() => setMenuOpen(false)}
        aria-label="Close menu"
      />
      <aside
        className={cn(
          "absolute inset-y-0 left-0 flex w-[min(100%,20rem)] flex-col bg-bg-elevated px-6 py-5 transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex items-center justify-between">
          <p className="font-display text-lg font-extrabold tracking-brand">JOKER</p>
          <button type="button" className="size-11" onClick={() => setMenuOpen(false)} aria-label="Close menu">
            <X className="size-5" />
          </button>
        </div>
        <nav className="mt-10 flex flex-col gap-1">
          {SHOP_CATEGORIES.map((cat) =>
            cat.slug === "all" ? (
              <Link key={cat.slug} to="/shop" className="py-3 font-display text-2xl font-semibold" onClick={() => setMenuOpen(false)}>
                {cat.label}
              </Link>
            ) : (
              <Link
                key={cat.slug}
                to="/shop/$category"
                params={{ category: cat.slug }}
                className="py-3 font-display text-2xl font-semibold"
                onClick={() => setMenuOpen(false)}
              >
                {cat.label}
              </Link>
            ),
          )}
        </nav>
        <div className="mt-auto space-y-3 pb-6 text-sm text-muted">
          <button
            type="button"
            className="block py-2 text-fg"
            onClick={() => {
              setMenuOpen(false);
              setSearchOpen(true);
            }}
          >
            Search
          </button>
          <Link to="/about" onClick={() => setMenuOpen(false)} className="block py-2">
            About
          </Link>
          <Link to="/contact" onClick={() => setMenuOpen(false)} className="block py-2">
            Contact
          </Link>
          <Link to="/shipping" onClick={() => setMenuOpen(false)} className="block py-2">
            Shipping & Returns
          </Link>
        </div>
      </aside>
    </div>
  );
}

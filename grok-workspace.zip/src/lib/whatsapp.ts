import { BRAND, whatsappUrl } from "@/lib/config";
import { formatEGP } from "@/lib/format";
import type { CartLine } from "@/store/cart";
import type { Order } from "@/store/orders";

export function orderWhatsAppMessage(order: Order) {
  const lines = [
    `New JOKER order`,
    `Order number: ${order.id}`,
    `Customer: ${order.customer.fullName}`,
    `Phone: ${order.customer.mobile}`,
    ``,
    `Products:`,
    ...order.items.map(
      (item) =>
        `• ${item.name} — ${item.color} / ${item.size} × ${item.quantity} — ${formatEGP(item.price * item.quantity)}`,
    ),
    ``,
    `Total: ${formatEGP(order.total)}`,
    `Payment: Cash on Delivery`,
    `Address: ${order.customer.address}, Bldg ${order.customer.building}, Apt ${order.customer.apartment}, ${order.customer.city}, ${order.customer.governorate}`,
  ];
  if (order.customer.notes) lines.push(`Notes: ${order.customer.notes}`);
  return lines.join("\n");
}

export function orderWhatsAppLink(order: Order) {
  return whatsappUrl(orderWhatsAppMessage(order));
}

export function cartWhatsAppPreview(items: CartLine[], total: number) {
  return whatsappUrl(
    `Hi ${BRAND.name}, I want to order:\n${items
      .map((i) => `• ${i.name} ${i.color}/${i.size} × ${i.quantity}`)
      .join("\n")}\nTotal: ${formatEGP(total)}`,
  );
}

import type { InputHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "h-12 w-full border border-border bg-bg-elevated px-4 text-sm text-fg placeholder:text-subtle outline-none transition-colors duration-150 focus:border-fg",
        className,
      )}
      {...props}
    />
  );
}

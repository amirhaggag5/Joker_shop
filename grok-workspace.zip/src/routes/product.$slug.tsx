import { createFileRoute, notFound } from "@tanstack/react-router";
import { ProductDetail } from "@/components/product/ProductDetail";
import { getProductBySlug } from "@/data/products";

export const Route = createFileRoute("/product/$slug")({
  loader: ({ params }) => {
    const product = getProductBySlug(params.slug);
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.product.name ?? "Product"} — JOKER` },
      {
        name: "description",
        content: loaderData?.product.description ?? "JOKER streetwear.",
      },
    ],
  }),
  component: ProductPage,
});

function ProductPage() {
  const { product } = Route.useLoaderData();
  return <ProductDetail product={product} />;
}

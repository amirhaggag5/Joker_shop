export const REVIEWS = [
  {
    id: "r1",
    name: "Karim A.",
    city: "New Cairo",
    quote: "The oversized tee actually fits. Heavy fabric — not that thin mall stuff. Wearing it every other day.",
    product: "Core Oversized Tee",
  },
  {
    id: "r2",
    name: "Layla M.",
    city: "Alexandria",
    quote: "Hoodie is dense, warm, and the cut is right. Ordered a second colour the same week.",
    product: "Essential Hoodie",
  },
  {
    id: "r3",
    name: "Omar H.",
    city: "6th of October",
    quote: "Clean pieces. Nothing loud. Exactly what I wanted for the gym and the street.",
    product: "Heavyweight Box Tee",
  },
  {
    id: "r4",
    name: "Nour S.",
    city: "Maadi",
    quote: "Cash on delivery, fast in Cairo, and the cargo is better in person than on the site.",
    product: "Utility Cargo",
  },
  {
    id: "r5",
    name: "Youssef K.",
    city: "Mansoura",
    quote: "Acid wash came with a real texture. Looks expensive without trying.",
    product: "Acid Wash Tee",
  },
  {
    id: "r6",
    name: "Farida T.",
    city: "Sheikh Zayed",
    quote: "JOKER feels like a proper brand, not a random drop page. I'll keep buying.",
    product: "Jester Tee",
  },
] as const;

export const BRAND = {
  name: "JOKER",
  tagline: "BUILT FOR YOUR EVERYDAY.",
  philosophy: "Designed for the way you move, train and live.",
  description:
    "JOKER is a youth streetwear house from Egypt. Oversized tees, heavyweight hoodies and everyday sportswear — cut clean, built to last.",
  whatsapp: "201012345678",
  instagram: "https://instagram.com/joker",
  tiktok: "https://www.tiktok.com/@joker",
  email: "hello@joker.store",
  currency: "EGP",
  freeShippingThreshold: 1000,
  shippingFee: 70,
  estimatedDelivery: "2–5 business days across Egypt",
  returnWindowDays: 14,
} as const;

export function whatsappUrl(text?: string) {
  const base = `https://wa.me/${BRAND.whatsapp}`;
  if (!text) return `${base}?text=${encodeURIComponent("Hi JOKER — I have a question about an order.")}`;
  return `${base}?text=${encodeURIComponent(text)}`;
}

import { X as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as ProductCard } from "./ProductCard-C0R-tK-9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ProductGrid-CHQwFaA8.js
var import_jsx_runtime = require_jsx_runtime();
function ProductGrid({ products }) {
	if (products.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border border-border px-6 py-20 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-xl",
			children: "No pieces match these filters."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Clear a filter or browse the full collection."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-x-3 gap-y-10 md:grid-cols-3 md:gap-x-6 lg:grid-cols-4",
		children: products.map((product, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, {
			product,
			priority: index < 4
		}, product.id))
	});
}
//#endregion
export { ProductGrid as t };

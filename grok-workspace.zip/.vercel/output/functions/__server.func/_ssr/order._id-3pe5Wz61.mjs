import { X as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as whatsappUrl, t as BRAND } from "./config-DAONyBRW.mjs";
import { t as Button } from "./button-Bv-N6FT1.mjs";
import { i as Route$3, o as useMounted, u as formatEGP } from "./router-QtDp_Yot.mjs";
import { n as useOrders } from "./orders-fH9KXyrh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/order._id-3pe5Wz61.js
var import_jsx_runtime = require_jsx_runtime();
function orderWhatsAppMessage(order) {
	const lines = [
		`New JOKER order`,
		`Order number: ${order.id}`,
		`Customer: ${order.customer.fullName}`,
		`Phone: ${order.customer.mobile}`,
		``,
		`Products:`,
		...order.items.map((item) => `• ${item.name} — ${item.color} / ${item.size} × ${item.quantity} — ${formatEGP(item.price * item.quantity)}`),
		``,
		`Total: ${formatEGP(order.total)}`,
		`Payment: Cash on Delivery`,
		`Address: ${order.customer.address}, Bldg ${order.customer.building}, Apt ${order.customer.apartment}, ${order.customer.city}, ${order.customer.governorate}`
	];
	if (order.customer.notes) lines.push(`Notes: ${order.customer.notes}`);
	return lines.join("\n");
}
function orderWhatsAppLink(order) {
	return whatsappUrl(orderWhatsAppMessage(order));
}
function OrderConfirmation({ order }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl px-4 py-16 md:py-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] tracking-label uppercase text-success",
				children: "Cash on delivery"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl font-semibold md:text-5xl",
				children: "Order confirmed"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm text-muted",
				children: [
					"We'll call to confirm, then ship. Estimated delivery: ",
					BRAND.estimatedDelivery.toLowerCase(),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-10 space-y-3 border border-border bg-bg-elevated p-6 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "Order number"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-medium tabular-nums",
							children: order.id
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "Customer"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: order.customer.fullName })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "Phone"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "tabular-nums",
							children: order.customer.mobile
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "Total"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "tabular-nums",
							children: formatEGP(order.total)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "Payment"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: "Cash on Delivery" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted",
						children: "Delivery"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1",
						children: [
							order.customer.address,
							", Bldg ",
							order.customer.building,
							", Apt ",
							order.customer.apartment,
							", ",
							order.customer.city,
							",",
							" ",
							order.customer.governorate
						]
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 divide-y divide-border border-y border-border text-sm",
				children: order.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						item.name,
						" · ",
						item.color,
						"/",
						item.size,
						" × ",
						item.quantity
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: formatEGP(item.price * item.quantity)
					})]
				}, item.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-col gap-3 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shop",
						children: "Continue shopping"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: orderWhatsAppLink(order),
						target: "_blank",
						rel: "noreferrer",
						children: "Contact us on WhatsApp"
					})
				})]
			})
		]
	});
}
function OrderPage() {
	const { id } = Route$3.useParams();
	const mounted = useMounted();
	const order = useOrders((s) => s.orders.find((o) => o.id === id));
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-4 py-24 text-center text-sm text-muted",
		children: "Loading order…"
	});
	if (!order) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl px-4 py-24 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold",
				children: "Order not found"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "This confirmation lives on the device that placed it."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-8",
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/shop",
					children: "Continue shopping"
				})
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderConfirmation, { order });
}
//#endregion
export { OrderPage as component };

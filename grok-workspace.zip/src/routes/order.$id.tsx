import { createFileRoute, Link } from "@tanstack/react-router";
import { OrderConfirmation } from "@/components/order/OrderConfirmation";
import { Button } from "@/components/ui/button";
import { useOrders } from "@/store/orders";
import { useMounted } from "@/hooks/use-mounted";

export const Route = createFileRoute("/order/$id")({
  head: () => ({ meta: [{ title: "Order confirmed — JOKER" }] }),
  component: OrderPage,
});

function OrderPage() {
  const { id } = Route.useParams();
  const mounted = useMounted();
  const order = useOrders((s) => s.orders.find((o) => o.id === id));

  if (!mounted) {
    return <div className="px-4 py-24 text-center text-sm text-muted">Loading order…</div>;
  }

  if (!order) {
    return (
      <div className="mx-auto max-w-xl px-4 py-24 text-center">
        <h1 className="font-display text-3xl font-semibold">Order not found</h1>
        <p className="mt-3 text-sm text-muted">This confirmation lives on the device that placed it.</p>
        <Button className="mt-8" asChild>
          <Link to="/shop">Continue shopping</Link>
        </Button>
      </div>
    );
  }

  return <OrderConfirmation order={order} />;
}

import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — JOKER" },
      { name: "description", content: "How JOKER handles your order details." },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <article className="mx-auto max-w-3xl px-4 py-16 md:py-24">
      <h1 className="font-display text-4xl font-semibold">Privacy Policy</h1>
      <div className="mt-8 space-y-4 text-sm leading-relaxed text-muted">
        <p>
          We collect only what we need to deliver your order: name, mobile number, and address. Orders placed in this
          store are saved on your device so you can view the confirmation. We do not sell your data.
        </p>
        <p>
          Newsletter emails are stored so we can send drop notices. You can stop by ignoring them — we don't buy lists
          and we don't share yours.
        </p>
        <p>
          WhatsApp conversations follow WhatsApp's own terms. Don't send payment cards in chat; we never ask for them.
        </p>
        <p>Questions: hello@joker.store</p>
      </div>
    </article>
  );
}

import { i as __toESM } from "../_runtime.mjs";
import { S as useNavigate, X as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { n as cn, t as Button } from "./button-Bv-N6FT1.mjs";
import { i as SlidersHorizontal, t as X } from "../_libs/lucide-react.mjs";
import { C as sortProducts, _ as SORT_OPTIONS, b as filterProducts, h as SIZES, m as SHOP_CATEGORIES, v as allColors } from "./router-QtDp_Yot.mjs";
import { t as ProductGrid } from "./ProductGrid-CHQwFaA8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ShopView-DzhFmcnE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ShopView({ category = "all", search }) {
	const navigate = useNavigate();
	const [filtersOpen, setFiltersOpen] = (0, import_react.useState)(false);
	const sort = search.sort ?? "featured";
	const colors = allColors();
	const products = (0, import_react.useMemo)(() => sortProducts(filterProducts({
		category,
		size: search.size,
		color: search.color,
		min: search.min,
		max: search.max
	}), sort), [
		category,
		search.size,
		search.color,
		search.min,
		search.max,
		sort
	]);
	const activeCategory = SHOP_CATEGORIES.find((c) => c.slug === category) ?? SHOP_CATEGORIES[0];
	function patch(next) {
		const merged = {
			...search,
			...next
		};
		const clean = {};
		if (merged.size) clean.size = merged.size;
		if (merged.color) clean.color = merged.color;
		if (merged.min != null) clean.min = merged.min;
		if (merged.max != null) clean.max = merged.max;
		if (merged.sort && merged.sort !== "featured") clean.sort = merged.sort;
		if (category && category !== "all") navigate({
			to: "/shop/$category",
			params: { category },
			search: clean
		});
		else navigate({
			to: "/shop",
			search: clean
		});
	}
	const filterBody = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] tracking-label uppercase text-subtle",
				children: "Category"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-1.5",
				children: SHOP_CATEGORIES.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: cat.slug === "all" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/shop",
					search,
					className: cn("text-sm", cat.slug === category ? "text-fg" : "text-muted hover:text-fg"),
					onClick: () => setFiltersOpen(false),
					children: cat.label
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/shop/$category",
					params: { category: cat.slug },
					search,
					className: cn("text-sm", cat.slug === category ? "text-fg" : "text-muted hover:text-fg"),
					onClick: () => setFiltersOpen(false),
					children: cat.label
				}) }, cat.slug))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] tracking-label uppercase text-subtle",
				children: "Size"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-1.5",
				children: SIZES.map((size) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => patch({ size: search.size === size ? void 0 : size }),
					className: cn("h-10 min-w-10 border px-2 text-xs", search.size === size ? "border-fg bg-fg text-bg" : "border-border hover:border-fg"),
					children: size
				}, size))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] tracking-label uppercase text-subtle",
				children: "Color"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-2",
				children: colors.map((color) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => patch({ color: search.color === color.name ? void 0 : color.name }),
					className: "flex items-center gap-2 text-sm text-muted hover:text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("size-4 rounded-full border", search.color === color.name ? "border-fg" : "border-border-strong"),
						style: { background: color.hex }
					}), color.name]
				}) }, color.name))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] tracking-label uppercase text-subtle",
				children: "Price"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "number",
					min: 0,
					placeholder: "Min",
					defaultValue: search.min ?? "",
					onBlur: (e) => {
						const value = e.target.value ? Number(e.target.value) : void 0;
						patch({ min: Number.isFinite(value) ? value : void 0 });
					},
					className: "h-11 border border-border bg-bg px-3 text-sm outline-none focus:border-fg"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "number",
					min: 0,
					placeholder: "Max",
					defaultValue: search.max ?? "",
					onBlur: (e) => {
						const value = e.target.value ? Number(e.target.value) : void 0;
						patch({ max: Number.isFinite(value) ? value : void 0 });
					},
					className: "h-11 border border-border bg-bg px-3 text-sm outline-none focus:border-fg"
				})]
			})] }),
			(search.size || search.color || search.min != null || search.max != null) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-xs tracking-label uppercase text-muted hover:text-fg",
				onClick: () => patch({
					size: void 0,
					color: void 0,
					min: void 0,
					max: void 0,
					sort: search.sort
				}),
				children: "Clear filters"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl px-4 py-10 md:px-6 md:py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] tracking-label uppercase text-muted",
					children: "Shop"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-4xl font-semibold md:text-5xl",
					children: activeCategory.label
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [products.length, " pieces"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						className: "lg:hidden",
						onClick: () => setFiltersOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-3.5" }), "Filter"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "Sort"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: sort,
							onChange: (e) => patch({ sort: e.target.value }),
							className: "h-10 border border-border bg-bg px-3 text-xs text-fg outline-none",
							children: SORT_OPTIONS.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: opt.value,
								children: opt.label
							}, opt.value))
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-10 lg:grid-cols-[220px_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "hidden lg:block",
					children: filterBody
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, { products })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("fixed inset-0 z-50 lg:hidden", filtersOpen ? "" : "pointer-events-none"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("absolute inset-0 bg-bg/70 transition-opacity duration-200", filtersOpen ? "opacity-100" : "opacity-0"),
					onClick: () => setFiltersOpen(false),
					"aria-label": "Close filters"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: cn("absolute inset-y-0 left-0 w-[min(100%,20rem)] overflow-y-auto bg-bg-elevated p-5 transition-transform duration-300", filtersOpen ? "translate-x-0" : "-translate-x-full"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-6 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm tracking-label uppercase",
							children: "Filters"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "size-10",
							onClick: () => setFiltersOpen(false),
							"aria-label": "Close filters",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})]
					}), filterBody]
				})]
			})
		]
	});
}
//#endregion
export { ShopView as t };

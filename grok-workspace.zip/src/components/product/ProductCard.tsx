import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import type { Product } from "@/data/products";
import { formatEGP } from "@/lib/format";
import { cn } from "@/lib/utils";
import { useCart } from "@/store/cart";
import { useUI } from "@/store/ui";

export function ProductCard({ product, priority = false }: { product: Product; priority?: boolean }) {
  const [sizeOpen, setSizeOpen] = useState(false);
  const addItem = useCart((s) => s.addItem);
  const setCartOpen = useUI((s) => s.setCartOpen);
  const color = product.colors[0];
  const soldOut = product.stock <= 0;

  function add(size: string) {
    if (!color) return;
    addItem({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      image: product.images[0] ?? "",
      size,
      color: color.name,
      colorHex: color.hex,
      price: product.price,
    });
    toast.success("Added to cart", { description: `${product.name} · ${size}` });
    setSizeOpen(false);
    setCartOpen(true);
  }

  return (
    <article className="group relative">
      <Link to="/product/$slug" params={{ slug: product.slug }} className="block">
        <div className="relative aspect-product overflow-hidden bg-surface">
          <img
            src={product.images[0]}
            alt={`${product.name} in ${color?.name ?? "black"}`}
            className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.04]"
            loading={priority ? "eager" : "lazy"}
            fetchPriority={priority ? "high" : "auto"}
          />
          {product.badge ? (
            <Badge className="absolute top-3 left-3">{product.badge}</Badge>
          ) : null}
          {soldOut ? (
            <div className="absolute inset-0 flex items-center justify-center bg-bg/50 text-xs tracking-label uppercase">
              Sold out
            </div>
          ) : null}
        </div>
        <div className="mt-3 flex items-start justify-between gap-3">
          <div>
            <h3 className="text-sm font-medium text-fg">{product.name}</h3>
            <p className="mt-0.5 text-xs text-muted">{color?.name}</p>
          </div>
          <div className="text-right text-sm tabular-nums">
            <p>{formatEGP(product.price)}</p>
            {product.oldPrice ? (
              <p className="text-xs text-muted line-through">{formatEGP(product.oldPrice)}</p>
            ) : null}
          </div>
        </div>
      </Link>
      {!soldOut ? (
        <div className="mt-3">
          {sizeOpen ? (
            <div className="flex flex-wrap gap-1.5">
              {product.sizes.map((size) => (
                <button
                  key={size}
                  type="button"
                  onClick={() => add(size)}
                  className="h-10 min-w-10 border border-border px-2 text-xs text-fg transition-colors hover:border-fg hover:bg-fg hover:text-bg"
                >
                  {size}
                </button>
              ))}
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setSizeOpen(true)}
              className={cn(
                "h-11 w-full border border-border text-[11px] font-medium tracking-label uppercase text-fg transition-colors hover:bg-fg hover:text-bg",
                "md:opacity-0 md:transition-opacity md:duration-200 md:group-hover:opacity-100",
              )}
            >
              Quick add
            </button>
          )}
        </div>
      ) : null}
    </article>
  );
}

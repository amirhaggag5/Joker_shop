import { Link } from "@tanstack/react-router";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { QuantitySelector } from "@/components/product/QuantitySelector";
import { BRAND } from "@/lib/config";
import { formatEGP } from "@/lib/format";
import { cn } from "@/lib/utils";
import { useCart, useCartTotals } from "@/store/cart";
import { useUI } from "@/store/ui";

export function CartDrawer() {
  const open = useUI((s) => s.cartOpen);
  const setCartOpen = useUI((s) => s.setCartOpen);
  const items = useCart((s) => s.items);
  const setQuantity = useCart((s) => s.setQuantity);
  const removeItem = useCart((s) => s.removeItem);
  const totals = useCartTotals();

  return (
    <div className={cn("fixed inset-0 z-50", open ? "" : "pointer-events-none")}>
      <button
        type="button"
        aria-label="Close cart"
        className={cn(
          "absolute inset-0 bg-bg/70 transition-opacity duration-200",
          open ? "opacity-100" : "opacity-0",
        )}
        onClick={() => setCartOpen(false)}
      />
      <aside
        className={cn(
          "absolute inset-y-0 right-0 flex w-full max-w-md flex-col border-l border-border bg-bg-elevated transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]",
          open ? "translate-x-0" : "translate-x-full",
        )}
      >
        <div className="flex h-16 items-center justify-between border-b border-border px-5">
          <h2 className="text-sm font-medium tracking-label uppercase">Cart</h2>
          <button
            type="button"
            className="flex size-10 items-center justify-center"
            onClick={() => setCartOpen(false)}
            aria-label="Close cart"
          >
            <X className="size-5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 py-5">
          {items.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <p className="font-display text-2xl">Your cart is empty.</p>
              <Button className="mt-6" onClick={() => setCartOpen(false)} asChild>
                <Link to="/shop">Shop now</Link>
              </Button>
            </div>
          ) : (
            <ul className="space-y-5">
              {items.map((item) => (
                <li key={item.key} className="flex gap-4">
                  <Link
                    to="/product/$slug"
                    params={{ slug: item.slug }}
                    onClick={() => setCartOpen(false)}
                    className="block size-24 shrink-0 overflow-hidden bg-surface"
                  >
                    <img src={item.image} alt={item.name} className="h-full w-full object-cover" />
                  </Link>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-sm font-medium">{item.name}</p>
                        <p className="mt-1 text-xs text-muted">
                          {item.color} / {item.size}
                        </p>
                      </div>
                      <p className="text-sm tabular-nums">{formatEGP(item.price * item.quantity)}</p>
                    </div>
                    <div className="mt-3 flex items-center justify-between">
                      <QuantitySelector
                        value={item.quantity}
                        onChange={(qty) => setQuantity(item.key, qty)}
                        className="h-10"
                      />
                      <button
                        type="button"
                        className="text-xs tracking-label uppercase text-muted hover:text-fg"
                        onClick={() => removeItem(item.key)}
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
        {items.length > 0 ? (
          <div className="border-t border-border px-5 py-5">
            {totals.freeShipping ? (
              <p className="mb-3 text-xs tracking-label uppercase text-success">Free shipping</p>
            ) : (
              <p className="mb-3 text-xs text-muted">
                Add {formatEGP(totals.remainingForFreeShipping)} for free shipping.
              </p>
            )}
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted">Subtotal</span>
              <span className="tabular-nums">{formatEGP(totals.subtotal)}</span>
            </div>
            {totals.discount > 0 ? (
              <div className="mt-1 flex items-center justify-between text-sm text-success">
                <span>Discount</span>
                <span className="tabular-nums">-{formatEGP(totals.discount)}</span>
              </div>
            ) : null}
            <div className="mt-3 flex items-center justify-between font-medium">
              <span>Total</span>
              <span className="tabular-nums">{formatEGP(totals.total)}</span>
            </div>
            <p className="mt-2 text-[11px] text-subtle">Shipping calculated at checkout · COD available</p>
            <Button className="mt-4 w-full" size="lg" asChild>
              <Link to="/checkout" onClick={() => setCartOpen(false)}>
                Checkout
              </Link>
            </Button>
            <Button variant="ghost" className="mt-2 w-full" asChild>
              <Link to="/cart" onClick={() => setCartOpen(false)}>
                View cart
              </Link>
            </Button>
            <p className="mt-3 text-center text-[11px] text-subtle">
              Free shipping on orders over {BRAND.freeShippingThreshold.toLocaleString("en-EG")} EGP
            </p>
          </div>
        ) : null}
      </aside>
    </div>
  );
}

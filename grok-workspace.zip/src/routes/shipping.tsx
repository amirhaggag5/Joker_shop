import { createFileRoute } from "@tanstack/react-router";
import { SizeGuideTable } from "@/components/product/SizeGuideTable";
import { BRAND } from "@/lib/config";

export const Route = createFileRoute("/shipping")({
  head: () => ({
    meta: [
      { title: "Shipping & Returns — JOKER" },
      { name: "description", content: "Cash on delivery across Egypt. Free shipping over 1000 EGP. 14-day returns." },
    ],
  }),
  component: ShippingPage,
});

function ShippingPage() {
  return (
    <article className="mx-auto max-w-3xl px-4 py-16 md:py-24">
      <h1 className="font-display text-4xl font-semibold">Shipping & Returns</h1>
      <section className="mt-10 space-y-3 text-sm leading-relaxed text-muted">
        <h2 className="font-display text-2xl text-fg">Shipping</h2>
        <p>We ship to every governorate in Egypt. Delivery in {BRAND.estimatedDelivery.toLowerCase()}.</p>
        <p>Standard shipping is {BRAND.shippingFee} EGP. Orders over {BRAND.freeShippingThreshold.toLocaleString("en-EG")} EGP ship free.</p>
        <p>Payment is cash on delivery. You pay the courier when the order arrives. We do not collect card details.</p>
      </section>
      <section className="mt-10 space-y-3 text-sm leading-relaxed text-muted">
        <h2 className="font-display text-2xl text-fg">Returns & exchanges</h2>
        <p>
          You have {BRAND.returnWindowDays} days from delivery to return or exchange an unworn item with tags attached.
          Items that have been washed, damaged, or worn cannot be returned.
        </p>
        <p>
          Message us on WhatsApp with your order number. We'll arrange a pickup in Cairo/Giza or a courier return
          elsewhere. Refunds for COD orders are issued as store credit or cash on the exchange delivery.
        </p>
      </section>
      <section className="mt-10">
        <h2 className="font-display text-2xl">Size guide</h2>
        <p className="mt-3 mb-6 text-sm text-muted">Measurements in centimetres. Oversized cut.</p>
        <SizeGuideTable />
      </section>
    </article>
  );
}

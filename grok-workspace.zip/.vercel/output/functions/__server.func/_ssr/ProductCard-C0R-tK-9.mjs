import { i as __toESM } from "../_runtime.mjs";
import { X as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { n as cn } from "./button-Bv-N6FT1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as useCart, s as useUI, u as formatEGP } from "./router-QtDp_Yot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ProductCard-C0R-tK-9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Badge({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center bg-fg px-2 py-1 font-sans text-[10px] font-medium uppercase tracking-label text-bg", className),
		children
	});
}
function ProductCard({ product, priority = false }) {
	const [sizeOpen, setSizeOpen] = (0, import_react.useState)(false);
	const addItem = useCart((s) => s.addItem);
	const setCartOpen = useUI((s) => s.setCartOpen);
	const color = product.colors[0];
	const soldOut = product.stock <= 0;
	function add(size) {
		if (!color) return;
		addItem({
			productId: product.id,
			slug: product.slug,
			name: product.name,
			image: product.images[0] ?? "",
			size,
			color: color.name,
			colorHex: color.hex,
			price: product.price
		});
		toast.success("Added to cart", { description: `${product.name} · ${size}` });
		setSizeOpen(false);
		setCartOpen(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/product/$slug",
			params: { slug: product.slug },
			className: "block",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative aspect-product overflow-hidden bg-surface",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: product.images[0],
						alt: `${product.name} in ${color?.name ?? "black"}`,
						className: "h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.04]",
						loading: priority ? "eager" : "lazy",
						fetchPriority: priority ? "high" : "auto"
					}),
					product.badge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						className: "absolute top-3 left-3",
						children: product.badge
					}) : null,
					soldOut ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 flex items-center justify-center bg-bg/50 text-xs tracking-label uppercase",
						children: "Sold out"
					}) : null
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-medium text-fg",
					children: product.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 text-xs text-muted",
					children: color?.name
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right text-sm tabular-nums",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: formatEGP(product.price) }), product.oldPrice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted line-through",
						children: formatEGP(product.oldPrice)
					}) : null]
				})]
			})]
		}), !soldOut ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3",
			children: sizeOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: product.sizes.map((size) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => add(size),
					className: "h-10 min-w-10 border border-border px-2 text-xs text-fg transition-colors hover:border-fg hover:bg-fg hover:text-bg",
					children: size
				}, size))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setSizeOpen(true),
				className: cn("h-11 w-full border border-border text-[11px] font-medium tracking-label uppercase text-fg transition-colors hover:bg-fg hover:text-bg", "md:opacity-0 md:transition-opacity md:duration-200 md:group-hover:opacity-100"),
				children: "Quick add"
			})
		}) : null]
	});
}
//#endregion
export { ProductCard as n, Badge as t };

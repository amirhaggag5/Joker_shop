//#region node_modules/.nitro/vite/services/ssr/assets/config-DAONyBRW.js
var BRAND = {
	name: "JOKER",
	tagline: "BUILT FOR YOUR EVERYDAY.",
	philosophy: "Designed for the way you move, train and live.",
	description: "JOKER is a youth streetwear house from Egypt. Oversized tees, heavyweight hoodies and everyday sportswear — cut clean, built to last.",
	whatsapp: "201012345678",
	instagram: "https://instagram.com/joker",
	tiktok: "https://www.tiktok.com/@joker",
	email: "hello@joker.store",
	currency: "EGP",
	freeShippingThreshold: 1e3,
	shippingFee: 70,
	estimatedDelivery: "2–5 business days across Egypt",
	returnWindowDays: 14
};
function whatsappUrl(text) {
	const base = `https://wa.me/${BRAND.whatsapp}`;
	if (!text) return `${base}?text=${encodeURIComponent("Hi JOKER — I have a question about an order.")}`;
	return `${base}?text=${encodeURIComponent(text)}`;
}
//#endregion
export { whatsappUrl as n, BRAND as t };

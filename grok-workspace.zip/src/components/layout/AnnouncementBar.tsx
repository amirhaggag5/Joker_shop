import { Link } from "@tanstack/react-router";
import { BRAND } from "@/lib/config";

export function AnnouncementBar() {
  return (
    <div className="bg-fg text-bg">
      <p className="flex h-9 items-center justify-center gap-3 px-4 text-[10px] font-medium tracking-label uppercase sm:text-[11px]">
        <span>2 T-Shirts + 1 Free</span>
        <span className="text-bg/40">/</span>
        <Link to="/shop" className="underline-offset-4 hover:underline">
          Free shipping over {BRAND.freeShippingThreshold.toLocaleString("en-EG")} EGP
        </Link>
      </p>
    </div>
  );
}

import { X as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-D3iSkllp.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-4 py-16 md:py-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl font-semibold",
			children: "Privacy Policy"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 space-y-4 text-sm leading-relaxed text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We collect only what we need to deliver your order: name, mobile number, and address. Orders placed in this store are saved on your device so you can view the confirmation. We do not sell your data." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Newsletter emails are stored so we can send drop notices. You can stop by ignoring them — we don't buy lists and we don't share yours." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "WhatsApp conversations follow WhatsApp's own terms. Don't send payment cards in chat; we never ask for them." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Questions: hello@joker.store" })
			]
		})]
	});
}
//#endregion
export { PrivacyPage as component };

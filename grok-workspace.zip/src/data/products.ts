export type ProductColor = {
  name: string;
  hex: string;
};

export type ProductCategory = "t-shirts" | "hoodies" | "pants";

export type ProductBadge = "NEW" | "BEST SELLER" | "SALE";

export type Product = {
  id: string;
  slug: string;
  name: string;
  price: number;
  oldPrice?: number;
  category: ProductCategory;
  oversized: boolean;
  description: string;
  fabric: string;
  details: string[];
  images: string[];
  colors: ProductColor[];
  sizes: string[];
  stock: number;
  badge?: ProductBadge;
  featured: boolean;
  bestSeller: boolean;
  newArrival: boolean;
  family?: string;
  sold: number;
  createdAt: string;
};

export const SIZES = ["S", "M", "L", "XL", "XXL"] as const;

export const SHOP_CATEGORIES = [
  { slug: "all", label: "All" },
  { slug: "t-shirts", label: "T-Shirts" },
  { slug: "oversized", label: "Oversized" },
  { slug: "hoodies", label: "Hoodies" },
  { slug: "pants", label: "Pants" },
  { slug: "new-arrivals", label: "New Arrivals" },
  { slug: "best-sellers", label: "Best Sellers" },
] as const;

export type ShopCategorySlug = (typeof SHOP_CATEGORIES)[number]["slug"];

export const SIZE_GUIDE = [
  { size: "S", chest: 108, length: 70, shoulder: 52 },
  { size: "M", chest: 114, length: 72, shoulder: 54 },
  { size: "L", chest: 120, length: 74, shoulder: 56 },
  { size: "XL", chest: 126, length: 76, shoulder: 58 },
  { size: "XXL", chest: 132, length: 78, shoulder: 60 },
] as const;

const TEE_DETAILS = [
  "Oversized dropped-shoulder cut",
  "Ribbed collar that holds its shape",
  "Double-needle hem and sleeves",
  "Pre-shrunk heavyweight cotton",
];

const HOODIE_DETAILS = [
  "Kangaroo pocket",
  "Ribbed cuffs and hem",
  "Lined hood",
  "Heavyweight fleece, brushed inside",
];

/**
 * JOKER catalog.
 * Add a product by appending an object below.
 * Drop images in /public/products and set images: ["/products/your-file.jpg"].
 */
export const PRODUCTS: Product[] = [
  {
    id: "p01",
    slug: "core-oversized-tee-black",
    name: "Core Oversized Tee",
    price: 449,
    oldPrice: 599,
    category: "t-shirts",
    oversized: true,
    family: "core-tee",
    description:
      "The daily uniform. A heavyweight oversized tee with dropped shoulders and a clean set-in neckline — cut to move with you from morning training to late hours in the city.",
    fabric: "280 GSM combed cotton. Soft hand, dense drape, pre-shrunk.",
    details: TEE_DETAILS,
    images: ["/products/core-tee-black.jpg", "/products/core-tee-black-detail.jpg"],
    colors: [{ name: "Black", hex: "#111111" }],
    sizes: [...SIZES],
    stock: 42,
    badge: "BEST SELLER",
    featured: true,
    bestSeller: true,
    newArrival: false,
    sold: 860,
    createdAt: "2026-06-12",
  },
  {
    id: "p02",
    slug: "core-oversized-tee-off-white",
    name: "Core Oversized Tee",
    price: 449,
    category: "t-shirts",
    oversized: true,
    family: "core-tee",
    description:
      "The same core cut in off-white. Heavy cotton, relaxed through the body, made to be worn on repeat.",
    fabric: "280 GSM combed cotton. Soft hand, dense drape, pre-shrunk.",
    details: TEE_DETAILS,
    images: ["/products/core-tee-white.jpg", "/products/core-tee-white-detail.jpg"],
    colors: [{ name: "Off White", hex: "#E8E4DC" }],
    sizes: [...SIZES],
    stock: 28,
    badge: "NEW",
    featured: true,
    bestSeller: false,
    newArrival: true,
    sold: 210,
    createdAt: "2026-08-20",
  },
  {
    id: "p03",
    slug: "core-oversized-tee-navy",
    name: "Core Oversized Tee",
    price: 449,
    category: "t-shirts",
    oversized: true,
    family: "core-tee",
    description:
      "Core oversized tee in deep navy. A darker alternative that still reads clean under any light.",
    fabric: "280 GSM combed cotton. Soft hand, dense drape, pre-shrunk.",
    details: TEE_DETAILS,
    images: ["/products/core-tee-navy.jpg", "/products/core-tee-navy-detail.jpg"],
    colors: [{ name: "Navy", hex: "#1E2A4A" }],
    sizes: [...SIZES],
    stock: 31,
    featured: false,
    bestSeller: false,
    newArrival: false,
    sold: 340,
    createdAt: "2026-07-02",
  },
  {
    id: "p04",
    slug: "heavyweight-box-tee-black",
    name: "Heavyweight Box Tee",
    price: 529,
    oldPrice: 649,
    category: "t-shirts",
    oversized: true,
    description:
      "A shorter, wider box cut in extra-dense cotton. Built for structure — it sits on the body instead of collapsing.",
    fabric: "320 GSM compact cotton. Rigid drape, broken in after wash.",
    details: [
      "Boxy cropped oversized fit",
      "Reinforced shoulder seams",
      "Clean hem, no side vents",
      "Heavyweight compact cotton",
    ],
    images: ["/products/box-tee-black.jpg", "/products/box-tee-black-detail.jpg"],
    colors: [{ name: "Black", hex: "#111111" }],
    sizes: [...SIZES],
    stock: 24,
    badge: "SALE",
    featured: true,
    bestSeller: true,
    newArrival: false,
    sold: 540,
    createdAt: "2026-05-18",
  },
  {
    id: "p05",
    slug: "acid-wash-tee-charcoal",
    name: "Acid Wash Tee",
    price: 479,
    category: "t-shirts",
    oversized: true,
    description:
      "Washed down charcoal with a lived-in surface. Each piece takes a slightly different pattern — no two are identical.",
    fabric: "260 GSM cotton, pigment washed and enzyme finished.",
    details: [
      "Oversized relaxed fit",
      "Unique wash on every piece",
      "Soft broken-in hand feel",
      "Tonal stitching",
    ],
    images: ["/products/wash-tee-charcoal.jpg", "/products/wash-tee-charcoal-detail.jpg"],
    colors: [{ name: "Charcoal", hex: "#4A4A4A" }],
    sizes: [...SIZES],
    stock: 18,
    badge: "NEW",
    featured: false,
    bestSeller: false,
    newArrival: true,
    sold: 160,
    createdAt: "2026-09-04",
  },
  {
    id: "p06",
    slug: "jester-tee-black",
    name: "Jester Tee",
    price: 549,
    category: "t-shirts",
    oversized: true,
    description:
      "A quiet graphic in a loud category. The Jester tee keeps the oversized cut of the core line with a mark that only reads up close.",
    fabric: "280 GSM combed cotton with water-based print.",
    details: [
      "Oversized core fit",
      "Water-based graphic, soft to the touch",
      "Tonal print that ages with wear",
      "Ribbed collar",
    ],
    images: ["/products/graphic-tee-black.jpg", "/products/graphic-tee-black-detail.jpg"],
    colors: [{ name: "Black", hex: "#111111" }],
    sizes: [...SIZES],
    stock: 36,
    badge: "BEST SELLER",
    featured: true,
    bestSeller: true,
    newArrival: false,
    sold: 720,
    createdAt: "2026-04-09",
  },
  {
    id: "p07",
    slug: "essential-hoodie-black",
    name: "Essential Hoodie",
    price: 899,
    oldPrice: 1099,
    category: "hoodies",
    oversized: true,
    family: "essential-hoodie",
    description:
      "The hoodie that carries the rest of the wardrobe. Heavy fleece, a deep hood, and a cut that layers over tees without feeling bulky.",
    fabric: "460 GSM cotton-blend fleece, brushed interior.",
    details: HOODIE_DETAILS,
    images: ["/products/hoodie-black.jpg", "/products/hoodie-black-detail.jpg"],
    colors: [{ name: "Black", hex: "#111111" }],
    sizes: [...SIZES],
    stock: 22,
    badge: "BEST SELLER",
    featured: true,
    bestSeller: true,
    newArrival: false,
    sold: 640,
    createdAt: "2026-03-22",
  },
  {
    id: "p08",
    slug: "essential-hoodie-shadow",
    name: "Essential Hoodie",
    price: 899,
    category: "hoodies",
    oversized: true,
    family: "essential-hoodie",
    description:
      "Essential hoodie in shadow grey. Same weight, same cut — a quieter colour that still holds the line.",
    fabric: "460 GSM cotton-blend fleece, brushed interior.",
    details: HOODIE_DETAILS,
    images: ["/products/hoodie-charcoal.jpg", "/products/hoodie-charcoal-detail.jpg"],
    colors: [{ name: "Shadow", hex: "#3A3A3A" }],
    sizes: [...SIZES],
    stock: 16,
    featured: false,
    bestSeller: false,
    newArrival: false,
    sold: 190,
    createdAt: "2026-06-01",
  },
  {
    id: "p09",
    slug: "essential-hoodie-navy",
    name: "Essential Hoodie",
    price: 899,
    category: "hoodies",
    oversized: true,
    family: "essential-hoodie",
    description:
      "Navy essential hoodie. Deep indigo that works as a second black — for training, travel, and everything between.",
    fabric: "460 GSM cotton-blend fleece, brushed interior.",
    details: HOODIE_DETAILS,
    images: ["/products/hoodie-navy.jpg", "/products/hoodie-navy-detail.jpg"],
    colors: [{ name: "Navy", hex: "#1E2A4A" }],
    sizes: [...SIZES],
    stock: 14,
    badge: "NEW",
    featured: false,
    bestSeller: false,
    newArrival: true,
    sold: 120,
    createdAt: "2026-09-10",
  },
  {
    id: "p10",
    slug: "utility-cargo-black",
    name: "Utility Cargo",
    price: 749,
    oldPrice: 899,
    category: "pants",
    oversized: false,
    description:
      "Relaxed cargo trousers with a clean face and working pockets. Cut to sit on the sneaker, not swallow it.",
    fabric: "Twilled cotton with a dry, structured hand.",
    details: [
      "Relaxed straight leg",
      "Side cargo pockets with hidden snap",
      "Elasticated back waist",
      "Internal drawcord",
    ],
    images: ["/products/cargo-pants-black.jpg", "/products/cargo-pants-black-2.jpg", "/products/hero.jpg"],
    colors: [{ name: "Black", hex: "#111111" }],
    sizes: [...SIZES],
    stock: 20,
    badge: "BEST SELLER",
    featured: true,
    bestSeller: true,
    newArrival: false,
    sold: 410,
    createdAt: "2026-05-30",
  },
];

export const INSTAGRAM_IMAGES = [
  { src: "/products/ig-1.jpg", alt: "JOKER campaign still — black hoodie and cargo" },
  { src: "/products/ig-2.jpg", alt: "JOKER core oversized tee in black" },
  { src: "/products/ig-3.jpg", alt: "JOKER essential hoodie in black" },
  { src: "/products/ig-4.jpg", alt: "JOKER core oversized tee in off-white" },
  { src: "/products/ig-5.jpg", alt: "JOKER essential hoodie in navy" },
  { src: "/products/ig-6.jpg", alt: "JOKER acid wash tee in charcoal" },
];

export function getProductBySlug(slug: string) {
  return PRODUCTS.find((p) => p.slug === slug);
}

export function getProductById(id: string) {
  return PRODUCTS.find((p) => p.id === id);
}

export function familyProducts(product: Product) {
  if (!product.family) return [product];
  return PRODUCTS.filter((p) => p.family === product.family);
}

export function relatedProducts(product: Product, limit = 4) {
  return PRODUCTS.filter((p) => p.id !== product.id)
    .sort((a, b) => {
      const cat = Number(b.category === product.category) - Number(a.category === product.category);
      if (cat !== 0) return cat;
      return b.sold - a.sold;
    })
    .slice(0, limit);
}

export function matchesCategory(product: Product, category?: string) {
  if (!category || category === "all") return true;
  if (category === "oversized") return product.oversized;
  if (category === "new-arrivals") return product.newArrival;
  if (category === "best-sellers") return product.bestSeller;
  return product.category === category;
}

export type ShopFilters = {
  category?: string;
  size?: string;
  color?: string;
  min?: number;
  max?: number;
};

export function filterProducts(filters: ShopFilters) {
  return PRODUCTS.filter((p) => {
    if (!matchesCategory(p, filters.category)) return false;
    if (filters.size && !p.sizes.includes(filters.size)) return false;
    if (
      filters.color &&
      !p.colors.some((c) => c.name.toLowerCase() === filters.color!.toLowerCase())
    ) {
      return false;
    }
    if (filters.min != null && p.price < filters.min) return false;
    if (filters.max != null && p.price > filters.max) return false;
    return true;
  });
}

export type SortKey = "featured" | "newest" | "price-asc" | "price-desc" | "best-selling";

export const SORT_OPTIONS: { value: SortKey; label: string }[] = [
  { value: "featured", label: "Featured" },
  { value: "newest", label: "Newest" },
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "best-selling", label: "Best Selling" },
];

export function sortProducts(products: Product[], sort: SortKey = "featured") {
  const arr = [...products];
  switch (sort) {
    case "newest":
      return arr.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
    case "price-asc":
      return arr.sort((a, b) => a.price - b.price);
    case "price-desc":
      return arr.sort((a, b) => b.price - a.price);
    case "best-selling":
      return arr.sort((a, b) => Number(b.bestSeller) - Number(a.bestSeller) || b.sold - a.sold);
    default:
      return arr.sort(
        (a, b) => Number(b.featured) - Number(a.featured) || b.sold - a.sold,
      );
  }
}

export function allColors() {
  const map = new Map<string, string>();
  for (const p of PRODUCTS) {
    for (const c of p.colors) map.set(c.name, c.hex);
  }
  return [...map.entries()].map(([name, hex]) => ({ name, hex }));
}

export function searchProducts(query: string) {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const terms = q.split(/\s+/);
  return PRODUCTS.filter((p) => {
    const hay = [
      p.name,
      p.category,
      p.description,
      p.fabric,
      ...p.colors.map((c) => c.name),
      p.oversized ? "oversized" : "",
      p.badge ?? "",
    ]
      .join(" ")
      .toLowerCase();
    return terms.every((t) => hay.includes(t));
  });
}

export function searchSuggestions(query: string, limit = 6) {
  return searchProducts(query).slice(0, limit);
}

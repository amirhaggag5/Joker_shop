import { X as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as BRAND } from "./config-DAONyBRW.mjs";
import { t as Button } from "./button-Bv-N6FT1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-2g-a95dq.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-4 py-16 md:py-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] tracking-label uppercase text-muted",
				children: "The house"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl font-semibold md:text-6xl",
				children: "JOKER"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-xl text-muted",
				children: BRAND.philosophy
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 space-y-5 text-base leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "JOKER is a streetwear house for people who live in their clothes. We design oversized tees, heavyweight hoodies and everyday sportswear in a short palette — black, off-white, charcoal, navy — so the pieces actually get worn." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Nothing here is seasonal filler. Fabric weight, shoulder drop, and hem length are decided on the body, not on a moodboard. If it doesn't earn a place in a weekly rotation, it doesn't ship." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We sell from Egypt, ship nationwide, and take cash on delivery because that's how our customers actually buy. Premium doesn't have to mean inaccessible." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-10",
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/shop",
					children: "Shop the collection"
				})
			})
		]
	});
}
//#endregion
export { AboutPage as component };

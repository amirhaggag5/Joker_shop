//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DIXmxLTm.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/$",
			"/about",
			"/cart",
			"/checkout",
			"/contact",
			"/privacy",
			"/search",
			"/shipping",
			"/shop",
			"/terms",
			"/order/$id",
			"/product/$slug"
		],
		preloads: [
			"/assets/index-R8VaUCvU.js",
			"/assets/jsx-runtime-BkSabwWG.js",
			"/assets/react-Biqg-U6H.js",
			"/assets/matchContext-BJcCXSNZ.js",
			"/assets/route-CyJqQsCC.js",
			"/assets/link-BHN-XpMC.js",
			"/assets/preload-helper-CHdTF4LC.js",
			"/assets/useSelector-CRqqBMds.js",
			"/assets/useNavigate-C4PZbXRq.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-R8VaUCvU.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Cbj-dOCb.js",
			"/assets/input-BVBd4MQm.js",
			"/assets/ProductCard-Cej55B7Q.js"
		]
	},
	"/$": {
		filePath: "/workspace/src/routes/$.tsx",
		children: void 0,
		preloads: ["/assets/_-CLGGq-F8.js"]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-BOYCmVLQ.js"]
	},
	"/cart": {
		filePath: "/workspace/src/routes/cart.tsx",
		children: void 0,
		preloads: ["/assets/cart-B19TOgMU.js", "/assets/input-BVBd4MQm.js"]
	},
	"/checkout": {
		filePath: "/workspace/src/routes/checkout.tsx",
		children: void 0,
		preloads: [
			"/assets/checkout-D7eLUmBY.js",
			"/assets/input-BVBd4MQm.js",
			"/assets/orders-hOc3A4aK.js"
		]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-CJgETJBE.js", "/assets/input-BVBd4MQm.js"]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-C4UwV5m_.js"]
	},
	"/search": {
		filePath: "/workspace/src/routes/search.tsx",
		children: void 0,
		preloads: ["/assets/search-rngrnQZc.js", "/assets/ProductGrid-BYG0pqSz.js"]
	},
	"/shipping": {
		filePath: "/workspace/src/routes/shipping.tsx",
		children: void 0,
		preloads: ["/assets/shipping-QStuRVw4.js", "/assets/SizeGuideTable-Cgncuh6i.js"]
	},
	"/shop": {
		filePath: "/workspace/src/routes/shop.tsx",
		children: ["/shop/$category", "/shop/"],
		preloads: ["/assets/shop-C2obZMYu.js"]
	},
	"/terms": {
		filePath: "/workspace/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-1fcS_t1j.js"]
	},
	"/order/$id": {
		filePath: "/workspace/src/routes/order.$id.tsx",
		children: void 0,
		preloads: ["/assets/order._id-COz6G8uy.js", "/assets/orders-hOc3A4aK.js"]
	},
	"/product/$slug": {
		filePath: "/workspace/src/routes/product.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/product._slug-C6He9v1a.js",
			"/assets/ProductCard-Cej55B7Q.js",
			"/assets/SizeGuideTable-Cgncuh6i.js"
		]
	},
	"/shop/$category": {
		filePath: "/workspace/src/routes/shop.$category.tsx",
		children: void 0,
		preloads: ["/assets/shop._category-D0re7Z2q.js", "/assets/ShopView-CpF1c8HU.js"]
	},
	"/shop/": {
		filePath: "/workspace/src/routes/shop.index.tsx",
		children: void 0,
		preloads: ["/assets/shop.index-BsHMalDv.js", "/assets/ShopView-CpF1c8HU.js"]
	}
} });
//#endregion
export { tsrStartManifest };

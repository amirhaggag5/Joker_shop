import { Link } from "@tanstack/react-router";
import { Menu, Search, ShoppingBag } from "lucide-react";
import { Logo } from "@/components/logo";
import { useMounted } from "@/hooks/use-mounted";
import { cn } from "@/lib/utils";
import { useCart, useCartCount } from "@/store/cart";
import { useUI } from "@/store/ui";

export function Navbar() {
  const mounted = useMounted();
  const count = useCartCount();
  const bump = useCart((s) => s.bump);
  const setMenuOpen = useUI((s) => s.setMenuOpen);
  const setSearchOpen = useUI((s) => s.setSearchOpen);
  const setCartOpen = useUI((s) => s.setCartOpen);

  return (
    <header className="sticky top-0 z-40 border-b border-border/80 bg-bg/90 backdrop-blur-md">
      <div className="mx-auto grid h-16 max-w-7xl grid-cols-3 items-center px-4 md:h-[4.25rem] md:px-6">
        <div className="flex items-center gap-1">
          <button
            type="button"
            className="flex size-11 items-center justify-center text-fg md:hidden"
            onClick={() => setMenuOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="size-5" />
          </button>
          <nav className="hidden items-center gap-6 md:flex">
            <Link to="/shop" className="text-[11px] font-medium tracking-label uppercase text-muted transition-colors hover:text-fg">
              Shop
            </Link>
            <Link
              to="/shop/$category"
              params={{ category: "new-arrivals" }}
              className="text-[11px] font-medium tracking-label uppercase text-muted transition-colors hover:text-fg"
            >
              New
            </Link>
            <Link
              to="/shop/$category"
              params={{ category: "best-sellers" }}
              className="text-[11px] font-medium tracking-label uppercase text-muted transition-colors hover:text-fg"
            >
              Best Sellers
            </Link>
            <Link to="/about" className="text-[11px] font-medium tracking-label uppercase text-muted transition-colors hover:text-fg">
              About
            </Link>
          </nav>
        </div>
        <div className="flex justify-center">
          <Logo />
        </div>
        <div className="flex items-center justify-end gap-0.5">
          <button
            type="button"
            className="flex size-11 items-center justify-center text-fg"
            onClick={() => setSearchOpen(true)}
            aria-label="Search"
          >
            <Search className="size-5" />
          </button>
          <button
            type="button"
            className="relative flex size-11 items-center justify-center text-fg"
            onClick={() => setCartOpen(true)}
            aria-label="Open cart"
          >
            <ShoppingBag className="size-5" />
            {mounted && count > 0 ? (
              <span
                key={bump}
                className={cn(
                  "absolute top-1.5 right-1.5 flex size-4 items-center justify-center bg-fg text-[9px] font-semibold text-bg tabular-nums cart-pop",
                )}
              >
                {count}
              </span>
            ) : null}
          </button>
        </div>
      </div>
    </header>
  );
}

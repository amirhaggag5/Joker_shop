import { i as __toESM } from "../_runtime.mjs";
import { X as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as BRAND } from "./config-DAONyBRW.mjs";
import { r as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { n as cn, t as Button } from "./button-Bv-N6FT1.mjs";
import { c as useCart, d as QuantitySelector, l as useCartTotals, u as formatEGP } from "./router-QtDp_Yot.mjs";
import { t as Input } from "./input-D6LKnbkF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cart-C2Vqhlzt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CartView() {
	const items = useCart((s) => s.items);
	const setQuantity = useCart((s) => s.setQuantity);
	const removeItem = useCart((s) => s.removeItem);
	const applyPromo = useCart((s) => s.applyPromo);
	const removePromo = useCart((s) => s.removePromo);
	const promoCode = useCart((s) => s.promoCode);
	const promoMessage = useCart((s) => s.promoMessage);
	const promoStatus = useCart((s) => s.promoStatus);
	const totals = useCartTotals();
	const [code, setCode] = (0, import_react.useState)("");
	if (items.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-4 py-24 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl font-semibold",
				children: "Your cart is empty"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "The drop is waiting."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-8",
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/shop",
					children: "Continue shopping"
				})
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-7xl gap-12 px-4 py-10 md:px-6 md:py-14 lg:grid-cols-[minmax(0,1fr)_360px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl font-semibold",
			children: "Cart"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-8 divide-y divide-border border-y border-border",
			children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex gap-4 py-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/product/$slug",
					params: { slug: item.slug },
					className: "size-28 shrink-0 overflow-hidden bg-surface sm:size-32",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: item.image,
						alt: item.name,
						className: "h-full w-full object-cover"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: item.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								"Size ",
								item.size,
								" · ",
								item.color
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "tabular-nums",
							children: formatEGP(item.price * item.quantity)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuantitySelector, {
							value: item.quantity,
							onChange: (qty) => setQuantity(item.key, qty)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-xs tracking-label uppercase text-muted hover:text-fg",
							onClick: () => removeItem(item.key),
							children: "Remove"
						})]
					})]
				})]
			}, item.key))
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "h-fit border border-border bg-bg-elevated p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm tracking-label uppercase",
					children: "Summary"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-6 space-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Subtotal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums",
								children: formatEGP(totals.subtotal)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Shipping"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums",
								children: totals.freeShipping ? "Free" : formatEGP(totals.shipping)
							})]
						}),
						totals.offerDiscount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between text-success",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: totals.offerLabel }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "tabular-nums",
								children: ["-", formatEGP(totals.offerDiscount)]
							})]
						}) : null,
						totals.promoDiscount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between text-success",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dt", { children: ["Promo ", promoCode] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "tabular-nums",
								children: ["-", formatEGP(totals.promoDiscount)]
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Discount"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums",
								children: totals.discount ? `-${formatEGP(totals.discount)}` : formatEGP(0)
							})]
						})
					]
				}),
				totals.freeShipping ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs tracking-label uppercase text-success",
					children: "Free shipping"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-xs text-muted",
					children: [
						"Add ",
						formatEGP(totals.remainingForFreeShipping),
						" more for free shipping over",
						" ",
						BRAND.freeShippingThreshold.toLocaleString("en-EG"),
						" EGP."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex justify-between border-t border-border pt-4 text-base font-medium",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: formatEGP(totals.total)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-6 flex gap-2",
					onSubmit: (e) => {
						e.preventDefault();
						applyPromo(code);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: code,
						onChange: (e) => setCode(e.target.value),
						placeholder: "Promo code",
						className: "h-12",
						"aria-label": "Promo code"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "outline",
						children: "Apply"
					})]
				}),
				promoMessage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("mt-2 text-xs", promoStatus === "success" ? "text-success" : "text-danger"),
					children: promoMessage
				}) : null,
				promoCode ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-2 text-xs text-muted hover:text-fg",
					onClick: removePromo,
					children: "Remove code"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-[11px] text-subtle",
					children: "Try JOKER10"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-6 w-full",
					size: "lg",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/checkout",
						children: "Checkout"
					})
				})
			]
		})]
	});
}
function CartPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartView, {});
}
//#endregion
export { CartPage as component };

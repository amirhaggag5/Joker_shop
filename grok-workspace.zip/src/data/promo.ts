export type PromoCode = {
  code: string;
  type: "percent" | "fixed";
  value: number;
  minSubtotal?: number;
  expiresAt?: string;
  once?: boolean;
  successMessage: string;
};

export const PROMO_CODES: PromoCode[] = [
  {
    code: "JOKER10",
    type: "percent",
    value: 10,
    successMessage: "JOKER10 applied — 10% off.",
  },
  {
    code: "JOKER20",
    type: "percent",
    value: 20,
    minSubtotal: 1500,
    successMessage: "JOKER20 applied — 20% off.",
  },
  {
    code: "WELCOME",
    type: "percent",
    value: 15,
    once: true,
    successMessage: "Welcome offer applied — 15% off.",
  },
  {
    code: "EXPIRED",
    type: "percent",
    value: 25,
    expiresAt: "2024-01-01",
    successMessage: "",
  },
];

export type PromoResult =
  | { ok: true; promo: PromoCode; message: string }
  | { ok: false; reason: "invalid" | "expired" | "used" | "min"; message: string };

export function findPromo(code: string) {
  const normalized = code.trim().toUpperCase();
  return PROMO_CODES.find((p) => p.code === normalized);
}

export function evaluatePromo(
  code: string,
  subtotal: number,
  usedCodes: string[],
): PromoResult {
  const normalized = code.trim().toUpperCase();
  if (!normalized) {
    return { ok: false, reason: "invalid", message: "Enter a promo code." };
  }
  const promo = findPromo(normalized);
  if (!promo) {
    return { ok: false, reason: "invalid", message: "This code is not valid." };
  }
  if (promo.expiresAt && new Date(promo.expiresAt).getTime() < Date.now()) {
    return { ok: false, reason: "expired", message: "This code has expired." };
  }
  if (promo.once && usedCodes.includes(promo.code)) {
    return { ok: false, reason: "used", message: "This code has already been used." };
  }
  if (promo.minSubtotal && subtotal < promo.minSubtotal) {
    return {
      ok: false,
      reason: "min",
      message: `This code requires a subtotal of ${promo.minSubtotal.toLocaleString("en-EG")} EGP.`,
    };
  }
  return { ok: true, promo, message: promo.successMessage };
}

export function promoDiscountAmount(promo: PromoCode, amount: number) {
  if (promo.type === "percent") return Math.round((amount * promo.value) / 100);
  return Math.min(promo.value, amount);
}

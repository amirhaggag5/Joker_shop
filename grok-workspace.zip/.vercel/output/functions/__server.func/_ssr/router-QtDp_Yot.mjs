import { i as __toESM } from "../_runtime.mjs";
import { C as useRouter, S as useNavigate, X as require_jsx_runtime, Y as notFound, _ as lazyRouteComponent, f as Scripts, g as Outlet, h as createRouter, p as HeadContent, v as createFileRoute, x as Link, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as whatsappUrl, t as BRAND } from "./config-DAONyBRW.mjs";
import { r as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { n as cn, t as Button } from "./button-Bv-N6FT1.mjs";
import { a as ShoppingBag, d as Menu, l as Plus, n as TriangleAlert, s as Search, t as X, u as Minus } from "../_libs/lucide-react.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products-B89m1PWm.js
var SIZES = [
	"S",
	"M",
	"L",
	"XL",
	"XXL"
];
var SHOP_CATEGORIES = [
	{
		slug: "all",
		label: "All"
	},
	{
		slug: "t-shirts",
		label: "T-Shirts"
	},
	{
		slug: "oversized",
		label: "Oversized"
	},
	{
		slug: "hoodies",
		label: "Hoodies"
	},
	{
		slug: "pants",
		label: "Pants"
	},
	{
		slug: "new-arrivals",
		label: "New Arrivals"
	},
	{
		slug: "best-sellers",
		label: "Best Sellers"
	}
];
var SIZE_GUIDE = [
	{
		size: "S",
		chest: 108,
		length: 70,
		shoulder: 52
	},
	{
		size: "M",
		chest: 114,
		length: 72,
		shoulder: 54
	},
	{
		size: "L",
		chest: 120,
		length: 74,
		shoulder: 56
	},
	{
		size: "XL",
		chest: 126,
		length: 76,
		shoulder: 58
	},
	{
		size: "XXL",
		chest: 132,
		length: 78,
		shoulder: 60
	}
];
var TEE_DETAILS = [
	"Oversized dropped-shoulder cut",
	"Ribbed collar that holds its shape",
	"Double-needle hem and sleeves",
	"Pre-shrunk heavyweight cotton"
];
var HOODIE_DETAILS = [
	"Kangaroo pocket",
	"Ribbed cuffs and hem",
	"Lined hood",
	"Heavyweight fleece, brushed inside"
];
/**
* JOKER catalog.
* Add a product by appending an object below.
* Drop images in /public/products and set images: ["/products/your-file.jpg"].
*/
var PRODUCTS = [
	{
		id: "p01",
		slug: "core-oversized-tee-black",
		name: "Core Oversized Tee",
		price: 449,
		oldPrice: 599,
		category: "t-shirts",
		oversized: true,
		family: "core-tee",
		description: "The daily uniform. A heavyweight oversized tee with dropped shoulders and a clean set-in neckline — cut to move with you from morning training to late hours in the city.",
		fabric: "280 GSM combed cotton. Soft hand, dense drape, pre-shrunk.",
		details: TEE_DETAILS,
		images: ["/products/core-tee-black.jpg", "/products/core-tee-black-detail.jpg"],
		colors: [{
			name: "Black",
			hex: "#111111"
		}],
		sizes: [...SIZES],
		stock: 42,
		badge: "BEST SELLER",
		featured: true,
		bestSeller: true,
		newArrival: false,
		sold: 860,
		createdAt: "2026-06-12"
	},
	{
		id: "p02",
		slug: "core-oversized-tee-off-white",
		name: "Core Oversized Tee",
		price: 449,
		category: "t-shirts",
		oversized: true,
		family: "core-tee",
		description: "The same core cut in off-white. Heavy cotton, relaxed through the body, made to be worn on repeat.",
		fabric: "280 GSM combed cotton. Soft hand, dense drape, pre-shrunk.",
		details: TEE_DETAILS,
		images: ["/products/core-tee-white.jpg", "/products/core-tee-white-detail.jpg"],
		colors: [{
			name: "Off White",
			hex: "#E8E4DC"
		}],
		sizes: [...SIZES],
		stock: 28,
		badge: "NEW",
		featured: true,
		bestSeller: false,
		newArrival: true,
		sold: 210,
		createdAt: "2026-08-20"
	},
	{
		id: "p03",
		slug: "core-oversized-tee-navy",
		name: "Core Oversized Tee",
		price: 449,
		category: "t-shirts",
		oversized: true,
		family: "core-tee",
		description: "Core oversized tee in deep navy. A darker alternative that still reads clean under any light.",
		fabric: "280 GSM combed cotton. Soft hand, dense drape, pre-shrunk.",
		details: TEE_DETAILS,
		images: ["/products/core-tee-navy.jpg", "/products/core-tee-navy-detail.jpg"],
		colors: [{
			name: "Navy",
			hex: "#1E2A4A"
		}],
		sizes: [...SIZES],
		stock: 31,
		featured: false,
		bestSeller: false,
		newArrival: false,
		sold: 340,
		createdAt: "2026-07-02"
	},
	{
		id: "p04",
		slug: "heavyweight-box-tee-black",
		name: "Heavyweight Box Tee",
		price: 529,
		oldPrice: 649,
		category: "t-shirts",
		oversized: true,
		description: "A shorter, wider box cut in extra-dense cotton. Built for structure — it sits on the body instead of collapsing.",
		fabric: "320 GSM compact cotton. Rigid drape, broken in after wash.",
		details: [
			"Boxy cropped oversized fit",
			"Reinforced shoulder seams",
			"Clean hem, no side vents",
			"Heavyweight compact cotton"
		],
		images: ["/products/box-tee-black.jpg", "/products/box-tee-black-detail.jpg"],
		colors: [{
			name: "Black",
			hex: "#111111"
		}],
		sizes: [...SIZES],
		stock: 24,
		badge: "SALE",
		featured: true,
		bestSeller: true,
		newArrival: false,
		sold: 540,
		createdAt: "2026-05-18"
	},
	{
		id: "p05",
		slug: "acid-wash-tee-charcoal",
		name: "Acid Wash Tee",
		price: 479,
		category: "t-shirts",
		oversized: true,
		description: "Washed down charcoal with a lived-in surface. Each piece takes a slightly different pattern — no two are identical.",
		fabric: "260 GSM cotton, pigment washed and enzyme finished.",
		details: [
			"Oversized relaxed fit",
			"Unique wash on every piece",
			"Soft broken-in hand feel",
			"Tonal stitching"
		],
		images: ["/products/wash-tee-charcoal.jpg", "/products/wash-tee-charcoal-detail.jpg"],
		colors: [{
			name: "Charcoal",
			hex: "#4A4A4A"
		}],
		sizes: [...SIZES],
		stock: 18,
		badge: "NEW",
		featured: false,
		bestSeller: false,
		newArrival: true,
		sold: 160,
		createdAt: "2026-09-04"
	},
	{
		id: "p06",
		slug: "jester-tee-black",
		name: "Jester Tee",
		price: 549,
		category: "t-shirts",
		oversized: true,
		description: "A quiet graphic in a loud category. The Jester tee keeps the oversized cut of the core line with a mark that only reads up close.",
		fabric: "280 GSM combed cotton with water-based print.",
		details: [
			"Oversized core fit",
			"Water-based graphic, soft to the touch",
			"Tonal print that ages with wear",
			"Ribbed collar"
		],
		images: ["/products/graphic-tee-black.jpg", "/products/graphic-tee-black-detail.jpg"],
		colors: [{
			name: "Black",
			hex: "#111111"
		}],
		sizes: [...SIZES],
		stock: 36,
		badge: "BEST SELLER",
		featured: true,
		bestSeller: true,
		newArrival: false,
		sold: 720,
		createdAt: "2026-04-09"
	},
	{
		id: "p07",
		slug: "essential-hoodie-black",
		name: "Essential Hoodie",
		price: 899,
		oldPrice: 1099,
		category: "hoodies",
		oversized: true,
		family: "essential-hoodie",
		description: "The hoodie that carries the rest of the wardrobe. Heavy fleece, a deep hood, and a cut that layers over tees without feeling bulky.",
		fabric: "460 GSM cotton-blend fleece, brushed interior.",
		details: HOODIE_DETAILS,
		images: ["/products/hoodie-black.jpg", "/products/hoodie-black-detail.jpg"],
		colors: [{
			name: "Black",
			hex: "#111111"
		}],
		sizes: [...SIZES],
		stock: 22,
		badge: "BEST SELLER",
		featured: true,
		bestSeller: true,
		newArrival: false,
		sold: 640,
		createdAt: "2026-03-22"
	},
	{
		id: "p08",
		slug: "essential-hoodie-shadow",
		name: "Essential Hoodie",
		price: 899,
		category: "hoodies",
		oversized: true,
		family: "essential-hoodie",
		description: "Essential hoodie in shadow grey. Same weight, same cut — a quieter colour that still holds the line.",
		fabric: "460 GSM cotton-blend fleece, brushed interior.",
		details: HOODIE_DETAILS,
		images: ["/products/hoodie-charcoal.jpg", "/products/hoodie-charcoal-detail.jpg"],
		colors: [{
			name: "Shadow",
			hex: "#3A3A3A"
		}],
		sizes: [...SIZES],
		stock: 16,
		featured: false,
		bestSeller: false,
		newArrival: false,
		sold: 190,
		createdAt: "2026-06-01"
	},
	{
		id: "p09",
		slug: "essential-hoodie-navy",
		name: "Essential Hoodie",
		price: 899,
		category: "hoodies",
		oversized: true,
		family: "essential-hoodie",
		description: "Navy essential hoodie. Deep indigo that works as a second black — for training, travel, and everything between.",
		fabric: "460 GSM cotton-blend fleece, brushed interior.",
		details: HOODIE_DETAILS,
		images: ["/products/hoodie-navy.jpg", "/products/hoodie-navy-detail.jpg"],
		colors: [{
			name: "Navy",
			hex: "#1E2A4A"
		}],
		sizes: [...SIZES],
		stock: 14,
		badge: "NEW",
		featured: false,
		bestSeller: false,
		newArrival: true,
		sold: 120,
		createdAt: "2026-09-10"
	},
	{
		id: "p10",
		slug: "utility-cargo-black",
		name: "Utility Cargo",
		price: 749,
		oldPrice: 899,
		category: "pants",
		oversized: false,
		description: "Relaxed cargo trousers with a clean face and working pockets. Cut to sit on the sneaker, not swallow it.",
		fabric: "Twilled cotton with a dry, structured hand.",
		details: [
			"Relaxed straight leg",
			"Side cargo pockets with hidden snap",
			"Elasticated back waist",
			"Internal drawcord"
		],
		images: [
			"/products/cargo-pants-black.jpg",
			"/products/cargo-pants-black-2.jpg",
			"/products/hero.jpg"
		],
		colors: [{
			name: "Black",
			hex: "#111111"
		}],
		sizes: [...SIZES],
		stock: 20,
		badge: "BEST SELLER",
		featured: true,
		bestSeller: true,
		newArrival: false,
		sold: 410,
		createdAt: "2026-05-30"
	}
];
var INSTAGRAM_IMAGES = [
	{
		src: "/products/ig-1.jpg",
		alt: "JOKER campaign still — black hoodie and cargo"
	},
	{
		src: "/products/ig-2.jpg",
		alt: "JOKER core oversized tee in black"
	},
	{
		src: "/products/ig-3.jpg",
		alt: "JOKER essential hoodie in black"
	},
	{
		src: "/products/ig-4.jpg",
		alt: "JOKER core oversized tee in off-white"
	},
	{
		src: "/products/ig-5.jpg",
		alt: "JOKER essential hoodie in navy"
	},
	{
		src: "/products/ig-6.jpg",
		alt: "JOKER acid wash tee in charcoal"
	}
];
function getProductBySlug(slug) {
	return PRODUCTS.find((p) => p.slug === slug);
}
function getProductById(id) {
	return PRODUCTS.find((p) => p.id === id);
}
function familyProducts(product) {
	if (!product.family) return [product];
	return PRODUCTS.filter((p) => p.family === product.family);
}
function relatedProducts(product, limit = 4) {
	return PRODUCTS.filter((p) => p.id !== product.id).sort((a, b) => {
		const cat = Number(b.category === product.category) - Number(a.category === product.category);
		if (cat !== 0) return cat;
		return b.sold - a.sold;
	}).slice(0, limit);
}
function matchesCategory(product, category) {
	if (!category || category === "all") return true;
	if (category === "oversized") return product.oversized;
	if (category === "new-arrivals") return product.newArrival;
	if (category === "best-sellers") return product.bestSeller;
	return product.category === category;
}
function filterProducts(filters) {
	return PRODUCTS.filter((p) => {
		if (!matchesCategory(p, filters.category)) return false;
		if (filters.size && !p.sizes.includes(filters.size)) return false;
		if (filters.color && !p.colors.some((c) => c.name.toLowerCase() === filters.color.toLowerCase())) return false;
		if (filters.min != null && p.price < filters.min) return false;
		if (filters.max != null && p.price > filters.max) return false;
		return true;
	});
}
var SORT_OPTIONS = [
	{
		value: "featured",
		label: "Featured"
	},
	{
		value: "newest",
		label: "Newest"
	},
	{
		value: "price-asc",
		label: "Price: Low to High"
	},
	{
		value: "price-desc",
		label: "Price: High to Low"
	},
	{
		value: "best-selling",
		label: "Best Selling"
	}
];
function sortProducts(products, sort = "featured") {
	const arr = [...products];
	switch (sort) {
		case "newest": return arr.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
		case "price-asc": return arr.sort((a, b) => a.price - b.price);
		case "price-desc": return arr.sort((a, b) => b.price - a.price);
		case "best-selling": return arr.sort((a, b) => Number(b.bestSeller) - Number(a.bestSeller) || b.sold - a.sold);
		default: return arr.sort((a, b) => Number(b.featured) - Number(a.featured) || b.sold - a.sold);
	}
}
function allColors() {
	const map = /* @__PURE__ */ new Map();
	for (const p of PRODUCTS) for (const c of p.colors) map.set(c.name, c.hex);
	return [...map.entries()].map(([name, hex]) => ({
		name,
		hex
	}));
}
function searchProducts(query) {
	const q = query.trim().toLowerCase();
	if (!q) return [];
	const terms = q.split(/\s+/);
	return PRODUCTS.filter((p) => {
		const hay = [
			p.name,
			p.category,
			p.description,
			p.fabric,
			...p.colors.map((c) => c.name),
			p.oversized ? "oversized" : "",
			p.badge ?? ""
		].join(" ").toLowerCase();
		return terms.every((t) => hay.includes(t));
	});
}
function searchSuggestions(query, limit = 6) {
	return searchProducts(query).slice(0, limit);
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-QtDp_Yot.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function AnnouncementBar() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "bg-fg text-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "flex h-9 items-center justify-center gap-3 px-4 text-[10px] font-medium tracking-label uppercase sm:text-[11px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "2 T-Shirts + 1 Free" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-bg/40",
					children: "/"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/shop",
					className: "underline-offset-4 hover:underline",
					children: [
						"Free shipping over ",
						BRAND.freeShippingThreshold.toLocaleString("en-EG"),
						" EGP"
					]
				})
			]
		})
	});
}
function QuantitySelector({ value, onChange, min = 1, max = 20, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("inline-flex h-12 items-center border border-border", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "flex h-full w-12 items-center justify-center text-fg transition-colors hover:bg-surface disabled:opacity-30",
				onClick: () => onChange(Math.max(min, value - 1)),
				disabled: value <= min,
				"aria-label": "Decrease quantity",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3.5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-8 text-center text-sm tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "flex h-full w-12 items-center justify-center text-fg transition-colors hover:bg-surface disabled:opacity-30",
				onClick: () => onChange(Math.min(max, value + 1)),
				disabled: value >= max,
				"aria-label": "Increase quantity",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" })
			})
		]
	});
}
function formatEGP(amount) {
	return `${amount.toLocaleString("en-EG")} EGP`;
}
var PROMO_CODES = [
	{
		code: "JOKER10",
		type: "percent",
		value: 10,
		successMessage: "JOKER10 applied — 10% off."
	},
	{
		code: "JOKER20",
		type: "percent",
		value: 20,
		minSubtotal: 1500,
		successMessage: "JOKER20 applied — 20% off."
	},
	{
		code: "WELCOME",
		type: "percent",
		value: 15,
		once: true,
		successMessage: "Welcome offer applied — 15% off."
	},
	{
		code: "EXPIRED",
		type: "percent",
		value: 25,
		expiresAt: "2024-01-01",
		successMessage: ""
	}
];
function findPromo(code) {
	const normalized = code.trim().toUpperCase();
	return PROMO_CODES.find((p) => p.code === normalized);
}
function evaluatePromo(code, subtotal, usedCodes) {
	const normalized = code.trim().toUpperCase();
	if (!normalized) return {
		ok: false,
		reason: "invalid",
		message: "Enter a promo code."
	};
	const promo = findPromo(normalized);
	if (!promo) return {
		ok: false,
		reason: "invalid",
		message: "This code is not valid."
	};
	if (promo.expiresAt && new Date(promo.expiresAt).getTime() < Date.now()) return {
		ok: false,
		reason: "expired",
		message: "This code has expired."
	};
	if (promo.once && usedCodes.includes(promo.code)) return {
		ok: false,
		reason: "used",
		message: "This code has already been used."
	};
	if (promo.minSubtotal && subtotal < promo.minSubtotal) return {
		ok: false,
		reason: "min",
		message: `This code requires a subtotal of ${promo.minSubtotal.toLocaleString("en-EG")} EGP.`
	};
	return {
		ok: true,
		promo,
		message: promo.successMessage
	};
}
function promoDiscountAmount(promo, amount) {
	if (promo.type === "percent") return Math.round(amount * promo.value / 100);
	return Math.min(promo.value, amount);
}
function teeOfferDiscount(items) {
	const prices = [];
	for (const line of items) {
		if (getProductById(line.productId)?.category !== "t-shirts") continue;
		for (let i = 0; i < line.quantity; i += 1) prices.push(line.price);
	}
	prices.sort((a, b) => a - b);
	const freeCount = Math.floor(prices.length / 3);
	if (freeCount <= 0) return 0;
	return prices.slice(0, freeCount).reduce((sum, price) => sum + price, 0);
}
function computeTotals(items, promoCode, usedCodes) {
	const subtotal = items.reduce((sum, line) => sum + line.price * line.quantity, 0);
	const offerDiscount = teeOfferDiscount(items);
	const offerLabel = offerDiscount > 0 ? "2 T-Shirts + 1 Free" : null;
	const afterOffer = Math.max(0, subtotal - offerDiscount);
	let promoDiscount = 0;
	if (promoCode) {
		const check = evaluatePromo(promoCode, afterOffer, usedCodes);
		if (check.ok) promoDiscount = promoDiscountAmount(check.promo, afterOffer);
		else {
			const promo = findPromo(promoCode);
			if (promo && !promo.once) {
				const relaxed = evaluatePromo(promoCode, afterOffer, []);
				if (relaxed.ok) promoDiscount = promoDiscountAmount(relaxed.promo, afterOffer);
			}
		}
	}
	const discount = offerDiscount + promoDiscount;
	const afterDiscounts = Math.max(0, subtotal - discount);
	const freeShipping = afterDiscounts >= BRAND.freeShippingThreshold;
	const shipping = items.length === 0 || freeShipping ? 0 : BRAND.shippingFee;
	const remainingForFreeShipping = Math.max(0, BRAND.freeShippingThreshold - afterDiscounts);
	return {
		subtotal,
		offerDiscount,
		offerLabel,
		promoDiscount,
		discount,
		shipping,
		total: afterDiscounts + shipping,
		freeShipping,
		remainingForFreeShipping
	};
}
function lineKey(productId, size, color) {
	return `${productId}__${size}__${color}`;
}
var useCart = create()(persist((set, get) => ({
	items: [],
	promoCode: null,
	promoMessage: null,
	promoStatus: "idle",
	usedCodes: [],
	bump: 0,
	addItem: (line) => {
		const key = lineKey(line.productId, line.size, line.color);
		const quantity = line.quantity ?? 1;
		set((state) => {
			return {
				items: state.items.find((item) => item.key === key) ? state.items.map((item) => item.key === key ? {
					...item,
					quantity: item.quantity + quantity
				} : item) : [...state.items, {
					...line,
					key,
					quantity
				}],
				bump: state.bump + 1
			};
		});
	},
	removeItem: (key) => set((state) => ({ items: state.items.filter((item) => item.key !== key) })),
	setQuantity: (key, quantity) => set((state) => ({ items: quantity <= 0 ? state.items.filter((item) => item.key !== key) : state.items.map((item) => item.key === key ? {
		...item,
		quantity
	} : item) })),
	applyPromo: (code) => {
		const { items, usedCodes } = get();
		const totals = computeTotals(items, null, usedCodes);
		const result = evaluatePromo(code, totals.subtotal - totals.offerDiscount, usedCodes);
		if (!result.ok) {
			set({
				promoCode: null,
				promoMessage: result.message,
				promoStatus: result.reason
			});
			return;
		}
		set({
			promoCode: result.promo.code,
			promoMessage: result.message,
			promoStatus: "success"
		});
	},
	removePromo: () => set({
		promoCode: null,
		promoMessage: null,
		promoStatus: "idle"
	}),
	markPromoUsed: () => {
		const { promoCode, usedCodes } = get();
		if (!promoCode) return;
		if (usedCodes.includes(promoCode)) return;
		set({
			usedCodes: [...usedCodes, promoCode],
			promoCode: null,
			promoMessage: null,
			promoStatus: "idle"
		});
	},
	clear: () => set({
		items: [],
		promoCode: null,
		promoMessage: null,
		promoStatus: "idle"
	})
}), { name: "joker-cart" }));
function useCartCount() {
	return useCart((s) => s.items.reduce((sum, item) => sum + item.quantity, 0));
}
function useCartTotals() {
	return computeTotals(useCart((s) => s.items), useCart((s) => s.promoCode), useCart((s) => s.usedCodes));
}
var useUI = create((set) => ({
	cartOpen: false,
	searchOpen: false,
	menuOpen: false,
	setCartOpen: (cartOpen) => set({
		cartOpen,
		searchOpen: false,
		menuOpen: false
	}),
	setSearchOpen: (searchOpen) => set({
		searchOpen,
		cartOpen: false,
		menuOpen: false
	}),
	setMenuOpen: (menuOpen) => set({
		menuOpen,
		cartOpen: false,
		searchOpen: false
	}),
	closeAll: () => set({
		cartOpen: false,
		searchOpen: false,
		menuOpen: false
	})
}));
function CartDrawer() {
	const open = useUI((s) => s.cartOpen);
	const setCartOpen = useUI((s) => s.setCartOpen);
	const items = useCart((s) => s.items);
	const setQuantity = useCart((s) => s.setQuantity);
	const removeItem = useCart((s) => s.removeItem);
	const totals = useCartTotals();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("fixed inset-0 z-50", open ? "" : "pointer-events-none"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Close cart",
			className: cn("absolute inset-0 bg-bg/70 transition-opacity duration-200", open ? "opacity-100" : "opacity-0"),
			onClick: () => setCartOpen(false)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: cn("absolute inset-y-0 right-0 flex w-full max-w-md flex-col border-l border-border bg-bg-elevated transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]", open ? "translate-x-0" : "translate-x-full"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-16 items-center justify-between border-b border-border px-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium tracking-label uppercase",
						children: "Cart"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-10 items-center justify-center",
						onClick: () => setCartOpen(false),
						"aria-label": "Close cart",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 overflow-y-auto px-5 py-5",
					children: items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-full flex-col items-center justify-center text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl",
							children: "Your cart is empty."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-6",
							onClick: () => setCartOpen(false),
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/shop",
								children: "Shop now"
							})
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-5",
						children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/product/$slug",
								params: { slug: item.slug },
								onClick: () => setCartOpen(false),
								className: "block size-24 shrink-0 overflow-hidden bg-surface",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: item.image,
									alt: item.name,
									className: "h-full w-full object-cover"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium",
										children: item.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-xs text-muted",
										children: [
											item.color,
											" / ",
											item.size
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm tabular-nums",
										children: formatEGP(item.price * item.quantity)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuantitySelector, {
										value: item.quantity,
										onChange: (qty) => setQuantity(item.key, qty),
										className: "h-10"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "text-xs tracking-label uppercase text-muted hover:text-fg",
										onClick: () => removeItem(item.key),
										children: "Remove"
									})]
								})]
							})]
						}, item.key))
					})
				}),
				items.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-border px-5 py-5",
					children: [
						totals.freeShipping ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-xs tracking-label uppercase text-success",
							children: "Free shipping"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-3 text-xs text-muted",
							children: [
								"Add ",
								formatEGP(totals.remainingForFreeShipping),
								" for free shipping."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "Subtotal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: formatEGP(totals.subtotal)
							})]
						}),
						totals.discount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex items-center justify-between text-sm text-success",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Discount" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums",
								children: ["-", formatEGP(totals.discount)]
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center justify-between font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: formatEGP(totals.total)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-[11px] text-subtle",
							children: "Shipping calculated at checkout · COD available"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-4 w-full",
							size: "lg",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/checkout",
								onClick: () => setCartOpen(false),
								children: "Checkout"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							className: "mt-2 w-full",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/cart",
								onClick: () => setCartOpen(false),
								children: "View cart"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-center text-[11px] text-subtle",
							children: [
								"Free shipping on orders over ",
								BRAND.freeShippingThreshold.toLocaleString("en-EG"),
								" EGP"
							]
						})
					]
				}) : null
			]
		})]
	});
}
function Logo({ className, to = "/" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		className: cn("font-display text-xl font-extrabold tracking-brand text-fg md:text-2xl", className),
		"aria-label": "JOKER home",
		children: "JOKER"
	});
}
var HOUSE = [
	{
		to: "/about",
		label: "About"
	},
	{
		to: "/contact",
		label: "Contact"
	},
	{
		to: "/shipping",
		label: "Shipping & Returns"
	},
	{
		to: "/privacy",
		label: "Privacy Policy"
	},
	{
		to: "/terms",
		label: "Terms"
	}
];
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-border bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-10 px-4 py-16 md:grid-cols-4 md:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xs text-sm text-muted",
						children: BRAND.philosophy
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-label uppercase text-subtle",
					children: "Shop"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-2.5",
					children: SHOP_CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item.slug === "all" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shop",
						className: "text-sm text-muted transition-colors hover:text-fg",
						children: item.label
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shop/$category",
						params: { category: item.slug },
						className: "text-sm text-muted transition-colors hover:text-fg",
						children: item.label
					}) }, item.slug))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-label uppercase text-subtle",
					children: "House"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-2.5",
					children: HOUSE.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						className: "text-sm text-muted transition-colors hover:text-fg",
						children: item.label
					}) }, item.to))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-label uppercase text-subtle",
					children: "Connect"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-2.5 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: BRAND.instagram,
							target: "_blank",
							rel: "noreferrer",
							className: "hover:text-fg",
							children: "Instagram"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: BRAND.tiktok,
							target: "_blank",
							rel: "noreferrer",
							className: "hover:text-fg",
							children: "TikTok"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: whatsappUrl(),
							target: "_blank",
							rel: "noreferrer",
							className: "hover:text-fg",
							children: "WhatsApp"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: `mailto:${BRAND.email}`,
							className: "hover:text-fg",
							children: BRAND.email
						}) })
					]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mx-auto flex max-w-7xl justify-between px-4 py-5 text-[11px] tracking-label uppercase text-subtle md:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" JOKER"
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Egypt · Cash on delivery" })]
			})
		})]
	});
}
function MobileMenu() {
	const open = useUI((s) => s.menuOpen);
	const setMenuOpen = useUI((s) => s.setMenuOpen);
	const setSearchOpen = useUI((s) => s.setSearchOpen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("fixed inset-0 z-50 md:hidden", open ? "" : "pointer-events-none"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: cn("absolute inset-0 bg-bg/70 transition-opacity duration-200", open ? "opacity-100" : "opacity-0"),
			onClick: () => setMenuOpen(false),
			"aria-label": "Close menu"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: cn("absolute inset-y-0 left-0 flex w-[min(100%,20rem)] flex-col bg-bg-elevated px-6 py-5 transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]", open ? "translate-x-0" : "-translate-x-full"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg font-extrabold tracking-brand",
						children: "JOKER"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "size-11",
						onClick: () => setMenuOpen(false),
						"aria-label": "Close menu",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mt-10 flex flex-col gap-1",
					children: SHOP_CATEGORIES.map((cat) => cat.slug === "all" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shop",
						className: "py-3 font-display text-2xl font-semibold",
						onClick: () => setMenuOpen(false),
						children: cat.label
					}, cat.slug) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shop/$category",
						params: { category: cat.slug },
						className: "py-3 font-display text-2xl font-semibold",
						onClick: () => setMenuOpen(false),
						children: cat.label
					}, cat.slug))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-auto space-y-3 pb-6 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "block py-2 text-fg",
							onClick: () => {
								setMenuOpen(false);
								setSearchOpen(true);
							},
							children: "Search"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/about",
							onClick: () => setMenuOpen(false),
							className: "block py-2",
							children: "About"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							onClick: () => setMenuOpen(false),
							className: "block py-2",
							children: "Contact"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/shipping",
							onClick: () => setMenuOpen(false),
							className: "block py-2",
							children: "Shipping & Returns"
						})
					]
				})
			]
		})]
	});
}
function useMounted() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	return mounted;
}
function Navbar() {
	const mounted = useMounted();
	const count = useCartCount();
	const bump = useCart((s) => s.bump);
	const setMenuOpen = useUI((s) => s.setMenuOpen);
	const setSearchOpen = useUI((s) => s.setSearchOpen);
	const setCartOpen = useUI((s) => s.setCartOpen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-40 border-b border-border/80 bg-bg/90 backdrop-blur-md",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid h-16 max-w-7xl grid-cols-3 items-center px-4 md:h-[4.25rem] md:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 items-center justify-center text-fg md:hidden",
						onClick: () => setMenuOpen(true),
						"aria-label": "Open menu",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "hidden items-center gap-6 md:flex",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/shop",
								className: "text-[11px] font-medium tracking-label uppercase text-muted transition-colors hover:text-fg",
								children: "Shop"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/shop/$category",
								params: { category: "new-arrivals" },
								className: "text-[11px] font-medium tracking-label uppercase text-muted transition-colors hover:text-fg",
								children: "New"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/shop/$category",
								params: { category: "best-sellers" },
								className: "text-[11px] font-medium tracking-label uppercase text-muted transition-colors hover:text-fg",
								children: "Best Sellers"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/about",
								className: "text-[11px] font-medium tracking-label uppercase text-muted transition-colors hover:text-fg",
								children: "About"
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-end gap-0.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 items-center justify-center text-fg",
						onClick: () => setSearchOpen(true),
						"aria-label": "Search",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "relative flex size-11 items-center justify-center text-fg",
						onClick: () => setCartOpen(true),
						"aria-label": "Open cart",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-5" }), mounted && count > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("absolute top-1.5 right-1.5 flex size-4 items-center justify-center bg-fg text-[9px] font-semibold text-bg tabular-nums cart-pop"),
							children: count
						}, bump) : null]
					})]
				})
			]
		})
	});
}
function SearchOverlay() {
	const open = useUI((s) => s.searchOpen);
	const setSearchOpen = useUI((s) => s.setSearchOpen);
	const [query, setQuery] = (0, import_react.useState)("");
	const inputRef = (0, import_react.useRef)(null);
	const navigate = useNavigate();
	const results = (0, import_react.useMemo)(() => searchSuggestions(query), [query]);
	(0, import_react.useEffect)(() => {
		if (open) {
			setQuery("");
			const t = window.setTimeout(() => inputRef.current?.focus(), 40);
			return () => window.clearTimeout(t);
		}
	}, [open]);
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			if (e.key === "Escape") setSearchOpen(false);
		}
		if (open) window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open, setSearchOpen]);
	function submit(event) {
		event.preventDefault();
		const q = query.trim();
		if (!q) return;
		setSearchOpen(false);
		navigate({
			to: "/search",
			search: { q }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("fixed inset-0 z-50", open ? "" : "pointer-events-none"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Close search",
			className: cn("absolute inset-0 bg-bg/80 transition-opacity duration-200", open ? "opacity-100" : "opacity-0"),
			onClick: () => setSearchOpen(false)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("absolute inset-x-0 top-0 bg-bg-elevated px-4 pt-6 pb-8 shadow-2xl transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] md:px-6", open ? "translate-y-0" : "-translate-y-full"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-3xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "flex items-center gap-3 border-b border-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5 text-muted" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: inputRef,
							value: query,
							onChange: (e) => setQuery(e.target.value),
							placeholder: "Search JOKER",
							className: "h-14 flex-1 bg-transparent text-lg text-fg outline-none placeholder:text-subtle"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "size-11",
							onClick: () => setSearchOpen(false),
							"aria-label": "Close search",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6",
					children: [
						query.trim() && results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								"No results for “",
								query.trim(),
								"”."
							]
						}) : null,
						results.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2",
							children: results.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/product/$slug",
								params: { slug: product.slug },
								onClick: () => setSearchOpen(false),
								className: "flex items-center gap-4 px-1 py-2 transition-colors hover:bg-surface",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: product.images[0],
										alt: "",
										className: "size-16 object-cover bg-surface"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-sm",
											children: product.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted",
											children: product.colors[0]?.name
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm tabular-nums",
										children: formatEGP(product.price)
									})
								]
							}) }, product.id))
						}) : null,
						query.trim() && results.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							onClick: submit,
							className: "mt-4 text-xs tracking-label uppercase text-muted hover:text-fg",
							children: "View all results"
						}) : null
					]
				})]
			})
		})]
	});
}
function WhatsAppButton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href: whatsappUrl(),
		target: "_blank",
		rel: "noreferrer",
		"aria-label": "Chat on WhatsApp",
		className: "fixed right-4 bottom-4 z-40 flex size-12 items-center justify-center rounded-full bg-fg text-bg shadow-lg transition-transform duration-150 hover:scale-105 md:right-6 md:bottom-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
			viewBox: "0 0 24 24",
			className: "size-5 fill-current",
			"aria-hidden": "true",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12.04 2c-5.5 0-10 4.47-10 10 0 1.76.46 3.47 1.34 4.98L2 22l5.16-1.35A9.96 9.96 0 0 0 12.04 22c5.5 0 10-4.47 10-10s-4.5-10-10-10Zm0 18.2c-1.62 0-3.2-.43-4.58-1.25l-.33-.2-3.06.8.82-2.98-.21-.34A8.18 8.18 0 0 1 3.84 12c0-4.52 3.68-8.2 8.2-8.2 4.52 0 8.2 3.68 8.2 8.2 0 4.52-3.68 8.2-8.2 8.2Zm4.5-6.14c-.25-.12-1.46-.72-1.69-.8-.23-.08-.4-.12-.56.12-.17.25-.64.8-.79.97-.14.16-.3.18-.55.06-.25-.12-1.06-.39-2.02-1.25-.75-.67-1.25-1.49-1.4-1.74-.14-.25-.02-.38.11-.5.11-.11.25-.3.37-.44.12-.15.16-.25.25-.42.08-.16.04-.31-.02-.43-.06-.12-.56-1.35-.77-1.85-.2-.48-.41-.41-.56-.42h-.48c-.16 0-.43.06-.65.31-.22.25-.86.84-.86 2.05 0 1.21.88 2.38 1 2.54.12.16 1.73 2.64 4.2 3.7.59.25 1.04.4 1.4.52.59.19 1.12.16 1.54.1.47-.07 1.46-.6 1.67-1.17.2-.58.2-1.07.14-1.17-.06-.1-.22-.16-.47-.28Z" })
		})
	});
}
function SiteShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnnouncementBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartDrawer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchOverlay, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileMenu, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppButton, {})
		]
	});
}
var styles_default = "/assets/styles-CEoVFPgd.css";
var Route$15 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "JOKER — Built for your everyday." },
			{
				name: "description",
				content: "JOKER is a youth streetwear house. Oversized tees, heavyweight hoodies and everyday sportswear. Cash on delivery across Egypt."
			},
			{
				name: "theme-color",
				content: "#0A0A0A"
			},
			{
				name: "keywords",
				content: "JOKER, streetwear, oversized t-shirt, hoodie, Egypt, cash on delivery"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&family=Syne:wght@600;700;800&display=swap"
			}
		]
	}),
	errorComponent: AppErrorComponent,
	notFoundComponent: NotFound,
	component: RootDocument
});
function RootDocument() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-bg text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
					theme: "dark",
					position: "top-center",
					toastOptions: {
						className: "font-sans",
						style: {
							background: "#111111",
							border: "1px solid #262626",
							color: "#f3f3f0"
						}
					}
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl px-4 py-24 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] tracking-label uppercase text-muted",
				children: "404"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl font-semibold",
				children: "This page doesn't exist."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "The drop you're looking for has moved."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/shop",
				className: "mt-8 inline-flex h-12 items-center bg-fg px-6 text-xs font-medium tracking-label uppercase text-bg",
				children: "Back to shop"
			})
		]
	});
}
var $$splitComponentImporter$14 = () => import("./routes-Dx5JBIRN.mjs");
var Route$14 = createFileRoute("/")({
	head: () => ({ meta: [{ title: "JOKER — Built for your everyday." }, {
		name: "description",
		content: "Premium youth streetwear. Oversized tees, hoodies and cargos. Designed for the way you move, train and live."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("../_-B48Nqn3n.mjs");
var Route$13 = createFileRoute("/$")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./about-2g-a95dq.mjs");
var Route$12 = createFileRoute("/about")({
	head: () => ({ meta: [{ title: "About — JOKER" }, {
		name: "description",
		content: BRAND.description
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./cart-C2Vqhlzt.mjs");
var Route$11 = createFileRoute("/cart")({
	head: () => ({ meta: [{ title: "Cart — JOKER" }] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./checkout-DCcG2i9k.mjs");
var Route$10 = createFileRoute("/checkout")({
	head: () => ({ meta: [{ title: "Checkout — JOKER" }, {
		name: "description",
		content: "Checkout with cash on delivery. JOKER ships across Egypt."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./contact-B0-aQkzE.mjs");
var Route$9 = createFileRoute("/contact")({
	head: () => ({ meta: [{ title: "Contact — JOKER" }, {
		name: "description",
		content: "Contact JOKER on WhatsApp, email, or the form. We reply within a day."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./privacy-D3iSkllp.mjs");
var Route$8 = createFileRoute("/privacy")({
	head: () => ({ meta: [{ title: "Privacy Policy — JOKER" }, {
		name: "description",
		content: "How JOKER handles your order details."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./search-CPUzVmwU.mjs");
var Route$7 = createFileRoute("/search")({
	validateSearch: (search) => ({ q: typeof search.q === "string" ? search.q : "" }),
	head: () => ({ meta: [{ title: "Search — JOKER" }] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./shipping-4so_zW0v.mjs");
var Route$6 = createFileRoute("/shipping")({
	head: () => ({ meta: [{ title: "Shipping & Returns — JOKER" }, {
		name: "description",
		content: "Cash on delivery across Egypt. Free shipping over 1000 EGP. 14-day returns."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var SORTS = new Set(SORT_OPTIONS.map((s) => s.value));
function parseShopSearch(search) {
	const result = {};
	if (typeof search.size === "string" && search.size) result.size = search.size;
	if (typeof search.color === "string" && search.color) result.color = search.color;
	const min = search.min == null || search.min === "" ? void 0 : Number(search.min);
	const max = search.max == null || search.max === "" ? void 0 : Number(search.max);
	if (Number.isFinite(min)) result.min = min;
	if (Number.isFinite(max)) result.max = max;
	if (SORTS.has(search.sort)) result.sort = search.sort;
	return result;
}
var $$splitComponentImporter$5 = () => import("./shop-BZjx1HCz.mjs");
var Route$5 = createFileRoute("/shop")({
	validateSearch: parseShopSearch,
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./terms-Bb4FrQ8h.mjs");
var Route$4 = createFileRoute("/terms")({
	head: () => ({ meta: [{ title: "Terms — JOKER" }, {
		name: "description",
		content: "Terms of sale for JOKER."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./order._id-3pe5Wz61.mjs");
var Route$3 = createFileRoute("/order/$id")({
	head: () => ({ meta: [{ title: "Order confirmed — JOKER" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./product._slug-GoMSh2YE.mjs");
var Route$2 = createFileRoute("/product/$slug")({
	loader: ({ params }) => {
		const product = getProductBySlug(params.slug);
		if (!product) throw notFound();
		return { product };
	},
	head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.product.name ?? "Product"} — JOKER` }, {
		name: "description",
		content: loaderData?.product.description ?? "JOKER streetwear."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./shop.index-wpwdRebx.mjs");
var Route$1 = createFileRoute("/shop/")({
	head: () => ({ meta: [{ title: "Shop — JOKER" }, {
		name: "description",
		content: "Shop JOKER oversized tees, hoodies and cargos. Free shipping over 1000 EGP. Cash on delivery."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./shop._category-BvqFOzck.mjs");
var slugs = new Set(SHOP_CATEGORIES.map((c) => c.slug));
var Route = createFileRoute("/shop/$category")({
	validateSearch: parseShopSearch,
	beforeLoad: ({ params }) => {
		if (params.category === "all" || !slugs.has(params.category)) throw notFound();
	},
	head: ({ params }) => {
		const label = SHOP_CATEGORIES.find((c) => c.slug === params.category)?.label ?? "Shop";
		return { meta: [{ title: `${label} — JOKER` }, {
			name: "description",
			content: `Shop ${label.toLowerCase()} from JOKER. Premium streetwear with cash on delivery in Egypt.`
		}] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$14.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$15
});
var SplatRoute = Route$13.update({
	id: "/$",
	path: "/$",
	getParentRoute: () => Route$15
});
var AboutRoute = Route$12.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$15
});
var CartRoute = Route$11.update({
	id: "/cart",
	path: "/cart",
	getParentRoute: () => Route$15
});
var CheckoutRoute = Route$10.update({
	id: "/checkout",
	path: "/checkout",
	getParentRoute: () => Route$15
});
var ContactRoute = Route$9.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$15
});
var PrivacyRoute = Route$8.update({
	id: "/privacy",
	path: "/privacy",
	getParentRoute: () => Route$15
});
var SearchRoute = Route$7.update({
	id: "/search",
	path: "/search",
	getParentRoute: () => Route$15
});
var ShippingRoute = Route$6.update({
	id: "/shipping",
	path: "/shipping",
	getParentRoute: () => Route$15
});
var ShopRoute = Route$5.update({
	id: "/shop",
	path: "/shop",
	getParentRoute: () => Route$15
});
var TermsRoute = Route$4.update({
	id: "/terms",
	path: "/terms",
	getParentRoute: () => Route$15
});
var OrderIdRoute = Route$3.update({
	id: "/order/$id",
	path: "/order/$id",
	getParentRoute: () => Route$15
});
var ProductSlugRoute = Route$2.update({
	id: "/product/$slug",
	path: "/product/$slug",
	getParentRoute: () => Route$15
});
var ShopIndexRoute = Route$1.update({
	id: "/",
	path: "/",
	getParentRoute: () => ShopRoute
});
var ShopRouteChildren = {
	ShopCategoryRoute: Route.update({
		id: "/$category",
		path: "/$category",
		getParentRoute: () => ShopRoute
	}),
	ShopIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	SplatRoute,
	AboutRoute,
	CartRoute,
	CheckoutRoute,
	ContactRoute,
	PrivacyRoute,
	SearchRoute,
	ShippingRoute,
	ShopRoute: ShopRoute._addFileChildren(ShopRouteChildren),
	TermsRoute,
	OrderIdRoute,
	ProductSlugRoute
};
var routeTree = Route$15._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { sortProducts as C, searchProducts as S, SORT_OPTIONS as _, Route$7 as a, filterProducts as b, useCart as c, QuantitySelector as d, INSTAGRAM_IMAGES as f, SIZE_GUIDE as g, SIZES as h, Route$3 as i, useCartTotals as l, SHOP_CATEGORIES as m, Route as n, useMounted as o, PRODUCTS as p, Route$2 as r, useUI as s, router_exports as t, formatEGP as u, allColors as v, relatedProducts as x, familyProducts as y };

import { i as __toESM } from "../_runtime.mjs";
import { X as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as whatsappUrl, t as BRAND } from "./config-DAONyBRW.mjs";
import { r as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { t as Button } from "./button-Bv-N6FT1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Input } from "./input-D6LKnbkF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-B0-aQkzE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ContactPage() {
	const [sent, setSent] = (0, import_react.useState)(false);
	function submit(event) {
		event.preventDefault();
		const data = new FormData(event.currentTarget);
		const payload = {
			name: String(data.get("name") ?? ""),
			email: String(data.get("email") ?? ""),
			message: String(data.get("message") ?? ""),
			at: (/* @__PURE__ */ new Date()).toISOString()
		};
		if (payload.name.trim().length < 2 || payload.message.trim().length < 8) {
			toast.error("Add your name and a short message.");
			return;
		}
		const key = "joker-contact";
		const prev = JSON.parse(localStorage.getItem(key) || "[]");
		localStorage.setItem(key, JSON.stringify([payload, ...prev]));
		setSent(true);
		toast.success("Message received.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-5xl gap-12 px-4 py-16 md:grid-cols-2 md:py-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl font-semibold md:text-5xl",
				children: "Contact"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm leading-relaxed text-muted",
				children: "Orders, sizing, or a restock question — WhatsApp is fastest. Email works too."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-8 space-y-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"WhatsApp ·",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "underline-offset-4 hover:underline",
							href: whatsappUrl(),
							target: "_blank",
							rel: "noreferrer",
							children: "Chat with us"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Email · ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "hover:underline",
						href: `mailto:${BRAND.email}`,
						children: BRAND.email
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Hours · Daily, 11:00–22:00 Cairo" })
				]
			})
		] }), sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "self-center text-sm",
			children: "Thanks — we'll get back to you."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-xs",
					children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "name",
						required: true,
						className: "mt-1.5"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-xs",
					children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "email",
						type: "email",
						required: true,
						className: "mt-1.5"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-xs",
					children: ["Message", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						name: "message",
						required: true,
						className: "mt-1.5 min-h-32 w-full border border-border bg-bg-elevated px-4 py-3 text-sm outline-none focus:border-fg"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Send"
				})
			]
		})]
	});
}
//#endregion
export { ContactPage as component };

import { createFileRoute } from "@tanstack/react-router";
import { CheckoutView } from "@/components/checkout/CheckoutView";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout — JOKER" },
      { name: "description", content: "Checkout with cash on delivery. JOKER ships across Egypt." },
    ],
  }),
  component: CheckoutPage,
});

function CheckoutPage() {
  return <CheckoutView />;
}

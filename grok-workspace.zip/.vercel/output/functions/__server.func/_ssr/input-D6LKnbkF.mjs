import { X as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn } from "./button-Bv-N6FT1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/input-D6LKnbkF.js
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-12 w-full border border-border bg-bg-elevated px-4 text-sm text-fg placeholder:text-subtle outline-none transition-colors duration-150 focus:border-fg", className),
		...props
	});
}
//#endregion
export { Input as t };

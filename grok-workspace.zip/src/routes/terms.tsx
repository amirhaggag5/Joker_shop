import { createFileRoute } from "@tanstack/react-router";
import { BRAND } from "@/lib/config";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms — JOKER" },
      { name: "description", content: "Terms of sale for JOKER." },
    ],
  }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <article className="mx-auto max-w-3xl px-4 py-16 md:py-24">
      <h1 className="font-display text-4xl font-semibold">Terms</h1>
      <div className="mt-8 space-y-4 text-sm leading-relaxed text-muted">
        <p>
          By placing an order you agree to pay the total shown — including shipping unless the order qualifies for free
          shipping over {BRAND.freeShippingThreshold.toLocaleString("en-EG")} EGP — in cash to the courier.
        </p>
        <p>
          Promo codes cannot be stacked. Some codes are one-time, some require a minimum subtotal, and expired codes
          will be rejected at the cart.
        </p>
        <p>
          Colours can shift slightly on screens. Size charts are measurements of the garment, not the body. If a piece
          is the wrong size and still unworn, the {BRAND.returnWindowDays}-day exchange window applies.
        </p>
        <p>JOKER may refuse orders that look fraudulent or that we cannot fulfil.</p>
      </div>
    </article>
  );
}

export function formatEGP(amount: number) {
  return `${amount.toLocaleString("en-EG")} EGP`;
}

export function formatOrderId(id: string) {
  return id.startsWith("JKR-") ? id : `JKR-${id}`;
}

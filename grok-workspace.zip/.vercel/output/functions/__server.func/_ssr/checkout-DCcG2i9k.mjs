import { i as __toESM } from "../_runtime.mjs";
import { S as useNavigate, X as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useForm, r as require_react, t as u } from "../_libs/@hookform/resolvers+[...].mjs";
import { n as cn, t as Button } from "./button-Bv-N6FT1.mjs";
import { i as string, r as object } from "../_libs/zod.mjs";
import { c as useCart, l as useCartTotals, u as formatEGP } from "./router-QtDp_Yot.mjs";
import { t as Input } from "./input-D6LKnbkF.mjs";
import { n as useOrders, t as createOrderId } from "./orders-fH9KXyrh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checkout-DCcG2i9k.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var GOVERNORATES = [
	{
		name: "Cairo",
		cities: [
			"Nasr City",
			"Heliopolis",
			"Maadi",
			"New Cairo",
			"Zamalek",
			"Downtown",
			"Shubra",
			"Ain Shams",
			"Helwan",
			"El Rehab",
			"Madinaty"
		]
	},
	{
		name: "Giza",
		cities: [
			"Dokki",
			"Mohandessin",
			"Haram",
			"6th of October",
			"Sheikh Zayed",
			"Faisal",
			"Imbaba",
			"Agouza",
			"Hadayek El Ahram"
		]
	},
	{
		name: "Alexandria",
		cities: [
			"Smouha",
			"Miami",
			"Stanley",
			"Sidi Gaber",
			"Montaza",
			"Agami",
			"Borg El Arab",
			"Gleem"
		]
	},
	{
		name: "Qalyubia",
		cities: [
			"Banha",
			"Shubra El Kheima",
			"Qalyub",
			"Khanka",
			"Obour",
			"Khusus"
		]
	},
	{
		name: "Sharqia",
		cities: [
			"Zagazig",
			"10th of Ramadan",
			"Bilbeis",
			"Minya El Qamh",
			"Faqous"
		]
	},
	{
		name: "Dakahlia",
		cities: [
			"Mansoura",
			"Talkha",
			"Mit Ghamr",
			"Sinbillawin",
			"Gamasa"
		]
	},
	{
		name: "Beheira",
		cities: [
			"Damanhur",
			"Kafr El Dawwar",
			"Rashid",
			"Edku",
			"Nubariya"
		]
	},
	{
		name: "Gharbia",
		cities: [
			"Tanta",
			"El Mahalla",
			"Kafr El Zayat",
			"Zifta",
			"Samanoud"
		]
	},
	{
		name: "Monufia",
		cities: [
			"Shebin El Kom",
			"Sadat City",
			"Menouf",
			"Quesna",
			"Ashmoun"
		]
	},
	{
		name: "Kafr El Sheikh",
		cities: [
			"Kafr El Sheikh",
			"Desouk",
			"Baltim",
			"Fuwwah",
			"Metoubes"
		]
	},
	{
		name: "Damietta",
		cities: [
			"Damietta",
			"New Damietta",
			"Faraskur",
			"Zarqa"
		]
	},
	{
		name: "Port Said",
		cities: [
			"Port Said",
			"Port Fouad",
			"El Zohour"
		]
	},
	{
		name: "Ismailia",
		cities: [
			"Ismailia",
			"Fayed",
			"Qantara",
			"Abu Suweir"
		]
	},
	{
		name: "Suez",
		cities: [
			"Suez",
			"Ain Sokhna",
			"Arbaeen"
		]
	},
	{
		name: "Red Sea",
		cities: [
			"Hurghada",
			"El Gouna",
			"Safaga",
			"Marsa Alam",
			"Qusair"
		]
	},
	{
		name: "South Sinai",
		cities: [
			"Sharm El Sheikh",
			"Dahab",
			"Nuweiba",
			"Taba",
			"Tur Sinai"
		]
	},
	{
		name: "North Sinai",
		cities: [
			"Arish",
			"Bir El Abd",
			"Nakhl"
		]
	},
	{
		name: "Fayoum",
		cities: [
			"Fayoum",
			"Ibshaway",
			"Sinnuris",
			"Tamiya"
		]
	},
	{
		name: "Beni Suef",
		cities: [
			"Beni Suef",
			"Wasta",
			"Nasser",
			"Biba"
		]
	},
	{
		name: "Minya",
		cities: [
			"Minya",
			"Mallawi",
			"Samalut",
			"Beni Mazar"
		]
	},
	{
		name: "Assiut",
		cities: [
			"Assiut",
			"Dairut",
			"Manfalut",
			"Abnub"
		]
	},
	{
		name: "Sohag",
		cities: [
			"Sohag",
			"Akhmim",
			"Girga",
			"Tahta"
		]
	},
	{
		name: "Qena",
		cities: [
			"Qena",
			"Nag Hammadi",
			"Qus",
			"Dishna"
		]
	},
	{
		name: "Luxor",
		cities: [
			"Luxor",
			"Armant",
			"Esna",
			"Tiba"
		]
	},
	{
		name: "Aswan",
		cities: [
			"Aswan",
			"Kom Ombo",
			"Edfu",
			"Daraw"
		]
	},
	{
		name: "New Valley",
		cities: [
			"Kharga",
			"Dakhla",
			"Farafra",
			"Balat"
		]
	},
	{
		name: "Matrouh",
		cities: [
			"Marsa Matrouh",
			"El Alamein",
			"Sidi Abdel Rahman",
			"Siwa"
		]
	}
];
function citiesFor(governorate) {
	return GOVERNORATES.find((g) => g.name === governorate)?.cities ?? [];
}
var schema = object({
	fullName: string().min(3, "Enter your full name"),
	mobile: string().regex(/^01[0125][0-9]{8}$/, "Enter a valid Egyptian mobile (01x xxxxxxxx)"),
	governorate: string().min(1, "Select a governorate"),
	city: string().min(1, "Select a city"),
	address: string().min(8, "Enter a full address"),
	building: string().min(1, "Building number required"),
	apartment: string().min(1, "Apartment number required"),
	notes: string().optional()
});
function CheckoutView() {
	const items = useCart((s) => s.items);
	const totals = useCartTotals();
	const promoCode = useCart((s) => s.promoCode);
	const clear = useCart((s) => s.clear);
	const markPromoUsed = useCart((s) => s.markPromoUsed);
	const addOrder = useOrders((s) => s.addOrder);
	const navigate = useNavigate();
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const form = useForm({
		resolver: u(schema),
		defaultValues: {
			fullName: "",
			mobile: "",
			governorate: "",
			city: "",
			address: "",
			building: "",
			apartment: "",
			notes: ""
		}
	});
	const governorate = form.watch("governorate");
	const cities = (0, import_react.useMemo)(() => citiesFor(governorate), [governorate]);
	if (items.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-4 py-24 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl font-semibold",
			children: "Your cart is empty"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-8",
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/shop",
				children: "Shop now"
			})
		})]
	});
	function onSubmit(values) {
		setSubmitting(true);
		const customer = {
			...values,
			notes: values.notes?.trim() || void 0
		};
		const order = {
			id: createOrderId(),
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			customer,
			items: [...items],
			subtotal: totals.subtotal,
			shipping: totals.shipping,
			discount: totals.discount,
			total: totals.total,
			promoCode: promoCode ?? void 0,
			payment: "cod"
		};
		addOrder(order);
		markPromoUsed();
		clear();
		navigate({
			to: "/order/$id",
			params: { id: order.id }
		});
	}
	const fieldClass = "mt-1.5";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-7xl gap-12 px-4 py-10 md:px-6 md:py-14 lg:grid-cols-[minmax(0,1fr)_360px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: form.handleSubmit(onSubmit),
			className: "space-y-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl font-semibold",
					children: "Checkout"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Cash on delivery. No card details required."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "sm:col-span-2 text-xs",
							children: [
								"Full name",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									className: fieldClass,
									...form.register("fullName"),
									autoComplete: "name"
								}),
								form.formState.errors.fullName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-danger",
									children: form.formState.errors.fullName.message
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "sm:col-span-2 text-xs",
							children: [
								"Mobile number",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									className: fieldClass,
									...form.register("mobile"),
									placeholder: "01xxxxxxxxx",
									inputMode: "tel"
								}),
								form.formState.errors.mobile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-danger",
									children: form.formState.errors.mobile.message
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs",
							children: [
								"Governorate",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: cn(fieldClass, "h-12 w-full border border-border bg-bg-elevated px-3 text-sm"),
									...form.register("governorate", { onChange: () => form.setValue("city", "") }),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select"
									}), GOVERNORATES.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: g.name,
										children: g.name
									}, g.name))]
								}),
								form.formState.errors.governorate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-danger",
									children: form.formState.errors.governorate.message
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs",
							children: [
								"City",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: cn(fieldClass, "h-12 w-full border border-border bg-bg-elevated px-3 text-sm"),
									...form.register("city"),
									disabled: !governorate,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select"
									}), cities.map((city) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: city,
										children: city
									}, city))]
								}),
								form.formState.errors.city ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-danger",
									children: form.formState.errors.city.message
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "sm:col-span-2 text-xs",
							children: [
								"Full address",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									className: fieldClass,
									...form.register("address"),
									placeholder: "Street name, district"
								}),
								form.formState.errors.address ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-danger",
									children: form.formState.errors.address.message
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs",
							children: [
								"Building number",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									className: fieldClass,
									...form.register("building")
								}),
								form.formState.errors.building ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-danger",
									children: form.formState.errors.building.message
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs",
							children: [
								"Apartment number",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									className: fieldClass,
									...form.register("apartment")
								}),
								form.formState.errors.apartment ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-danger",
									children: form.formState.errors.apartment.message
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "sm:col-span-2 text-xs",
							children: ["Notes", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: "mt-1.5 min-h-24 w-full border border-border bg-bg-elevated px-4 py-3 text-sm outline-none focus:border-fg",
								...form.register("notes"),
								placeholder: "Landmark, delivery time, extra details"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
					className: "border border-border p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "px-2 text-[11px] tracking-label uppercase text-muted",
							children: "Payment method"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "radio",
								checked: true,
								readOnly: true,
								className: "size-4 accent-current"
							}), "Cash on Delivery"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted",
							children: "Pay the courier when your order arrives. We never ask for card details."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					size: "lg",
					className: "w-full",
					disabled: submitting,
					children: "Confirm order"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "h-fit border border-border bg-bg-elevated p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm tracking-label uppercase",
					children: "Order summary"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 space-y-4",
					children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: item.image,
								alt: "",
								className: "size-16 object-cover bg-surface"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate",
									children: item.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										item.color,
										" / ",
										item.size,
										" × ",
										item.quantity
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "tabular-nums",
								children: formatEGP(item.price * item.quantity)
							})
						]
					}, item.key))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-6 space-y-2 border-t border-border pt-4 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Subtotal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums",
								children: formatEGP(totals.subtotal)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Shipping"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums",
								children: totals.freeShipping ? "Free" : formatEGP(totals.shipping)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Discount"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums",
								children: totals.discount ? `-${formatEGP(totals.discount)}` : formatEGP(0)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between pt-2 font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums",
								children: formatEGP(totals.total)
							})]
						})
					]
				})
			]
		})]
	});
}
function CheckoutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckoutView, {});
}
//#endregion
export { CheckoutPage as component };

import { i as __toESM } from "../_runtime.mjs";
import { S as useNavigate, X as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as BRAND } from "./config-DAONyBRW.mjs";
import { r as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { n as cn, t as Button } from "./button-Bv-N6FT1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as useCart, d as QuantitySelector, r as Route$2, s as useUI, u as formatEGP, x as relatedProducts, y as familyProducts } from "./router-QtDp_Yot.mjs";
import { n as ProductCard, t as Badge } from "./ProductCard-C0R-tK-9.mjs";
import { t as SizeGuideTable } from "./SizeGuideTable-B1cPOWUZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product._slug-GoMSh2YE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductDetail({ product }) {
	const [imageIndex, setImageIndex] = (0, import_react.useState)(0);
	const [size, setSize] = (0, import_react.useState)(null);
	const [qty, setQty] = (0, import_react.useState)(1);
	const [sizeError, setSizeError] = (0, import_react.useState)(false);
	const [openSection, setOpenSection] = (0, import_react.useState)("description");
	const addItem = useCart((s) => s.addItem);
	const setCartOpen = useUI((s) => s.setCartOpen);
	const navigate = useNavigate();
	const color = product.colors[0];
	const family = familyProducts(product);
	const related = relatedProducts(product);
	const discount = product.oldPrice && product.oldPrice > product.price ? Math.round((product.oldPrice - product.price) / product.oldPrice * 100) : 0;
	function requireSize() {
		if (!size) {
			setSizeError(true);
			toast.error("Select a size");
			return false;
		}
		return true;
	}
	function add(open = true) {
		if (!requireSize() || !color || !size) return false;
		addItem({
			productId: product.id,
			slug: product.slug,
			name: product.name,
			image: product.images[0] ?? "",
			size,
			color: color.name,
			colorHex: color.hex,
			price: product.price,
			quantity: qty
		});
		toast.success("Added to cart");
		if (open) setCartOpen(true);
		return true;
	}
	const sections = [
		{
			id: "description",
			title: "Product description",
			body: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: product.description
			})
		},
		{
			id: "fabric",
			title: "Fabric & details",
			body: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: product.fabric }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 list-disc space-y-1 pl-4",
					children: product.details.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: d }, d))
				})]
			})
		},
		{
			id: "size",
			title: "Size guide",
			body: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SizeGuideTable, {})
		},
		{
			id: "shipping",
			title: "Shipping information",
			body: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Cash on delivery is available across Egypt." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Delivery in ",
						BRAND.estimatedDelivery.toLowerCase(),
						"."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Free shipping on orders over ",
						BRAND.freeShippingThreshold.toLocaleString("en-EG"),
						" EGP. Standard shipping",
						" ",
						BRAND.shippingFee,
						" EGP."
					] })
				]
			})
		},
		{
			id: "returns",
			title: "Returns",
			body: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: [
					"Unworn items with tags can be returned or exchanged within ",
					BRAND.returnWindowDays,
					" days of delivery. Contact us on WhatsApp and we'll arrange pickup or a shop exchange."
				]
			})
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl px-4 py-8 md:px-6 md:py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-[11px] tracking-label uppercase text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shop",
						className: "hover:text-fg",
						children: "Shop"
					}),
					" ",
					"/ ",
					product.category.replace("-", " ")
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-10 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "aspect-product overflow-hidden bg-surface",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: product.images[imageIndex] ?? product.images[0],
						alt: `${product.name} ${color?.name ?? ""}`,
						className: "h-full w-full object-cover transition-opacity duration-300"
					})
				}), product.images.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-4 gap-2",
					children: product.images.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setImageIndex(i),
						className: cn("aspect-product overflow-hidden border", i === imageIndex ? "border-fg" : "border-transparent"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src,
							alt: "",
							className: "h-full w-full object-cover"
						})
					}, src))
				}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					product.badge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: product.badge }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 font-display text-4xl font-semibold md:text-5xl",
						children: product.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-baseline gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xl tabular-nums",
							children: formatEGP(product.price)
						}), product.oldPrice ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted line-through tabular-nums",
							children: formatEGP(product.oldPrice)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs tracking-label uppercase text-danger",
							children: [
								"-",
								discount,
								"%"
							]
						})] }) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-md text-sm leading-relaxed text-muted",
						children: product.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] tracking-label uppercase text-subtle",
							children: ["Color — ", color?.name]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex gap-2",
							children: family.map((item) => {
								const swatch = item.colors[0];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/product/$slug",
									params: { slug: item.slug },
									"aria-label": swatch?.name,
									className: cn("size-8 rounded-full border", item.id === product.id ? "border-fg" : "border-border-strong"),
									style: { background: swatch?.hex }
								}, item.id);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: cn("text-[11px] tracking-label uppercase", sizeError ? "text-danger" : "text-subtle"),
								children: sizeError ? "Select a size" : "Size"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/shipping",
								className: "text-[11px] tracking-label uppercase text-muted hover:text-fg",
								children: "Size guide"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: product.sizes.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setSize(s);
									setSizeError(false);
								},
								className: cn("h-12 min-w-12 border px-3 text-sm", size === s ? "border-fg bg-fg text-bg" : "border-border hover:border-fg"),
								children: s
							}, s))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuantitySelector, {
							value: qty,
							onChange: setQty,
							max: Math.min(10, product.stock)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "flex-1",
							onClick: () => add(true),
							disabled: product.stock <= 0,
							children: "Add to cart"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						className: "mt-3 w-full",
						onClick: () => {
							if (add(false)) navigate({ to: "/checkout" });
						},
						disabled: product.stock <= 0,
						children: "Buy now"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-xs text-muted",
						children: [
							"Cash on delivery · ",
							BRAND.estimatedDelivery,
							" · ",
							product.stock,
							" in stock"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 divide-y divide-border border-y border-border",
						children: sections.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex w-full items-center justify-between py-4 text-left text-sm font-medium",
							onClick: () => setOpenSection((cur) => cur === section.id ? "" : section.id),
							children: [section.title, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: openSection === section.id ? "–" : "+"
							})]
						}), openSection === section.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pb-5",
							children: section.body
						}) : null] }, section.id))
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold",
					children: "You may also like"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid grid-cols-2 gap-x-3 gap-y-10 md:grid-cols-4",
					children: related.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
				})]
			})
		]
	});
}
function ProductPage() {
	const { product } = Route$2.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductDetail, { product });
}
//#endregion
export { ProductPage as component };

import { Link, useNavigate } from "@tanstack/react-router";
import { SlidersHorizontal, X } from "lucide-react";
import { useMemo, useState } from "react";
import { ProductGrid } from "@/components/product/ProductGrid";
import { Button } from "@/components/ui/button";
import {
  SHOP_CATEGORIES,
  SORT_OPTIONS,
  SIZES,
  allColors,
  filterProducts,
  sortProducts,
  type SortKey,
} from "@/data/products";
import { cn } from "@/lib/utils";
import type { ShopSearchParams } from "@/lib/shop-search";

export function ShopView({ category = "all", search }: { category?: string; search: ShopSearchParams }) {
  const navigate = useNavigate();
  const [filtersOpen, setFiltersOpen] = useState(false);
  const sort = search.sort ?? "featured";
  const colors = allColors();

  const products = useMemo(
    () =>
      sortProducts(
        filterProducts({
          category,
          size: search.size,
          color: search.color,
          min: search.min,
          max: search.max,
        }),
        sort,
      ),
    [category, search.size, search.color, search.min, search.max, sort],
  );

  const activeCategory = SHOP_CATEGORIES.find((c) => c.slug === category) ?? SHOP_CATEGORIES[0];

  function patch(next: Partial<ShopSearchParams>) {
    const merged = { ...search, ...next };
    const clean: ShopSearchParams = {};
    if (merged.size) clean.size = merged.size;
    if (merged.color) clean.color = merged.color;
    if (merged.min != null) clean.min = merged.min;
    if (merged.max != null) clean.max = merged.max;
    if (merged.sort && merged.sort !== "featured") clean.sort = merged.sort;
    if (category && category !== "all") {
      void navigate({ to: "/shop/$category", params: { category }, search: clean });
    } else {
      void navigate({ to: "/shop", search: clean });
    }
  }

  const filterBody = (
    <div className="space-y-8">
      <div>
        <p className="text-[11px] tracking-label uppercase text-subtle">Category</p>
        <ul className="mt-3 space-y-1.5">
          {SHOP_CATEGORIES.map((cat) => (
            <li key={cat.slug}>
              {cat.slug === "all" ? (
                <Link
                  to="/shop"
                  search={search}
                  className={cn("text-sm", cat.slug === category ? "text-fg" : "text-muted hover:text-fg")}
                  onClick={() => setFiltersOpen(false)}
                >
                  {cat.label}
                </Link>
              ) : (
                <Link
                  to="/shop/$category"
                  params={{ category: cat.slug }}
                  search={search}
                  className={cn("text-sm", cat.slug === category ? "text-fg" : "text-muted hover:text-fg")}
                  onClick={() => setFiltersOpen(false)}
                >
                  {cat.label}
                </Link>
              )}
            </li>
          ))}
        </ul>
      </div>
      <div>
        <p className="text-[11px] tracking-label uppercase text-subtle">Size</p>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {SIZES.map((size) => (
            <button
              key={size}
              type="button"
              onClick={() => patch({ size: search.size === size ? undefined : size })}
              className={cn(
                "h-10 min-w-10 border px-2 text-xs",
                search.size === size ? "border-fg bg-fg text-bg" : "border-border hover:border-fg",
              )}
            >
              {size}
            </button>
          ))}
        </div>
      </div>
      <div>
        <p className="text-[11px] tracking-label uppercase text-subtle">Color</p>
        <ul className="mt-3 space-y-2">
          {colors.map((color) => (
            <li key={color.name}>
              <button
                type="button"
                onClick={() => patch({ color: search.color === color.name ? undefined : color.name })}
                className="flex items-center gap-2 text-sm text-muted hover:text-fg"
              >
                <span
                  className={cn(
                    "size-4 rounded-full border",
                    search.color === color.name ? "border-fg" : "border-border-strong",
                  )}
                  style={{ background: color.hex }}
                />
                {color.name}
              </button>
            </li>
          ))}
        </ul>
      </div>
      <div>
        <p className="text-[11px] tracking-label uppercase text-subtle">Price</p>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <input
            type="number"
            min={0}
            placeholder="Min"
            defaultValue={search.min ?? ""}
            onBlur={(e) => {
              const value = e.target.value ? Number(e.target.value) : undefined;
              patch({ min: Number.isFinite(value) ? value : undefined });
            }}
            className="h-11 border border-border bg-bg px-3 text-sm outline-none focus:border-fg"
          />
          <input
            type="number"
            min={0}
            placeholder="Max"
            defaultValue={search.max ?? ""}
            onBlur={(e) => {
              const value = e.target.value ? Number(e.target.value) : undefined;
              patch({ max: Number.isFinite(value) ? value : undefined });
            }}
            className="h-11 border border-border bg-bg px-3 text-sm outline-none focus:border-fg"
          />
        </div>
      </div>
      {(search.size || search.color || search.min != null || search.max != null) && (
        <button
          type="button"
          className="text-xs tracking-label uppercase text-muted hover:text-fg"
          onClick={() =>
            patch({ size: undefined, color: undefined, min: undefined, max: undefined, sort: search.sort })
          }
        >
          Clear filters
        </button>
      )}
    </div>
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 md:px-6 md:py-14">
      <header className="mb-8">
        <p className="text-[11px] tracking-label uppercase text-muted">Shop</p>
        <h1 className="mt-2 font-display text-4xl font-semibold md:text-5xl">{activeCategory.label}</h1>
      </header>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-muted">{products.length} pieces</p>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="lg:hidden" onClick={() => setFiltersOpen(true)}>
            <SlidersHorizontal className="size-3.5" />
            Filter
          </Button>
          <label className="flex items-center gap-2 text-xs text-muted">
            <span className="hidden sm:inline">Sort</span>
            <select
              value={sort}
              onChange={(e) => patch({ sort: e.target.value as SortKey })}
              className="h-10 border border-border bg-bg px-3 text-xs text-fg outline-none"
            >
              {SORT_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </label>
        </div>
      </div>
      <div className="grid gap-10 lg:grid-cols-[220px_minmax(0,1fr)]">
        <aside className="hidden lg:block">{filterBody}</aside>
        <ProductGrid products={products} />
      </div>

      <div className={cn("fixed inset-0 z-50 lg:hidden", filtersOpen ? "" : "pointer-events-none")}>
        <button
          type="button"
          className={cn(
            "absolute inset-0 bg-bg/70 transition-opacity duration-200",
            filtersOpen ? "opacity-100" : "opacity-0",
          )}
          onClick={() => setFiltersOpen(false)}
          aria-label="Close filters"
        />
        <aside
          className={cn(
            "absolute inset-y-0 left-0 w-[min(100%,20rem)] overflow-y-auto bg-bg-elevated p-5 transition-transform duration-300",
            filtersOpen ? "translate-x-0" : "-translate-x-full",
          )}
        >
          <div className="mb-6 flex items-center justify-between">
            <p className="text-sm tracking-label uppercase">Filters</p>
            <button type="button" className="size-10" onClick={() => setFiltersOpen(false)} aria-label="Close filters">
              <X className="size-5" />
            </button>
          </div>
          {filterBody}
        </aside>
      </div>
    </div>
  );
}

import { Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/product/ProductCard";
import { QuantitySelector } from "@/components/product/QuantitySelector";
import { SizeGuideTable } from "@/components/product/SizeGuideTable";
import { familyProducts, relatedProducts, type Product } from "@/data/products";
import { BRAND } from "@/lib/config";
import { formatEGP } from "@/lib/format";
import { cn } from "@/lib/utils";
import { useCart } from "@/store/cart";
import { useUI } from "@/store/ui";

export function ProductDetail({ product }: { product: Product }) {
  const [imageIndex, setImageIndex] = useState(0);
  const [size, setSize] = useState<string | null>(null);
  const [qty, setQty] = useState(1);
  const [sizeError, setSizeError] = useState(false);
  const [openSection, setOpenSection] = useState<string>("description");
  const addItem = useCart((s) => s.addItem);
  const setCartOpen = useUI((s) => s.setCartOpen);
  const navigate = useNavigate();
  const color = product.colors[0];
  const family = familyProducts(product);
  const related = relatedProducts(product);
  const discount =
    product.oldPrice && product.oldPrice > product.price
      ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)
      : 0;

  function requireSize() {
    if (!size) {
      setSizeError(true);
      toast.error("Select a size");
      return false;
    }
    return true;
  }

  function add(open = true) {
    if (!requireSize() || !color || !size) return false;
    addItem({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      image: product.images[0] ?? "",
      size,
      color: color.name,
      colorHex: color.hex,
      price: product.price,
      quantity: qty,
    });
    toast.success("Added to cart");
    if (open) setCartOpen(true);
    return true;
  }

  const sections = [
    { id: "description", title: "Product description", body: <p className="text-sm leading-relaxed text-muted">{product.description}</p> },
    {
      id: "fabric",
      title: "Fabric & details",
      body: (
        <div className="text-sm text-muted">
          <p>{product.fabric}</p>
          <ul className="mt-3 list-disc space-y-1 pl-4">
            {product.details.map((d) => (
              <li key={d}>{d}</li>
            ))}
          </ul>
        </div>
      ),
    },
    { id: "size", title: "Size guide", body: <SizeGuideTable /> },
    {
      id: "shipping",
      title: "Shipping information",
      body: (
        <div className="space-y-2 text-sm text-muted">
          <p>Cash on delivery is available across Egypt.</p>
          <p>Delivery in {BRAND.estimatedDelivery.toLowerCase()}.</p>
          <p>
            Free shipping on orders over {BRAND.freeShippingThreshold.toLocaleString("en-EG")} EGP. Standard shipping{" "}
            {BRAND.shippingFee} EGP.
          </p>
        </div>
      ),
    },
    {
      id: "returns",
      title: "Returns",
      body: (
        <p className="text-sm leading-relaxed text-muted">
          Unworn items with tags can be returned or exchanged within {BRAND.returnWindowDays} days of delivery. Contact
          us on WhatsApp and we'll arrange pickup or a shop exchange.
        </p>
      ),
    },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 md:px-6 md:py-12">
      <p className="text-[11px] tracking-label uppercase text-muted">
        <Link to="/shop" className="hover:text-fg">
          Shop
        </Link>{" "}
        / {product.category.replace("-", " ")}
      </p>
      <div className="mt-6 grid gap-10 lg:grid-cols-2">
        <div>
          <div className="aspect-product overflow-hidden bg-surface">
            <img
              src={product.images[imageIndex] ?? product.images[0]}
              alt={`${product.name} ${color?.name ?? ""}`}
              className="h-full w-full object-cover transition-opacity duration-300"
            />
          </div>
          {product.images.length > 1 ? (
            <div className="mt-3 grid grid-cols-4 gap-2">
              {product.images.map((src, i) => (
                <button
                  key={src}
                  type="button"
                  onClick={() => setImageIndex(i)}
                  className={cn("aspect-product overflow-hidden border", i === imageIndex ? "border-fg" : "border-transparent")}
                >
                  <img src={src} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          ) : null}
        </div>
        <div>
          {product.badge ? <Badge>{product.badge}</Badge> : null}
          <h1 className="mt-4 font-display text-4xl font-semibold md:text-5xl">{product.name}</h1>
          <div className="mt-4 flex items-baseline gap-3">
            <p className="text-xl tabular-nums">{formatEGP(product.price)}</p>
            {product.oldPrice ? (
              <>
                <p className="text-sm text-muted line-through tabular-nums">{formatEGP(product.oldPrice)}</p>
                <p className="text-xs tracking-label uppercase text-danger">-{discount}%</p>
              </>
            ) : null}
          </div>
          <p className="mt-6 max-w-md text-sm leading-relaxed text-muted">{product.description}</p>

          <div className="mt-8">
            <p className="text-[11px] tracking-label uppercase text-subtle">Color — {color?.name}</p>
            <div className="mt-3 flex gap-2">
              {family.map((item) => {
                const swatch = item.colors[0];
                return (
                  <Link
                    key={item.id}
                    to="/product/$slug"
                    params={{ slug: item.slug }}
                    aria-label={swatch?.name}
                    className={cn(
                      "size-8 rounded-full border",
                      item.id === product.id ? "border-fg" : "border-border-strong",
                    )}
                    style={{ background: swatch?.hex }}
                  />
                );
              })}
            </div>
          </div>

          <div className="mt-8">
            <div className="flex items-center justify-between">
              <p className={cn("text-[11px] tracking-label uppercase", sizeError ? "text-danger" : "text-subtle")}>
                {sizeError ? "Select a size" : "Size"}
              </p>
              <Link to="/shipping" className="text-[11px] tracking-label uppercase text-muted hover:text-fg">
                Size guide
              </Link>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {product.sizes.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => {
                    setSize(s);
                    setSizeError(false);
                  }}
                  className={cn(
                    "h-12 min-w-12 border px-3 text-sm",
                    size === s ? "border-fg bg-fg text-bg" : "border-border hover:border-fg",
                  )}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <QuantitySelector value={qty} onChange={setQty} max={Math.min(10, product.stock)} />
            <Button className="flex-1" onClick={() => add(true)} disabled={product.stock <= 0}>
              Add to cart
            </Button>
          </div>
          <Button
            variant="outline"
            className="mt-3 w-full"
            onClick={() => {
              if (add(false)) void navigate({ to: "/checkout" });
            }}
            disabled={product.stock <= 0}
          >
            Buy now
          </Button>
          <p className="mt-4 text-xs text-muted">
            Cash on delivery · {BRAND.estimatedDelivery} · {product.stock} in stock
          </p>

          <div className="mt-10 divide-y divide-border border-y border-border">
            {sections.map((section) => (
              <div key={section.id}>
                <button
                  type="button"
                  className="flex w-full items-center justify-between py-4 text-left text-sm font-medium"
                  onClick={() => setOpenSection((cur) => (cur === section.id ? "" : section.id))}
                >
                  {section.title}
                  <span className="text-muted">{openSection === section.id ? "–" : "+"}</span>
                </button>
                {openSection === section.id ? <div className="pb-5">{section.body}</div> : null}
              </div>
            ))}
          </div>
        </div>
      </div>

      <section className="mt-20">
        <h2 className="font-display text-2xl font-semibold">You may also like</h2>
        <div className="mt-8 grid grid-cols-2 gap-x-3 gap-y-10 md:grid-cols-4">
          {related.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>
    </div>
  );
}

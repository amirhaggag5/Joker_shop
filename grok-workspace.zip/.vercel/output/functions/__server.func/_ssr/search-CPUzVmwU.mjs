import { X as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-Bv-N6FT1.mjs";
import { S as searchProducts, a as Route$7 } from "./router-QtDp_Yot.mjs";
import { t as ProductGrid } from "./ProductGrid-CHQwFaA8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-CPUzVmwU.js
var import_jsx_runtime = require_jsx_runtime();
function SearchPage() {
	const { q } = Route$7.useSearch();
	const results = searchProducts(q);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl px-4 py-10 md:px-6 md:py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] tracking-label uppercase text-muted",
				children: "Search"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl font-semibold",
				children: q ? `Results for “${q}”` : "Search JOKER"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: q ? `${results.length} ${results.length === 1 ? "piece" : "pieces"}` : "Type a name, colour, or category."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10",
				children: q && results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-border px-6 py-20 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-2xl",
							children: [
								"No results for “",
								q,
								"”."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Try “t-shirt”, “hoodie”, “navy”, or “oversized”."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-8",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/shop",
								children: "Browse the shop"
							})
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, { products: results })
			})
		]
	});
}
//#endregion
export { SearchPage as component };

import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

export function Logo({ className, to = "/" }: { className?: string; to?: string }) {
  return (
    <Link
      to={to}
      className={cn(
        "font-display text-xl font-extrabold tracking-brand text-fg md:text-2xl",
        className,
      )}
      aria-label="JOKER home"
    >
      JOKER
    </Link>
  );
}

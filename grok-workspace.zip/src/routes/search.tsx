import { createFileRoute } from "@tanstack/react-router";
import { ProductGrid } from "@/components/product/ProductGrid";
import { Button } from "@/components/ui/button";
import { Link } from "@tanstack/react-router";
import { searchProducts } from "@/data/products";

export const Route = createFileRoute("/search")({
  validateSearch: (search: Record<string, unknown>) => ({
    q: typeof search.q === "string" ? search.q : "",
  }),
  head: () => ({
    meta: [{ title: "Search — JOKER" }],
  }),
  component: SearchPage,
});

function SearchPage() {
  const { q } = Route.useSearch();
  const results = searchProducts(q);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 md:px-6 md:py-14">
      <p className="text-[11px] tracking-label uppercase text-muted">Search</p>
      <h1 className="mt-2 font-display text-4xl font-semibold">{q ? `Results for “${q}”` : "Search JOKER"}</h1>
      <p className="mt-2 text-sm text-muted">
        {q ? `${results.length} ${results.length === 1 ? "piece" : "pieces"}` : "Type a name, colour, or category."}
      </p>
      <div className="mt-10">
        {q && results.length === 0 ? (
          <div className="border border-border px-6 py-20 text-center">
            <p className="font-display text-2xl">No results for “{q}”.</p>
            <p className="mt-2 text-sm text-muted">Try “t-shirt”, “hoodie”, “navy”, or “oversized”.</p>
            <Button className="mt-8" asChild>
              <Link to="/shop">Browse the shop</Link>
            </Button>
          </div>
        ) : (
          <ProductGrid products={results} />
        )}
      </div>
    </div>
  );
}
